from config.settings import BASE_DIR
from src.connectors.conn_db import ConnDB
from pathlib import Path
import pandas as pd
from src.utils import read_sql
import time
from sqlalchemy import create_engine, Engine, text
from sqlalchemy.exc import OperationalError
from psycopg.errors import QueryCanceled
import pandas as pd
import psycopg
from psycopg.errors import OperationalError
from psycopg.rows import dict_row  # для совместимости с pandas.read_sql
from datetime import datetime

print(f"Дата запуска программы: {time.ctime()}\n")

# коннекторы
# kot
engine_pg = ConnDB.get_engine_db("KOT_")
# pg33-test
engine_pg33test = ConnDB.get_engine_db("PG33TEST_")
# idb33
engine_idb33 = ConnDB.get_engine_db("IDB33_")


def load_df_from_kot(
    sql_to: str | Path,
    engine_extract: Engine,
    name_tab_load: str | None,
    max_retries=5,
    base_delay=2,
) -> list[str, pd.DataFrame]:
    attempt = 0

    sql_to = Path(sql_to) if isinstance(sql_to, str) else sql_to
    query = read_sql.read_sqlalch(sql_to)  # Предполагаем, что эта функция существует

    if name_tab_load is None:
        name_tab_load = sql_to.name.split("---")[1].replace(".sql", "")

    time_start_extract = time.time()
    last_error = None

    while attempt < max_retries:
        try:
            # ИСПОЛЬЗУЕМ .connect() ВМЕСТО .begin()
            with engine_extract.connect() as connection:
                # Устанавливаем параметры для текущей сессии.
                # В SQLAlchemy 2.0 эти команды будут выполнены в режиме "autocommit",
                # каждая в своей мини-транзакции, что для SET-команд нормально.
                connection.execute(text("SET default_transaction_read_only = true"))
                # connection.execute(text("SET TIME ZONE '+03:00'"))
                # Увеличим таймауты, чтобы они точно не мешали
                connection.execute(text("SET statement_timeout = '3600s'"))  # 1 час
                connection.execute(text("SET idle_in_transaction_session_timeout = '3600s'"))  # 1 час

                print(f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} 🧮 Грузим запрос {sql_to.name}, попытка {attempt + 1}/{max_retries}")

                # Передаем объект connection в pd.read_sql
                # Pandas выполнит запрос и закроет всё что нужно.
                # Транзакция не будет "висеть" открытой после выполнения запроса.
                df = pd.read_sql(query, connection)

                print(
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Забрал запрос в фрейм, размером {df.shape}\n"
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Забрал запрос {sql_to.name} за {int(time.time() - time_start_extract)} сек\n"
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} ✅ Успешно на попытке {attempt + 1}"
                )

                # Теперь, когда мы выходим из блока with, соединение просто
                # возвращается в пул, а не пытается сделать COMMIT для несуществующей транзакции.
                return [name_tab_load, df]

        except OperationalError as e:
            last_error = e
            # Проверяем разные варианты ошибок конфликта с recovery
            conflict_errors = [
                "conflict with recovery",
                "canceling statement due to conflict with recovery",
                "row versions that must be removed",
            ]

            if any(err_text in str(e) for err_text in conflict_errors):
                wait = base_delay * (2**attempt)
                print(
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} ⚠️ Конфликт с recovery. Повтор через {wait} сек. "
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Попытка {attempt + 1}/{max_retries}. Ошибка: {str(e)}"
                )
            else:
                wait = base_delay * (2**attempt)
                print(
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} ⚠️ OperationalError (будет повтор). Повтор через {wait} сек. "
                    f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Попытка {attempt + 1}/{max_retries}. Ошибка: {str(e)}"
                )

            time.sleep(wait)
            attempt += 1

        except Exception as e:
            last_error = e
            wait = base_delay * (2**attempt)
            print(
                f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} ⚠️ Неожиданная ошибка (будет повтор). Повтор через {wait} сек. "
                f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Попытка {attempt + 1}/{max_retries}. Ошибка: {str(e)}"
            )
            time.sleep(wait)
            attempt += 1

    raise RuntimeError(
        f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} ❌ Не удалось выполнить SELECT после {max_retries} попыток. "
        f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Последняя ошибка: {str(last_error)}"
    )


# ==================================================================================================================
# ⚡функция загрузки фрейма в pg33-test
def load_df_to_pg33test(df: pd.DataFrame, name_tab_load: str, engine_load: Engine):
    print(f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} ⚡Начинаем загружать данные в PG33-test")
    time_start_load = time.time()

    # вычисляем оптимальный chunksize
    good_chunksize = int(60000 / len(df.columns))

    df.to_sql(
        name_tab_load,
        engine_load,
        index=False,
        if_exists="replace",
        schema="otpb_bi",
        method="multi",
        chunksize=good_chunksize,
    )

    return print(
        f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Загрузил фрейм {name_tab_load} за {int(time.time() - time_start_load)} сек\n"
        f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Таблица {name_tab_load} создана на PG33-test\n"
        "================================================================================"
    )


# 🧮функция создания фрейма из запроса к БД IDB33
def load_df_from_idb33(
    sql_to: str | Path,
    engine_extract: Engine,
    name_tab_load: str | None,
) -> list[str, pd.DataFrame]:

    # Если необходимо, то переводим путь в Path
    sql_to = Path(sql_to) if isinstance(sql_to, str) else sql_to
    # Читаем sql запрос
    query = read_sql.read_sqlalch(sql_to)

    # Вычисляем имя новой таблицы в pg33
    # если имя для новой таблицы None, то вычисляем из названия
    if name_tab_load is None:
        name_tab_load = sql_to.name.split("---")[1].replace(".sql", "")

    print(f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} 🧮Грузим запрос {sql_to}")
    # начальное время
    time_start_extract = time.time()
    df = pd.read_sql(query, engine_extract)
    print(
        f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Забрал запрос в фрейм, размером {df.shape}\n"
        f"{datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')} Забрал запрос {sql_to} за {int(time.time() - time_start_extract)} сек\n"
    )
    return [name_tab_load, df]


# 🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️
# готовый мего на запись всех запросов kot->pg33-test:
for i in (BASE_DIR / "data/sql/kot").glob("*.sql"):

    # забираем данные в список [имя таблицы, фрейм данных]
    list_res = load_df_from_kot(
        sql_to=i,
        name_tab_load=None,
        engine_extract=engine_pg,
    )

    # создаем таблицу в pg33-test:
    load_df_to_pg33test(df=list_res[1], name_tab_load=list_res[0], engine_load=engine_pg33test)

print(f"\n🎆ГОТОВО {datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')}")


# 🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️🚴‍♀️
# готовый мего код на запись всех запросов idb33->pg33-test:
for i in (BASE_DIR / "data/sql/idb33").glob("*.sql"):

    # забираем данные в список [имя таблицы, фрейм данных]
    list_res = load_df_from_idb33(
        sql_to=i,
        name_tab_load=None,
        engine_extract=engine_idb33,
    )

    # создаем таблицу в pg33-test:
    load_df_to_pg33test(df=list_res[1], name_tab_load=list_res[0], engine_load=engine_pg33test)

print(f"\n🎆ГОТОВО {datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')}")
print(f"Закончил в: {datetime.today().strftime(format='%d.%m.%Y %H:%M:%S')}\n")
