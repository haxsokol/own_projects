import pandas as pd
from hdbcli import dbapi
from pathlib import Path
from config.settings import BASE_DIR, DBSettingsSAP


class ConnDBSAP:

    def get_engine_db_SAP(prefix_db="SAP_") -> dbapi.connect:
        dsn_for_engine_SAP = DBSettingsSAP.from_prefix(prefix_db).dsnSAP
        return dbapi.connect(**dsn_for_engine_SAP)

    @classmethod
    def get_df_from_sql_SAP(
        cls, path_sql: Path | str, prefix_db="SAP_"
    ) -> pd.DataFrame:
        # Читаем SQL-запрос из файла
        with open(path_sql, "r", encoding="utf-8") as file:
            query = file.read()

        # Создаем движок из метода выше
        engine_SAP = cls.get_engine_db_SAP(prefix_db)

        # Выполняем запрос через pandas и созданный движок
        return pd.read_sql(query, engine_SAP)
