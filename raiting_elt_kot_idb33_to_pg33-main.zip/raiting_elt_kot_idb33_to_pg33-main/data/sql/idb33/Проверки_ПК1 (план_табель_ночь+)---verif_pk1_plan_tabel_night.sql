WITH res AS
(SELECT DISTINCT 
cast(replace(ztm.PERNR,':','') as numeric) PERNR
,ztm."DATA" 
,ztm.FACT_H
,BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA") wp
,CASE WHEN BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA")IS NOT NULL AND BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA") <>'-'
	THEN TO_CHAR(
			TO_DATE(
				SUBSTR(BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA"), 1,6)
			, 'HH24:MI:SS')
		, 'HH24:MI:SS') 
	ELSE null
	END  start_time
,CASE WHEN BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA")IS NOT NULL AND BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA") <>'-'
	THEN TO_CHAR(
			TO_DATE(
				REPLACE(
					SUBSTR(BATCHMES.f_get_work_period(ztm.PERNR,ztm."DATA"), 8,6)
				,'240000', '235959')
			, 'HH24:MI:SS')
		, 'HH24:MI:SS') 
	ELSE null
	END  end_time
FROM BATCHMES.ZHCMI896_TBT_MV ztm 
JOIN batchmes.CONTACT_ALL_MV cam ON ztm.PERNR=cam.CONTACT_ID 
								AND (cam.DISCHARGE_DATE IS null OR cam.DISCHARGE_DATE>=ztm."DATA")
								AND ztm.FACT_H >7 --ночные и немного дневных (по другому никак) 
								AND TRUNC(ztm."DATA")>=TO_DATE('01.01.2024', 'dd.mm.yyyy') --данные с 01.01.2024
								AND TRUNC(ztm."DATA")<SYSDATE --в текущий день будет красный кружок
JOIN IDB01.INTEGR_CHL_REF_EMP_MV icrem  ON ztm.PERNR=icrem.PERNR
JOIN IDB01.INTEGR_CHL_EMP_LVLPK_MV icelm ON cast(icrem.INTEGR_CHL_REF_EMP_ID as integer)=cast(icelm.INTEGR_CHL_REF_EMP_ID as integer) 
                                        AND icelm.REF_INSP_LVLPK_ID=7 
					AND ((ztm."DATA" >= icelm.DATE_BEG AND icelm.DATE_END IS NULL ) OR (ztm."DATA" BETWEEN icelm.DATE_BEG AND icelm.DATE_END))
	)

SELECT 
PERNR
,"DATA"
,FACT_H
,CASE WHEN wp IS NOT NULL AND wp <>'-'
	THEN TO_CHAR("DATA" + TO_DSINTERVAL('0 ' || SUBSTR(start_time,1,2) || ':' || SUBSTR(start_time,4,2) || ':' || SUBSTR(start_time,7,2)),
			 'YYYY-MM-DD HH24:MI:SS') 
	ELSE null
	END StartDateTime
,CASE WHEN wp IS NOT NULL AND wp <>'-' AND start_time > end_time --если смена заканчивается на след. сутки, то +1 день к дате
	THEN TO_CHAR("DATA" + TO_DSINTERVAL('0 ' || SUBSTR(end_time,1,2) || ':' || SUBSTR(end_time,4,2) || ':' || SUBSTR(end_time,7,2)) + INTERVAL '1' DAY,
			 'YYYY-MM-DD HH24:MI:SS')
	WHEN wp IS NOT NULL AND wp <>'-'
	THEN  TO_CHAR("DATA" + TO_DSINTERVAL('0 ' || SUBSTR(end_time,1,2) || ':' || SUBSTR(end_time,4,2) || ':' || SUBSTR(end_time,7,2)),
			 'YYYY-MM-DD HH24:MI:SS')
	ELSE null
	END EndDateTime
,CASE WHEN start_time > end_time
	THEN "DATA"+1
	ELSE "DATA"
	END DataNew
,CASE WHEN FACT_H > 30 --ночь
	THEN "DATA"-1
	WHEN FACT_H > (TO_DATE(end_time,'HH24:MI:SS') - TO_DATE(start_time,'HH24:MI:SS')) * 24+3 -- подстраховка от кривизны SAP
	THEN "DATA"-1
	ELSE "DATA"
	END DataPrev
,start_time
,end_time
FROM res
ORDER BY "DATA" DESC