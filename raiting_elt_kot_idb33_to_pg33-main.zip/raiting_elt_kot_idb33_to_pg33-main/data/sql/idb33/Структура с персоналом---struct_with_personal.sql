with 
CALENDAR AS --вывод каждого дня из календаря
	(SELECT  to_date(DATE_OF_CALENDAR) AS R ,
	to_char(DATE_OF_CALENDAR,'YYYY') as YEAR, to_char(DATE_OF_CALENDAR,'MM') as MONTH
	FROM LAUPADMIN.SPR_CALENDAR_ADM WHERE TO_DATE(DATE_OF_CALENDAR) BETWEEN TO_DATE('2020-01-01','YYYY-MM-DD') AND sysdate+61 --отбираем даты с 2020 года по сегодня+61 день, чтобы видеть в будущее для декретниц
	),

PERS as --постоянные переводы по TN
	(
	SELECT DISTINCT
	CASE 
		WHEN  DATE_BEG<to_date('01.01.2022','dd.mm.yy')	
	THEN to_date('01.01.2022','dd.mm.yy')	
		ELSE to_date(to_char(DATE_BEG,'dd')||'.'||to_char(DATE_BEG,'mm')||'.'||to_char(DATE_BEG,'yyyy'),'dd.mm.yy') 
	END as DS
	,CASE 
		WHEN  DATE_END>sysdate	THEN sysdate
		WHEN  DATE_END IS NULL AND DATE_OF_DISMISSAL IS NOT NULL THEN DATE_OF_DISMISSAL
		WHEN  DATE_END IS NULL	THEN sysdate 
		WHEN  DATE_END<to_date('01.01.2022','dd.mm.yy')
	THEN to_date('01.01.2022','dd.mm.yy')	
		ELSE to_date(to_char(DATE_END,'dd')||'.'||to_char(DATE_END,'mm')||'.'||to_char(DATE_END,'yyyy'),'dd.mm.yy') 
	END as DE
	,TN
	,STRUCT_ID
	,FIO_ALL

	FROM IDB01.POWER_BI_NHRS_FULL_MV NHRS
		where 
		(DATE_END>to_date('01012018','ddmmyyyy') or DATE_END IS NULL)	-- ограничить дату окончания 2022 годом, старые переводы нам не нужны
		AND TYPE_WORKER IN ('Временная', 'Постоянная')
	--	AND TN IN (70006781)  -- тест на человеке
	),

			
PERS_Calendar AS --постоянные переводы на каждый день из PERS_Calendar
	(SELECT distinct 	
		max(CALENDAR.r) AS r
		,max(PERS.STRUCT_ID) AS STRUCT_ID
		,PERS.TN
		,CALENDAR.YEAR
		,CALENDAR.MONTH
		,FIO_ALL
	FROM CALENDAR, PERS where CALENDAR.r between PERS.ds and PERS.de
		GROUP BY YEAR, MONTH, TN	,FIO_ALL)
		
		,			
/*_____ собираем структуру на уровне цеха с выводом и STRUCT_ID и OBJID ______*/
PERS_RAB_MESTO AS (
	SELECT 
	RAB_MESTO.TN
	,FIO_ALL
	,SHOP.ORG_ID
	,SHOP.STRUCT_ID
	,RAB_MESTO.YEAR
	,RAB_MESTO.MONTH
	,SHOP.OBJID
	,SUBDIVISION2.OBJID AS OBJID_SHOP
	,SHOP."Цех"
	,TO_NUMBER(SUBDIVISION2.OBJID||RAB_MESTO.YEAR||TO_NUMBER(RAB_MESTO.MONTH)) AS STRUCT_YEAR_MONTH
	,TO_NUMBER(RAB_MESTO.TN||RAB_MESTO.YEAR||TO_NUMBER(RAB_MESTO.MONTH)) AS TN_YEAR_MONTH
	
FROM PERS_Calendar RAB_MESTO 
	left join  (
	SELECT distinct 
		CASE WHEN SHOP.ORG_NAME is null THEN STRUCT."Цех" ELSE  SHOP.ORG_NAME END AS "Цех"
		,STRUCT."Цех id" AS STRUCT_ID
		,STRUCT."Цех" as CEH
		,SHOP.NAME
		, CASE  
			WHEN SHOP.ORG_ID IS NULL AND  MANUFACTURE.ORG_ID IS NULL AND ORGANIZATIONS.ORG_ID IS NULL 
		THEN null  --все пусто, нет уровней, ничего не беру
			WHEN SHOP.ORG_ID IS NULL AND  MANUFACTURE.ORG_ID IS NULL AND ORGANIZATIONS.ORG_ID IS NOT NULL 
		THEN ORGANIZATIONS.ORG_ID  --все пусто, кроме организации, беру организацию
			WHEN SHOP.ORG_ID IS NULL AND  MANUFACTURE.ORG_ID IS not NULL 
		THEN MANUFACTURE.ORG_ID  --пусто в цехе и непусто в производстве беру производство
			WHEN SHOP.ORG_ID IS NULL AND  MANUFACTURE.ORG_ID IS NULL AND ORGANIZATIONS.ORG_ID IS not NULL 
		THEN ORGANIZATIONS.ORG_ID  --пусто в цехе и пусто в производстве, не пусто в организации, беру организацию
			WHEN SHOP.ORG_ID IS NOT NULL 
		THEN SHOP.ORG_ID
			ELSE null END   AS ORG_ID
		,SUBDIVISION.OBJID
FROM idb01.SQP_STRUCT_MV STRUCT 
	left JOIN IDB01.STRUCT_WORKSHOPS_MV SHOP on STRUCT."Цех id"=SHOP.STRUCT_ID
	left join IDB01.STRUCT_MANUFACTURE_MV MANUFACTURE on STRUCT."Цех id"=MANUFACTURE.STRUCT_ID
	left join IDB01.STRUCT_ORGANIZATIONS_MV ORGANIZATIONS on STRUCT."Цех id"=ORGANIZATIONS.STRUCT_ID
/*_________ связываю для вывода OBJID ________________*/
	LEFT JOIN LAUPADMIN.SUBDIVISION_MV SUBDIVISION ON SUBDIVISION.STRUCT_ID=STRUCT."Цех id"
			) SHOP on SHOP.STRUCT_ID=RAB_MESTO.STRUCT_ID
/*_________ связываю для вывода OBJID ________________*/
	LEFT JOIN LAUPADMIN.SUBDIVISION_MV SUBDIVISION2 ON SUBDIVISION2.STRUCT_ID=SHOP.ORG_ID
WHERE YEAR>=2024
	)

SELECT * FROM PERS_RAB_MESTO
WHERE OBJID_SHOP IS NOT null