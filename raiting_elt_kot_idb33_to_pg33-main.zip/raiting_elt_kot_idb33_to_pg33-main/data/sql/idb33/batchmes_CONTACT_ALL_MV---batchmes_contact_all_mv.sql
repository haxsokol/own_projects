select distinct cast(replace(cam.EMPLOYEE_ID,':','') as numeric) EMPLOYEE_ID 
,concat (concat (concat (concat (concat (concat (concat (concat (concat( SUBSTR(cam.LAST_NAME,1,1),LOWER(SUBSTR(cam.LAST_NAME,2))), ' '),SUBSTR(cam.FIRST_NAME,1,1)),'.'),SUBSTR(cam.MIDDLE_NAME,1,1)),'.'), ' ('),cast(replace(cam.CONTACT_ID,':','') as numeric)),')') FIO_TN
,cam.JOB_TITLE
,sm.NAME 
,CASE WHEN sm.WORKSHOPS='Участки' THEN CONCAT('Участки - ',sm.MANUFACTURE) ELSE sm.WORKSHOPS END  "Цех/участок"
,sm.MANUFACTURE
,cam.ORGANIZATION_ID_FULL
FROM batchmes.CONTACT_ALL_MV cam --ON r.MEMBERID=cam.CONTACT_ID AND cam.DISCHARGE_DATE IS NULL
JOIN LAUPADMIN.SUBDIVISION_MV sm ON cam.ORGANIZATION_ID_FULL=sm.OBJID AND cam.DISCHARGE_DATE IS NULL
LEFT JOIN IDB01.INTEGR_CHL_REF_EMP_MV icrem  ON cam.CONTACT_ID=cast(icrem.PERNR AS  integer) 
LEFT JOIN IDB01.INTEGR_CHL_EMP_LVLPK_MV icelm ON cast(icrem.INTEGR_CHL_REF_EMP_ID AS integer)=cast(icelm.INTEGR_CHL_REF_EMP_ID AS integer) 
                                        AND icelm.REF_INSP_LVLPK_ID=7