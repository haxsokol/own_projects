

SELECT 
 
to_date(DATE_OF_CALENDAR) AS "Date",
to_char(to_date(DATE_OF_CALENDAR), 'YYYY','nls_date_language=russian')||to_char(to_date(DATE_OF_CALENDAR), 'MM','nls_date_language=russian') "MonthAsInteger",
to_char(to_date(DATE_OF_CALENDAR), 'IYYY','nls_date_language=russian')||TO_CHAR(to_date(DATE_OF_CALENDAR),'IW') "Integer",

TO_CHAR(to_date(DATE_OF_CALENDAR),'YYYY') "Year",
TO_CHAR(to_date(DATE_OF_CALENDAR),'Q') "Quarter",
to_char(to_date(DATE_OF_CALENDAR), 'Month','nls_date_language=russian') "Месяц",
to_char(to_date(DATE_OF_CALENDAR), 'Month','nls_date_language=American') "Month",
to_char(to_date(DATE_OF_CALENDAR), 'MM','nls_date_language=russian') "MonthNo",
TO_CHAR(to_date(DATE_OF_CALENDAR),'MON.YY','nls_date_language=russian') "YearMonth",
TO_CHAR(to_date(DATE_OF_CALENDAR),'IW') AS "WeekNo",
INITCAP (TO_CHAR(to_date(DATE_OF_CALENDAR),'DAY','nls_date_language=russian')) "WeekDay",
TO_CHAR(to_date(DATE_OF_CALENDAR),'DY','nls_date_language=russian') "WeekDayShort",
TO_CHAR(to_date(DATE_OF_CALENDAR),'DD') "День месяца (1-31)",

TO_CHAR(to_date(DATE_OF_CALENDAR),'D','nls_date_language=russian') "День недели (1-7)",

TO_CHAR(to_date(DATE_OF_CALENDAR),'DDD','nls_date_language=russian') "День года (1-366)",
 
 NAME_OF_HOLIDAY  AS "Праздник",
 
	CASE WHEN TYPE_OF_DAY IN ('В','О') 
		THEN 0 ELSE 1 END "Рабочий_день(=1)",
	
	CASE WHEN TO_CHAR(to_date(SYSDATE),'MMYYYY') = TO_CHAR(to_date(DATE_OF_CALENDAR),'MMYYYY')
		THEN 'Текущий'ELSE INITCAP(to_char(to_date(DATE_OF_CALENDAR), 'Month','nls_date_language=russian')) END AS "Текущий_месяц",
		
	CASE WHEN TO_CHAR(to_date(SYSDATE),'IW') = TO_CHAR(to_date(DATE_OF_CALENDAR),'IW')
		THEN 'Текущая_неделя'ELSE TO_CHAR(to_date(DATE_OF_CALENDAR),'IW') END AS "Текущая_неделя",
		
	CASE  WHEN TO_CHAR(to_date(SYSDATE),'MMYYYY') = TO_CHAR(to_date(DATE_OF_CALENDAR),'MMYYYY')	THEN 'Текущий_месяц'
		WHEN to_date(DATE_OF_CALENDAR)-to_date(SYSDATE)<0  
		THEN 'Прошлое' ELSE 'Будущее' END AS "Период",
		to_char(to_date(DATE_OF_CALENDAR), 'IYYY','nls_date_language=russian')||TO_CHAR(to_date(DATE_OF_CALENDAR),'IW')||TO_CHAR(to_date(DATE_OF_CALENDAR),'DD') "Index",
 
			CASE  WHEN TO_CHAR(to_date(DATE_OF_CALENDAR),'D','nls_date_language=russian')=1 AND TO_CHAR(to_date(DATE_OF_CALENDAR),'DD')=1 THEN 1 
			ELSE 0 END AS PERHOD
		
 FROM LAUPADMIN.SPR_CALENDAR_ADM 
	WHERE TO_DATE(DATE_OF_CALENDAR) BETWEEN TO_DATE('2025-01-01','YYYY-MM-DD') AND SYSDATE
ORDER BY  DATE_OF_CALENDAR
