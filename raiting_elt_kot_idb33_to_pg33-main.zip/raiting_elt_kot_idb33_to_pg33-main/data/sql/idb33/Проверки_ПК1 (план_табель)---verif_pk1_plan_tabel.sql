WITH
Plan AS (
SELECT DISTINCT 
cast(replace(ztm.PERNR,':','') as numeric) PERNR
,ztm."DATA" 
,CASE 
	WHEN ztm.FACT_H>0
THEN 1
	ELSE 0
END AS PLAN
,cam.ORGANIZATION_ID_FULL OBJID
,TO_NUMBER(TO_NUMBER(cast(replace(ztm.PERNR,':','') as numeric))||to_char(to_date(ztm."DATA"), 'YYYY','nls_date_language=russian')||TO_NUMBER( to_char(to_date(ztm."DATA"), 'MM','nls_date_language=russian'))) AS TN_YEAR_MONTHS
,TO_NUMBER(cam.ORGANIZATION_ID_FULL||to_char(to_date(ztm."DATA"), 'YYYY','nls_date_language=russian')||TO_NUMBER( to_char(to_date(ztm."DATA"), 'MM','nls_date_language=russian'))) AS STRUCT_YEAR_MONTHS


FROM BATCHMES.ZHCMI896_TBT_MV ztm 
JOIN batchmes.CONTACT_ALL_MV cam ON ztm.PERNR=cam.CONTACT_ID 
								AND (cam.DISCHARGE_DATE IS null OR cam.DISCHARGE_DATE>=ztm."DATA")
								AND ztm.FACT_H BETWEEN 2 AND 12 --более 2ч факт.работы 
								AND TRUNC(ztm."DATA")>=TO_DATE('01.01.2024', 'dd.mm.yyyy') --данные с 01.01.2024
								AND TRUNC(ztm."DATA")<SYSDATE --в текущий день будет красный кружок
JOIN IDB01.INTEGR_CHL_REF_EMP_MV icrem  ON ztm.PERNR=icrem.PERNR
JOIN IDB01.INTEGR_CHL_EMP_LVLPK_MV icelm ON cast(icrem.INTEGR_CHL_REF_EMP_ID as integer)=cast(icelm.INTEGR_CHL_REF_EMP_ID as integer) 
                                        AND icelm.REF_INSP_LVLPK_ID=7 
					AND ((ztm."DATA" >= icelm.DATE_BEG AND icelm.DATE_END IS NULL ) OR (ztm."DATA" BETWEEN icelm.DATE_BEG AND icelm.DATE_END))
							and (ztm."DATA" not in (Date '2024-07-02', Date '2024-07-03')) --сбой в работе КОТа
		),		
		
GROUP_plan AS (SELECT 
	sum (PLAN) AS PLAN
	,OBJID
	,TN_YEAR_MONTHS
	,STRUCT_YEAR_MONTHS
	,PERNR
FROM Plan
GROUP BY OBJID, TN_YEAR_MONTHS, STRUCT_YEAR_MONTHS,PERNR)

SELECT * FROM 
Plan
--WHERE TN_YEAR_MONTHS IN (1006391320242)
--WHERE PERNR IN (10063913)
