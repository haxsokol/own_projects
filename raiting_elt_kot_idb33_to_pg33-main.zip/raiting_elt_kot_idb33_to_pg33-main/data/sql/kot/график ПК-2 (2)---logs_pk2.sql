WITH  
/*___ переводки основные и временные ____*/

FOREMAN AS (
SELECT distinct
"NHRS"."FIO_TN"||','||chr(10)||"PA0001".OBJID_A_NAME as "FIO_TN_PROF"
,"PA0001".STRUCT_ID
,case 
		when "PA0001".BEGDA<to_date('01.03.2024','dd.mm.yy')
then to_date('29.02.2024','dd.mm.yy') --меняем на дату начала действия рейтинга
	else "PA0001".BEGDA
end as BEGDA
,CASE 
	WHEN  "PA0001".ENDDA::date>now()::date 
		THEN now()::date
	WHEN  "PA0001".ENDDA::date<to_date('01.03.2024','dd.mm.yy') 
		THEN to_date('29.02.2024','dd.mm.yy')
ELSE "PA0001".ENDDA::date 
		END as ENDDA 
,"PA0001".OBJID_A::numeric as OBJID_A
,"PA0001".OBJID_A_NAME
,"PA0001".HRSROOT_ID
,"PA0001".PERNR
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"

left join 
	(select distinct 
		case 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
			||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
				||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
					||chr(10)||'('||HRSROOT_ID||')'
	else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||TN||')'
				end as"FIO_TN"
		,CASE 
			WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
		THEN HRSROOT_ID
			ELSE TN 
		END AS PERNR   
		FROM otpb.power_bi_nhrs_full_mv
		 where 
		(DATE_END::date>to_date('01012018','ddmmyyyy') or DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
		AND TYPE_WORKER NOT IN ('Ученичество','Практика')
		and (DATE_BEG::date<=now() and DATE_BEG>to_date('01012000','ddmmyyyy'))
		) "NHRS"
		on "NHRS".pernr="PA0001".PERNR

WHERE ("PA0001".MASSN_NAME NOT IN ('Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
	OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
	AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') 
	and ("PA0001".BEGDA::date<=now() and "PA0001".BEGDA::date>to_date('01012000','ddmmyyyy'))
	AND "PA0001".OBJID_A_NAME NOT IN ('Начальник участка а/м импорт пр-ва','Начальник участка (по вагонному парку)') 
	AND ("PA0001".OBJID_A_NAME LIKE ('%ач%цех%') 
	OR "PA0001".OBJID_A_NAME LIKE ('%ач%учас%') 
	OR "PA0001".OBJID_A_NAME LIKE ('Начальник%') 
	OR "PA0001".OBJID_A_NAME LIKE ('Начальник центр%') 
	OR "PA0001".OBJID_A_NAME LIKE ('Начальник отдела%') 
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник производственного комплекса%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Директор  рудоуправлени%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник ЦПТБД%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник лабора%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник складского комплекса%')
	OR "PA0001". OBJID_A_NAME LIKE ('Начальник складского хозяйства%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник производственного комплекса%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник произв%')
	OR "PA0001". OBJID_A_NAME LIKE ('Старший мастер складского б%')
	OR "PA0001". OBJID_A_NAME LIKE ('Старший мастер%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Руководитель ремонтной служ%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Директор фи%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Зам. начальник%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Заместитель начальника УГЭ%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Главный электрик ПАО "Северсталь"%')
	OR "PA0001". OBJID_A_NAME LIKE ('Начальник управ%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Директор пр%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Главный механик,01%')
	OR "PA0001". OBJID_A_NAME LIKE ('Исполнительный дир%')
	OR  "PA0001".OBJID_A_NAME LIKE ('Начальник МС,01%')
	)
	and "NHRS"."FIO_TN" is not null
			
UNION all--из НХРС начальники
select 
case 
	WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||"FULL".HRSROOT_ID||'),'
					||chr(10)||PROF_P
else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
	||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
		||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
			||chr(10)||'('||TN||'),'
				||chr(10)||PROF_P
	
	end as "FIO_TN_PROF"
,"FULL".STRUCT_ID
,"FULL".DATE_BEG::date as BEGDA
, CASE 
	WHEN  "FULL".DATE_END::date>now()::date	
		THEN now()::date
	WHEN  "FULL".DATE_END::date IS NULL AND "FULL".DATE_OF_DISMISSAL::date IS NOT NULL
		THEN "FULL".DATE_OF_DISMISSAL::date
	WHEN  "FULL".DATE_END::date IS NULL	
		THEN now()::date 
	ELSE "FULL".DATE_END::date 
		END as ENDDA
,case 
	when STRUCT_OBJID.OBJID::numeric is null
then "FULL".STRUCT_ID::numeric
	else STRUCT_OBJID.OBJID::numeric
end as OBJID_A
,PROF_P AS OBJID_A_NAME
	,"FULL".HRSROOT_ID
	,CASE 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	THEN "FULL".HRSROOT_ID
		ELSE TN 
	END AS PERNR   
	FROM otpb.power_bi_nhrs_full_mv "FULL"
left join otpb.idb33_struct_objid_mv STRUCT_OBJID
	on "FULL".struct_id=STRUCT_OBJID.struct_id
		 
left join (
SELECT distinct
"PA0001".HRSROOT_ID
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"
WHERE ("PA0001".MASSN_NAME NOT IN ('Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
	OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
	and ("PA0001".BEGDA::date<=now() and "PA0001".BEGDA::date>to_date('01012000','ddmmyyyy'))
	AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') 

) "PA001"
	on  "PA001".HRSROOT_ID="FULL".HRSROOT_ID

	where 
	("FULL".DATE_END::date>to_date('01012018','ddmmyyyy') or "FULL".DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
	AND TYPE_WORKER NOT IN ('Ученичество','Практика') 
	and ("FULL".DATE_BEG::date<=now() and "FULL".DATE_BEG>to_date('01012000','ddmmyyyy'))

	and	(PROF_P LIKE ('%ач%цех%') 
	OR PROF_P LIKE ('%ач%учас%') 
	OR PROF_P LIKE ('Начальник цент%') 
	OR PROF_P LIKE ('Начальник отдела%') 
	OR PROF_P LIKE ('Начальник%') 
	OR  PROF_P LIKE ('Начальник производственного компл%')
	OR  PROF_P LIKE ('Начальник произв%')
	OR  PROF_P LIKE ('Директор  БРУ%')
	OR  PROF_P LIKE ('Начальник ЦПТБД%')
	OR  PROF_P LIKE ('Начальник  лабора%')
	OR  PROF_P LIKE ('Начальник лабора%')
	OR  PROF_P LIKE ('Начальник складского комплекса%')
	OR  PROF_P LIKE ('Начальник складского хозяйства%')
	OR  PROF_P LIKE ('Начальник производственного комплекса%')
	OR  PROF_P LIKE ('Старший мастер складского блока%')
	OR  PROF_P LIKE ('Старший мастер%')
	OR  PROF_P LIKE ('Руководитель ремонтной службы%')
	OR  PROF_P LIKE ('Директор филиала%')
	OR  PROF_P LIKE ('Зам. начальник%')
	OR  PROF_P LIKE ('Начальник управ%')
	OR  PROF_P LIKE ('Директор пр%')
	OR  PROF_P LIKE ('Главный механик%')
	OR  PROF_P LIKE ('Начальник службы (главный метролог)%')
	OR  PROF_P LIKE ('Исполнительный дире%'))
	),
		

FOREMAN_PA002 AS --группирую формеман по должности без учета всех работников, вывожу struct_ID
	(SELECT STRUCT_ID, OBJID_A, OBJID_A_NAME FROM FOREMAN
	WHERE OBJID_A IS NOT null
	GROUP BY STRUCT_ID, OBJID_A, OBJID_A_NAME),
	
PEREVED_PA_2002 AS --переводки без оплаты
	(select distinct  
	FOREMAN_PA002.STRUCT_ID
	,case 
		when PA_0002.BEGDA::date<to_date('01.03.2024','dd.mm.yy')
then to_date('29.02.2024','dd.mm.yy') --меняем на дату начала действия рейтинга
	else PA_0002.BEGDA::date
end  as BEGDA
	,case 
		when PA_0002.ENDDA::date<to_date('01.03.2024','dd.mm.yy')
then to_date('29.02.2024','dd.mm.yy') --меняем на дату начала действия рейтинга
	else PA_0002.ENDDA::date
end  as ENDDA
	,FOREMAN_PA002.OBJID_A
	,FOREMAN_PA002.OBJID_A_NAME
	,PA_0002.PERNR
	FROM FOREMAN_PA002 
		LEFT JOIN otpb.idb33_pa2002_mv PA_0002 ON FOREMAN_PA002.OBJID_A::numeric =PA_0002.PLANS::numeric
		WHERE PA_0002.OTYPE IN ('A') AND PA_0002.PLANS NOT IN ('0')
		--AND PERNR IN (20002581)
	),
	
PEREVED_PA_2002_HRSROOT_ID AS --переводки без оплаты + привязка HRSROOT_ID, в той таблице нет	
	(select
	"NHRS"."FIO_TN"||' ,'||chr(10)||PEREVED_PA_2002.OBJID_A_NAME as "FIO_TN_PROF"
	,PEREVED_PA_2002.STRUCT_ID
	,PEREVED_PA_2002.BEGDA
	,PEREVED_PA_2002.ENDDA
	,PEREVED_PA_2002.OBJID_A
	,PEREVED_PA_2002.OBJID_A_NAME
	,PA_01.HRSROOT_ID
	,PEREVED_PA_2002.PERNR 
	FROM PEREVED_PA_2002
LEFT JOIN 
	(SELECT DISTINCT PA0001.PERNR, PA0001.HRSROOT_ID FROM  PEREVED_PA_2002
	LEFT JOIN  otpb.idb33_power_bi_pa0001_mv PA0001 ON PEREVED_PA_2002.PERNR=PA0001.PERNR) PA_01 /*внутри джоина отфилтровываю только нужные мне табльние из предыдущего же запроса PEREVED_PA_2002*/  
	ON PA_01.PERNR=PEREVED_PA_2002.PERNR
		left join 
	(select distinct 
case 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
			||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
				||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
					||chr(10)||'('||HRSROOT_ID||')'
	else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||TN||')'
				end as"FIO_TN"
		,CASE 
			WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
		THEN HRSROOT_ID
			ELSE TN 
		END AS PERNR   
		FROM otpb.power_bi_nhrs_full_mv
		 where 
		(DATE_END::date>to_date('01012018','ddmmyyyy') or DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
		AND TYPE_WORKER NOT IN ('Ученичество','Практика') ) "NHRS"
		on "NHRS".pernr=PEREVED_PA_2002.PERNR
where PA_01.HRSROOT_ID is not null
	union 
	select * from FOREMAN
	),

/*___________________ Определяем, назначен ли НЦ _____________________________________*/			
"41.Начальник цеха" as (
select distinct 
"E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табельный номер
                                  as "ФИО начальника" 
,"D1"."DepartmentName" as "Цех" -- Цех
,"Ref_OTV"."Name" as "Вид ответственности"
, case 
	when "E1"."PersonalNumber" like ('%:%')
	then substring("E1"."PersonalNumber" from 3 for position (':' in "E1"."PersonalNumber")+8) --для табельных с двоеточием отрезаем первую часть и двоеточие    
	else "E1"."PersonalNumber"
end as "TN"
,"importd"."ExternalId" as "OBJID"

from "EmployeeResponsibilityInDepartments" "ref_shop" --справочник ответственные лица

/*_____ связь для вывода ФИО начальников ____________________________*/  
	left join "Employees" as "E1" on "ref_shop"."EmployeeId"="E1"."Id"
	
/*_____ связь для вывода названия цехов ____________________________*/  	
	left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id"
	
/*_____ связь для вывода названия ответственности ____________________________*/  	
	left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" 

/*_____связь перекодировочной таблицы и единого справочника для получения "DepartmentId" по OBJID цехов____________________________*/  		
	left join "ImportDepartments" as "importd" on "importd"."DepartmentId"="ref_shop"."DepartmentId" -- связываем со справочником цехов  	  
	
	where "ref_shop"."ResponsibilityTypeId" in (61) --идентификатор 41. Начальник цеха
	--and "E1"."PersonalNumber" not like ('%:%')
	--and "ref_shop"."IsMain" in (true) --берем основные должности

	-- 30.10 неправильно был вбит НЦ Богомолов (10609496), убрал строку. Алгоритм проблемный - надо переписывать!
	AND "ref_shop"."Id" <> 8596
),
		
                               
/*___________________ Все проверки по аудитору____________________________________*/   
"PROVERKA" as (
select
	"REV"."Id" as "ID_PROVERKI"
	,'https://kot.severstal.com/revisions_severstal/card/'||"REV"."Id" as "LINK"
	,"EveI"."ExecutionDate"::date as "Дата Факт проверки"
	,case 
		when "E4"."PersonalNumber" is not null  and "E4"."PersonalNumber" like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
	then substring("E4"."PersonalNumber" from 3 for position (':' in "E4"."PersonalNumber")+8) --для табельных с двоеточием отрезаем первую часть и двоеточие    
		when "E4"."PersonalNumber" is not null  and "E4"."PersonalNumber" not like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
	then "E4"."PersonalNumber" --для табельных без двоеточия		
			when "E4"."PersonalNumber" is null  and "E3"."PersonalNumber" not like ('%:%') --если нет комиссии и аудитор без двоеточия
	then "E3"."PersonalNumber" --для табельных без двоеточия	
			else substring("E3"."PersonalNumber" from 3 for position (':' in "E3"."PersonalNumber")+8) --для табельных с двоеточием отрезаем первую часть и двоеточие    
	end as "Аудитор"
,case 
		when "REV"."RevisionTypeId" in (1)
	then 'ПАБ'
		when "REV"."GroupOfDirectionId" is null 
	then "DirInsp"."Name"
		when "GrDir"."Name" is null 
	then 'Нет направления'	
	else "GrDir"."Name"  
end  as "Направление проверки"
,EXTRACT(week from "EveI"."ExecutionDate"::date) as "№_недели"
,EXTRACT(month from "EveI"."ExecutionDate"::date) as "№_месяца"
,(to_char("EveI"."ExecutionDate"::date,'YYYY')::numeric)::text as "year"
,1 as "FACT"

from "Revisions" as "REV"

join "BusinessUnits" "BUS" -- предприятия
on "REV"."BusinessUnitId"="BUS"."Id" and "BUS"."IsActual"  IN (true)

left join "ExternalOrganizations" as "ExOrg" -- Проверяемая организация
on "REV"."ExternalOrganizationId"= "ExOrg"."Id" and "ExOrg"."IsActual"  IN (true)

left join "RevisionTypes" as "REV_TYP" -- виды проверок
on "REV"."RevisionTypeId"="REV_TYP"."Id" and "REV_TYP"."IsActual"  IN (true)

left join "Events" as "EveI" -- события для проверки
on "REV"."EventId"="EveI"."Id" and "EveI"."IsActual"  IN (true)

/*__Аудитор__*/	
left join "EventParticipants" as "EP3" 
	on "REV"."AuditorId"="EP3"."Id"  and "EP3"."IsActual" IN (true)

left join "Employees" as "E3" 
	on "EP3"."EmployeeId"="E3"."Id" and "E3"."IsActual" IN (true) -- Аудитор

left join "InternalEmployeePositionTypes" as "IEPT3" -- Назначение сотрудника
	on "E3"."Id"="IEPT3"."InternalEmployeeId" and "IEPT3"."IsActual" in (true)
	
left join "PositionTypes" as "PT3" -- место работы аудитора
	on "IEPT3"."PositionTypeId"="PT3"."Id" --and "PT3"."IsActual" in (true)
	
left join "PositionNames" as "PN3" -- должность аудитора	
	on "PT3"."PositionNameId" = "PN3"."Id" and  "PN3"."IsActual" in (true)
	
	/*___Аудитор__*/
left join "ExternalOrganizations" as "ExOrg_A" -- Подрядная организация аудитора
	on "E3"."ExternalOrganizationId"="ExOrg_A"."Id"and "ExOrg_A"."IsActual" IN (true)

/*_______ Привязываем комиссию, будем выводить председателя комиссии ___________*/
left join "CommissionParticipants_Revision" 
	on "REV"."Id"="CommissionParticipants_Revision"."RevisionId" 
		and "CommissionParticipants_Revision"."IsActual" IN (true) and "CommissionParticipants_Revision"."IsTheChair" IN (true)
		
/*_______ Расшифровываем председателя ___________*/
left join "CommissionParticipants" 
	on "CommissionParticipants_Revision"."CommissionParticipantId"="CommissionParticipants"."Id" 
		and "CommissionParticipants"."IsActual" IN (true)

/*_______  для табельного номера председателя ___________*/
left join "Employees" as "E4" 
	on "CommissionParticipants"."EmployeeId"="E4"."Id" and "E4"."IsActual" IN (true) -- Аудитор

/*_____________________________Направление Проверки_________________________________*/

left join public."DirectionsOfInspectionsAndAudits" as "DirInsp"-- справочник направлений проверки уровня группы
on "REV"."RevisionDirectionId"="DirInsp"."Id" --and "DirInsp"."IsActual" IN (true)

left join public."GroupOfDirections" as "GrDir" -- справочник направлений проверки дочерних записей
on "REV"."GroupOfDirectionId"="GrDir"."Id" --and "GrDir"."IsActual" IN (true)

WHERE "REV"."IsActual" IN (true)
and "REV"."RevisionTypeId" in (4)
--and "REV"."Id" IN (536640) --проверка на конкртеной Проверке
--and "ViEv"."EventId" =279376
and "EveI"."ExecutionDate"::date is not null -- с фактом проведения проверки
and "EveI"."EndingDate">=to_date('01012025','ddmmyyyy') -- только с этого года
and "GrDir"."Name" in ('Лидерский обход') --нужно только это направление проверки
--and ("E3"."PersonalNumber" not like ('1:%') or "E4"."PersonalNumber" not like ('1:%'))
),
/*___________________ генерация виртуального календаря_____________________________________*/		
"CALENDAR" as (SELECT 	
r::date AS "Date"
	,EXTRACT(DAY  from r) as "Число"
	,EXTRACT(ISODOW from r) as "№_дня_недели"
	,((date_trunc('month',r) + interval '1 month') - interval '1 day')::date as "LAST_DAY"
	,date_trunc('month',r) ::date as "FIRST_DAY"
	,(to_char(r,'YYYY')::numeric)::text||(to_char(r,'MM')::numeric)::text as "YEAR_MONTHS"
,EXTRACT(WEEK FROM r) as "№_Week"
,(to_char(r,'YYYY')::numeric)::text||EXTRACT(WEEK FROM r) "Integer"
		FROM generate_series('2025-01-01',now()::date, '1 day') as r
			),
			
"SHOP" as (select 
	"Documents"."Name"
	,"Documents"."DocStartDate"::date as "DS"
	,case 
		when "Documents"."DocEndDate" is null then now()::date
		else "Documents"."DocEndDate"::date
	end as "DE"
	,"Documents"."Number"
	,"D1"."DepartmentName"
	,"Documents"."Code" --идентификтор предка
from "Documents" as "Documents" 
left join "ImportDepartments" as "importd"  on "Documents"."Number"::integer="importd"."ExternalId"::integer -- цех OBJID цехов	
left join "Departments" as "D1" on "D1"."Id"="importd"."DepartmentId"

where 
	"Description" IN ('Рейтинг цеха')
	and "Documents"."IsActual" in (true)
	--and "Documents"."Number" in ('20052525') --тест на цехе
	) ,
                               
"STRUCT_SHOP" as (
select distinct
	"CALENDAR"."Date"::date as "CALENDAR_DATE"
	,"DepartmentName" as "Цех"
	,"Number"||EXTRACT(year FROM "CALENDAR"."Date"::date)||EXTRACT(Month FROM "CALENDAR"."Date"::date) as "STRUCT_YEAR_MONTH"
	,"Number" as "OBJID"
from  "CALENDAR",   "SHOP" 
/*___________________ объединени двух таблиц_____________________________________*/		          
where "CALENDAR"."Date" between "SHOP"."DS" and "SHOP"."DE"
),

/*___________________ генерация виртуального календаря по одной на каждую неделю_____________________________________*/	
"CALENDAR_week" as (
	SELECT 	distinct 
	r::date as "DATE"
	,EXTRACT(week from r) as "№_недели"
	,EXTRACT(month from r) as "№_месяца"
	,EXTRACT(year from r) as "YEAR"
	,date_trunc('week',r) ::date as "FIRST_DAY_week"
	,((date_trunc('week',r) + interval '1 week') - interval '1 day')::date as "LAST_DAY_week"
	,date_trunc('month',r) ::date as "FIRST_DAY_month"
	FROM generate_series('2025-01-01',now()::date, '1 day') as r	
		),

/*___________________ вычисление плана ПК-2 _____________________________________*/			
"PLAN" as (
select 
"STRUCT_YEAR_MONTH"::numeric
--,"№_недели" as "№_недели_PLAN"
,"№_месяца" as "№_месяца_PLAN"
,"YEAR" as "YEAR_PLAN"
,2 as "PLAN"
from "STRUCT_SHOP", "CALENDAR_week"
where "CALENDAR_week"."FIRST_DAY_month"="STRUCT_SHOP"."CALENDAR_DATE"
and not ("№_недели"=1 and "№_месяца"=12 and "YEAR"=2024)
and not ("№_недели"=1 and "№_месяца"=1 and "YEAR"=2025)
group by "STRUCT_YEAR_MONTH","№_месяца_PLAN","YEAR_PLAN"
),

"PK_2_DETAL" as (
select
"PROVERKA".*
,("Аудитор"::integer)::text||"year"::text||"№_недели"::text as "TN_YEAR_MONTHS"
from "PROVERKA" 
where "Аудитор" is not null
),


"ITOG" as (
select distinct 
"PK_2_DETAL".*
,"41.Начальник цеха"."OBJID"
,(("41.Начальник цеха"."OBJID"::integer)::text||"year"||"№_месяца")::numeric as "STRUCT_YEAR_MONTH"
from "PK_2_DETAL"

/*___________________ соединяю с переводками на должность не кот _____________________________________*/		
left join "41.Начальник цеха" on "41.Начальник цеха"."TN"::integer="PK_2_DETAL"."Аудитор"::integer

where "41.Начальник цеха"."OBJID" is not null
--and "Аудитор" in (3573886)
),


"PK_2_WEEK" as (
select distinct 
"PLAN"."STRUCT_YEAR_MONTH"
,"OBJID"::numeric
,"№_месяца"
,"№_недели"
,"№_месяца_PLAN"
,"year"
,"Направление проверки"

--количество проверок внутри одной недели
,"PLAN"."PLAN"
,case 
	when "FACT">0
		then 1
	else 0
end as "FACT"

from "PLAN"

left join "ITOG" 
	on "ITOG"."STRUCT_YEAR_MONTH"="PLAN"."STRUCT_YEAR_MONTH"
),

"PK_2_MONTH" as (
select  
"STRUCT_YEAR_MONTH"
,max("PLAN") as "PLAN"
,case 
	when sum("FACT") is null
		then 0
	else sum("FACT")
end as "FACT"
,case 
	when sum("FACT")>1
		then 1
	else 0
end as "PLAN_FACT"


from "PK_2_WEEK"
group by "STRUCT_YEAR_MONTH"
)

select * from "PK_2_MONTH" 
--where "STRUCT_YEAR_MONTH" in (401319820251)
--where "Аудитор" in (10608478)