select 
distinct  
 s."ShiftLogId" --Id журнала 
,case 
	when s."StartDateTime"::time<sl."TimeDay"-interval '1' hour then "StartDateTime"::date-interval '1' day else "StartDateTime"::date end "StartDateTime"  --Время приёма смены
,case 
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  
	(s."StartDateTime"::time>=sl."TimeNight"-interval '1' hour or s."StartDateTime"::time<sl."TimeDay"-interval '1' hour) --интервал между началами смены со сдвигом на час назад (те, кто пришел раньше и заполнил)
	then 'ночь' 
	else 'день' 
	end "смена"
from 
public."Shifts" s 
join public."ShiftLogs" sl on s."ShiftLogId"=sl."Id" 
join public."ShiftEquipment" se on s."Id"=se."ShiftId" 
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true
where sl."IsActual"=true