/*______ показатель в рейтинге цехов 2.0 №8 Проекты ОТиПБ  ______________*/	 
WITH

"№8 ОТиПБ" as (
select 
	"AC"."Id" as "CardId"
	,'https://kot.severstal.com/audits_industry/card/'||"AC"."Id" as "LinkCard"
	,"FinalScore"*20/100 as "Ball"
	,"ExecutionDate" as "Дата аудита (выполнения)"
	,EXTRACT(day FROM "ExecutionDate"::date)<11
	,EXTRACT(day FROM "ExecutionDate"::date)
	,EXTRACT(Month FROM "ExecutionDate"::date)-1
	,case 
		when EXTRACT(day FROM "ExecutionDate"::date)<11 and EXTRACT(Month FROM "ExecutionDate"::date)>1--при внесении даты Аудита до 10 числа включительно текущего месяца и это не январь, тогда переносим оценку на предыдущий месяц
	then (EXTRACT(year FROM "ExecutionDate"::date)||'.'||EXTRACT(Month FROM "ExecutionDate"::date)-1||'.'||'15')::date --перенос на 15 число предыдущего месяца
		when EXTRACT(day FROM "ExecutionDate"::date)<16 and EXTRACT(Month FROM "ExecutionDate"::date)=1--при внесении даты Аудита до 15 января включительно, тогда переносим оценку на декабрь предыдущего года
	then (EXTRACT(year FROM "ExecutionDate"::date)-1||'.'||'12'||'.'||'15')::date --перенос на 15 января предыдущего года
		when EXTRACT(day FROM "ExecutionDate"::date)>10 and EXTRACT(Month FROM "ExecutionDate"::date)>1--при внесении даты Аудита после 10 числа текущего месяца и это не январь, тогда оставляем оценку на текущем месяце
	then (EXTRACT(year FROM "ExecutionDate"::date)||'.'||EXTRACT(Month FROM "ExecutionDate"::date)||'.'||'15')::date --перенос на 15 число текущего месяца
		when EXTRACT(day FROM "ExecutionDate"::date)>15 and EXTRACT(Month FROM "ExecutionDate"::date)=1--при внесении даты Аудита после 15 января включительно, тогда оставляем оценку на текущем месяце
	then (EXTRACT(year FROM "ExecutionDate"::date)||'.'||EXTRACT(Month FROM "ExecutionDate"::date)||'.'||'15')::date --перенос на 15 число текущего месяца и года
		else "ExecutionDate"
	end as "Дата учета в рейтинге"
	,"DepartmentName"
	,"import"."ExternalId" as "OBJID"
   ,case 
  	 when 
   "E1"."Discriminator" in ('ExternalEmployee')
   then     "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                          		||', '||"E1"."Position"  -- должность    
   
 	else     "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                          		||', '||"PN1"."Name" -- должность                       
                          		
                       end   		as "АУДИТОР" 

    FROM "AuditIndustryCards" as "AC"

/* _______________ Связь с событиями __________________________*/  
left join "Events" as "EV" -- Событие к аудиту
       on "AC"."EventId"="EV"."Id"
       
/* _______________ Для определения вида аудита и фильтра по нему __________________________*/  
left join "AuditIndustryKinds" as "AIK"--Вид аудита
       on "AC"."AuditKindId"= "AIK"."Id" and "AIK"."IsActual" in (true)
       
/* _______________ Связь с подразделениями __________________________*/  
left join "EventDepartments" as "ED" -- Событие к аудиту
       on "ED"."EventId"="EV"."Id"
       
 /* _______________Место проведения Аудита__________________________*/
join "Departments" as "D"
       on "ED"."DepartmentId"="D"."Id"      

/* _______________ перекодировочная для OBJID цехов __________________________*/     
left join "ImportDepartments" as "import"  
on "D"."Id"::integer="import"."DepartmentId"::integer -- цех OBJID цехов	*/       
  
/* _______________ Связываем с таблицей задействованные лица __________________________*/  
left join "InvolvedAuditIndustry" as "STAK"--задействованные лица
       on "AC"."Id"= "STAK"."AuditIndustryCardId" 
       and "STAK"."IsActual" in (true)  and     "STAK"."TypeOfInvolved"=0 --берем только актульные записи и только аудиторов (0), если 1 - соаудиторы

/* _______________ Связываем с расшифровкой задействованные лица. вытаскиваем ИД аудитора __________________________*/  
left join "EventParticipants" as "UCHASTNIK_AUDITOR"--задействованные лица
       on "STAK"."EventParticipantId"= "UCHASTNIK_AUDITOR"."Id" 
       and "UCHASTNIK_AUDITOR"."IsActual" in (true) --берем только актульные записи

/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/  
left join "Employees" as "E1" --задействованные лица
       on "UCHASTNIK_AUDITOR"."EmployeeId"= "E1"."Id" 
       and "E1"."IsActual" IN (true) --берем только актульные записи      
  
left join "InternalEmployeePositionTypes" as "IEPT1" -- Назначение сотрудника
	on "E1"."Id"="IEPT1"."InternalEmployeeId" and "IEPT1"."IsActual" in (true)
	
left join "PositionTypes" as "PT1" -- место работы аудитора, связь
	on "IEPT1"."PositionTypeId"="PT1"."Id" --and "PT3"."IsActual" in (true)
 
left join "PositionNames" as "PN1" -- должность аудитора	
	on "PT1"."PositionNameId" = "PN1"."Id" and  "PN1"."IsActual" in (true)

WHERE "AC"."IsActual" IN (true) --только актуальные записи
and "GroupOfDirectionId" in (108)  --Проекты по ОТ и ПБ

-- 21.07.2025 добавление условия, чтобы не учитывались аудиты подрядчикам
AND "AC"."IsContractor" <> TRUE
)

select 
"CardId"
,"LinkCard"
,"Ball"
,"Дата аудита (выполнения)"
,"Дата учета в рейтинге"
,"DepartmentName"
	,"OBJID"||EXTRACT(year FROM "Дата учета в рейтинге"::date)||EXTRACT(Month FROM "Дата учета в рейтинге"::date) as "STRUCT_YEAR_MONTH"
, "АУДИТОР" 
from "№8 ОТиПБ" 