
WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" in (true)
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),


"SHOP" as (
select 
	"Documents"."Name"
	,"Documents"."DocStartDate"::date as "DS"
	,case 
		when "Documents"."DocEndDate" is null then now()::date
		else "Documents"."DocEndDate"::date
	end as "DE"
	,"Documents"."Number"
	,"D1"."DepartmentName"
	,"Documents"."Code" --идентификтор предка
	,"REKURS"."MANUFACTURE"
	,"REKURS"."MANUF_ID"
	,"REKURS"."COMPANY"
	,"REKURS"."DIVISION"
	,"REKURS"."WORKS_OBJID"
	,"REKURS"."OBJID"
	,"REKURS"."L_REITING"
	
from "Documents" as "Documents" 
left join "ImportDepartments" as "importd"  on "Documents"."Number"::integer="importd"."ExternalId"::integer -- цех OBJID цехов	
left join "Departments" as "D1" on "D1"."Id"="importd"."DepartmentId"
left join "REKURS" on "REKURS"."L_REITING"::integer="Documents"."Number"::integer
where 
	"Description" IN ('Рейтинг цеха')
	and "Documents"."IsActual" in (true)
	) ,
	
/*___________________ генерация виртуального календаря_____________________________________*/		
CALENDAR as (SELECT * FROM generate_series('2023-01-01',
                               now()::date, '1 month') as r),
STRUCTURA as  (                          
select distinct
	CALENDAR."r"::date as "CALENDAR_DATE"
	,"DepartmentName" as "Цех"
	,"Number"
	,("Number"||EXTRACT(year FROM CALENDAR."r"::date)||EXTRACT(Month FROM CALENDAR."r"::date))::numeric as "STRUCT_YEAR_MONTH"
	,(("SHOP"."OBJID"::numeric)::text||EXTRACT(year FROM CALENDAR."r"::date)||EXTRACT(Month FROM CALENDAR."r"::date))::numeric as "OBJID_YEAR_MONTH"
	,case 
		when "SHOP"."MANUF_ID" in (30297) --принудительно переношу цеха ЯГОКа из ПАО обратно в ЯГОК
	then 'ЯГОК'
		else "SHOP"."DIVISION"
	end as "DIVISION"
	,"SHOP"."MANUFACTURE"
	,"SHOP"."WORKS_OBJID"::numeric
	,"SHOP"."OBJID"::numeric
	,"SHOP"."COMPANY"

from  CALENDAR,   "SHOP" 
/*___________________ объединени двух таблиц_____________________________________*/		          
where CALENDAR."r" between "SHOP"."DS" and "SHOP"."DE"
),

TESTS as (
SELECT 
year
,MONTH
,case 
	when OBJID is null
then struct_id_old
	else  OBJID
end AS "OBJID"
,count(distinct PERSONAL_NUMBER) AS "COUNT_PERS"
,case 
	when svetofor in (2,3)
then	count (distinct personal_number)  
	else 0
end AS "COUNT_IN_ZONA"
,svetofor
,"name"
,case 
	when OBJID is null
then (struct_id_old::text||YEAR::text||(MONTH::numeric)::text)::numeric 
	else(OBJID::text||YEAR::text||(MONTH::numeric)::text)::numeric 
end AS "OBJID_YEAR_MONTH"

FROM otpb.idb33_tests_mv tests
where (NON in ('В рейтинге') OR NON IS NULL)
--and OBJID in (30026)
group BY YEAR,MONTH,OBJID,svetofor,"name",struct_id_old

),

"ITOG" as (
select 
TESTS.year
,TESTS.month
--,TESTS."OBJID"
--,tests."OBJID_YEAR_MONTH"
,sum(TESTS."COUNT_PERS") as "COUNT_PERS"
,sum(TESTS."COUNT_IN_ZONA") as "COUNT_IN_ZONA"
,STRUCTURA."STRUCT_YEAR_MONTH"
,CASE 
	WHEN (sum(TESTS."COUNT_IN_ZONA")*10/sum(TESTS."COUNT_PERS"))>=9 THEN 10
		ELSE ROUND(sum(TESTS."COUNT_IN_ZONA")*10/sum(TESTS."COUNT_PERS"))
	END AS "ITOG"  --если 90, то приравнивать к 100*/
from TESTS
left join STRUCTURA on STRUCTURA."OBJID_YEAR_MONTH"=tests."OBJID_YEAR_MONTH"
where STRUCTURA."STRUCT_YEAR_MONTH"  is not null 
--and STRUCTURA."STRUCT_YEAR_MONTH" in ('400475220248')
group BY YEAR,MONTH,STRUCTURA."STRUCT_YEAR_MONTH"--,TESTS."OBJID",tests."OBJID_YEAR_MONTH"
)

select * from "ITOG"