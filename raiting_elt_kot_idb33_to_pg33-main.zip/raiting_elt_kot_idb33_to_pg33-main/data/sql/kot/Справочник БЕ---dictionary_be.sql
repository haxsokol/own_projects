select distinct
"Id" as "Location_Id"
,"Name" as "Location_Name"
from "Locations" 
where "Locations"."IsActual" IN (true)