
WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" = true
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),
/*___ переводки основные и временные ____*/
FOREMAN AS (
SELECT distinct
"NHRS"."FIO_TN"||','||chr(10)||"PA0001".OBJID_A_NAME as "FIO_TN_PROF"
,"PA0001".STRUCT_ID
,"PA0001".BEGDA::date as BEGDA
,CASE 
	WHEN  "PA0001".ENDDA::date>now()::date 
		THEN now()::date
	ELSE "PA0001".ENDDA::date
		END as ENDDA
,"PA0001".ORGEH::numeric as OBJID_A
,"PA0001".OBJID_A_NAME
,"PA0001".HRSROOT_ID
,"PA0001".PERNR
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"

left join 
	(select distinct 
case 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
			||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
				||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
					||chr(10)||'('||HRSROOT_ID||')'
	else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||TN||')'
				end as"FIO_TN"
		,CASE 
			WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
		THEN HRSROOT_ID
			ELSE TN 
		END AS PERNR   
		FROM otpb.power_bi_nhrs_full_mv
		 where 
		(DATE_END::date>to_date('01012025','ddmmyyyy') or DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
		AND TN>100000
		) "NHRS"
		on "NHRS".pernr="PA0001".PERNR

WHERE "NHRS"."FIO_TN" is not null
		
UNION all--из НХРС начальники
select 
case 
	WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||"FULL".HRSROOT_ID||'),'
					||chr(10)||PROF_P
else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
	||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
		||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
			||chr(10)||'('||TN||'),'
				||chr(10)||PROF_P
	
	end as "FIO_TN_PROF"
,"FULL".STRUCT_ID
,"FULL".DATE_BEG::date as BEGDA
, CASE 
	WHEN  "FULL".DATE_END::date>now()::date	
		THEN now()::date
	WHEN  "FULL".DATE_END::date IS NULL AND "FULL".DATE_OF_DISMISSAL::date IS NOT NULL
		THEN "FULL".DATE_OF_DISMISSAL::date
	WHEN  "FULL".DATE_END::date IS NULL	
		THEN now()::date 
	ELSE "FULL".DATE_END::date 
		END as ENDDA
,STRUCT_OBJID.OBJID::numeric  as OBJID_A
,PROF_P AS OBJID_A_NAME
	,"FULL".HRSROOT_ID
	,CASE 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	THEN "FULL".HRSROOT_ID
		ELSE TN 
	END AS PERNR   
	FROM otpb.power_bi_nhrs_full_mv "FULL"
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
	on "FULL".STRUCT_ID=STRUCT_OBJID."struct_id"
		 
left join (
SELECT distinct
"PA0001".HRSROOT_ID
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"
	) "PA001"
	on  "PA001".HRSROOT_ID="FULL".HRSROOT_ID
	where 
	("FULL".DATE_END::date>to_date('01012025','ddmmyyyy') or "FULL".DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
	and "PA001".HRSROOT_ID is null
	),


	/* _____ соединяем с перекодировочной struct_id и OBJID    _____  */
"FOREMAN_OBJID" as (
select FOREMAN.*
,case 
	when STRUCT_OBJID.OBJID is null
then STRUCT_OBJID.struct_id
	else  STRUCT_OBJID.OBJID
end as "OBJID"
,"REKURS"."L_REITING"::numeric  as "OBJID_Цех"
,"REKURS"."WORKSHOPS" as "Цех"
from FOREMAN
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
	on FOREMAN.STRUCT_ID=STRUCT_OBJID."struct_id"

/*_________ связь с рекурсией для вывода цеха Аудитора  ________________*/
left join "REKURS"  -- 
	on "REKURS"."OBJID"::numeric =STRUCT_OBJID.OBJID::numeric	
	where FOREMAN.PERNR>0
	--and FOREMAN.PERNR in (10608275) --тест
),

"FULL_PROV" as (
select
	"REV"."Id"
	
,CASE 
    WHEN "REV"."RevisionTypeId" = 1 THEN "EveI"."BeginDate"::date
    ELSE COALESCE("EveI"."ExecutionDate", "EveI"."EndingDate", "EveI"."BeginDate")::date
END AS "DATE"
	
	
/*________________________Персонал__________________________________________________*/	


,CASE 
    WHEN "REV"."AuditorId" IS NOT NULL THEN CONCAT_WS(
        '',
        "E3"."LastName", ' ',
        SUBSTRING("E3"."FirstName" FROM 1 FOR 1), '. ',
        COALESCE(SUBSTRING("E3"."SecondName" FROM 1 FOR 1) || '. ', ''),
        CHR(10), '(',
        COALESCE("E3"."PersonalNumber", "ExOrg_A"."Name"), ')',
        COALESCE(',' || CHR(10) || COALESCE("E3"."Position", "PN3"."Name"), '')
    )
    ELSE 'Комиссия'
END AS "Аудитор"

,CASE 
    WHEN "E3"."PersonalNumber" LIKE '%:%' THEN 
        COALESCE(
            SUBSTRING("E3"."PersonalNumber" FROM '[^:]*$'), -- Извлекаем часть после двоеточия
            "ExOrg_A"."Name"
        )
    ELSE 
        "E3"."PersonalNumber"
END AS "TN_Auditor"

	
/*___________________ Несоответствия к проверке_____________________________________*/	
	,"ViEv"."EventId" as "ID_несоответсвия"
	,'https://kot.severstal.com/revisions_severstal/violation_event/'||"ViEv"."EventId" as "LINK_V"
	,"BPSJ"."Name" as "БПСЖ"
	
,CONCAT_WS(
    '',
    "E4"."LastName", ' ',
    SUBSTRING("E4"."FirstName" FROM 1 FOR 1), '. ',
    COALESCE(SUBSTRING("E4"."SecondName" FROM 1 FOR 1) || '. ', ''),
    CHR(10), '(',
    COALESCE("E4"."PersonalNumber", "ExOrg_WN"."Name"), ')'
) AS "Допустивший нар."
				
,CASE 
    WHEN "E4"."PersonalNumber" LIKE '%:%' THEN 
        SUBSTRING("E4"."PersonalNumber" FROM '[^:]*$') -- Извлекаем часть после двоеточия
    ELSE 
        "E4"."PersonalNumber"
END AS "TN_Допустивший"

	,"PT4"."DepartmentId" as "Depart_Проверяемый"
	,"PT3"."DepartmentId" as "Depart_Аудитора"
	
	from public."Revisions" as "REV"

left join "Events" as "EveI" -- события для проверки
on "REV"."EventId"="EveI"."Id" and "EveI"."IsActual"  IN (true)

/*_____________________________Направление Проверки_________________________________*/


left join "GroupOfDirections" as "GrDir" -- справочник направлений проверки дочерних записей
on "REV"."GroupOfDirectionId"="GrDir"."Id" and "GrDir"."IsActual" IN (true)

/*__Аудитор__*/	
left join "EventParticipants" as "EP3" 
	on "REV"."AuditorId"="EP3"."Id"  and "EP3"."IsActual" IN (true)

	left join "Employees" as "E3" 
	on "EP3"."EmployeeId"="E3"."Id" and "E3"."IsActual" IN (true) -- Аудитор

left join "InternalEmployeePositionTypes" as "IEPT3" -- Назначение сотрудника
	on "E3"."Id"="IEPT3"."InternalEmployeeId" and "IEPT3"."IsActual" in (true)
	
left join "PositionTypes" as "PT3" -- место работы аудитора
	on "IEPT3"."PositionTypeId"="PT3"."Id" --and "PT3"."IsActual" in (true)
	
left join "PositionNames" as "PN3" -- должность аудитора	
	on "PT3"."PositionNameId" = "PN3"."Id" and  "PN3"."IsActual" in (true)

left join "ExternalOrganizations" as "ExOrg_A" -- Подрядная организация аудитора
	on "E3"."ExternalOrganizationId"="ExOrg_A"."Id"and "ExOrg_A"."IsActual" IN (true)
	
/*_______________________Место проведения проверки_________________________________*/	
left join "RevisionDepartments" as "RevDE" --Отдел проверки
	on "REV"."Id"="RevDE"."RevisionId" and "RevDE"."IsActual" IN (true)


left join "RevisionDepartments_ViolationEvents" as "Rev_Viol" --Отдел нарушения в проверке
	on "RevDE"."Id"="Rev_Viol"."RevisionDepartmentId"  and "Rev_Viol"."IsActual" IN (true)

/*___________________ Несоответствия к проверке_____________________________________*/	
left join "ViolationEvents" as "ViEv" -- Нарушение
	on "Rev_Viol"."ViolationEventId" = "ViEv"."Id" and "ViEv"."IsActual" IN (true)

left join "ViolationEventBasicRules" as "ViBaRU" --Связь нарушения с БПСЖ
	on "ViEv"."Id"= "ViBaRU"."ViolationEventId" and "ViBaRU"."IsActual" IN (true)

left join "BasicRules" as "BPSJ" --БПСЖ
	on "ViBaRU"."BasicRuleId"="BPSJ"."Id" 
	--and "BPSJ"."IsActual"IN (true) 
	and "BPSJ"."Id"<>39


/*___________________Допустивший несоответствие_____________________________________*/	
left join "EventParticipants" as "EP4" --Участник события
	on "ViEv"."EventId"="EP4"."EventId" and "EP4"."IsActual" IN (true) and "EP4"."ParticipantType"=4 -- 4 - нарушитель

left join "Employees" as "E4" 
	on "EP4"."EmployeeId"="E4"."Id" and "E4"."IsActual" IN (true)

left join "InternalEmployeePositionTypes" as "IEPT4" -- Назначение сотрудника
	on "E4"."Id"="IEPT4"."InternalEmployeeId" and "IEPT4"."IsActual" in (true)
	
left join "PositionTypes" as "PT4" -- место работы допустившего несоответствие
	on "IEPT4"."PositionTypeId"="PT4"."Id" --and "PT4"."IsActual" in (true)
	
left join "ExternalOrganizations" as "ExOrg_WN" -- Подрядная допустившего несоответствие
	on "E4"."ExternalOrganizationId"="ExOrg_WN"."Id" and "ExOrg_WN"."IsActual" IN (true)


WHERE "EveI"."EndingDate">=to_date('01012025','ddmmyyyy')
and "REV"."RevisionTypeId" in (1)
and "REV"."IsActual" IN (true)
and "BPSJ"."Id" is not null
--and "CommissionId" is not null
--and "REV"."Id" IN (848162)    --тест на кокретной проверке
--and "ViEv"."EventId" =940416

and ("GrDir"."Id"not in (8) or "GrDir"."Id" is null) --ПК супервайзеры, Группа по развитию подрядных организаций
),

/*___________________ Ответственные лица. МУПРы_____________________________________*/    
"MUPR" as (
select 
       "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                  as "ФИО МУПР" 
       ,"D1"."DepartmentName" as "Цех" -- Цех
       ,"ref_shop"."DepartmentId" as "ID_SHOP_MUPR" --идентификатор цеха
 	,"REKURS"."OBJID"::numeric as "OBJID"
	,"REKURS"."WORKS_OBJID"::numeric as "MUPR_OBJID_Цех"
	,"REKURS"."WORKSHOPS" as "MUPR_Цех"
  ,case 
       when "E1"."PersonalNumber" like ('%:%')
then (substring("E1"."PersonalNumber" from 3 for position (':' in "E1"."PersonalNumber")+10))::numeric
       else "E1"."PersonalNumber"::numeric
end as "TN_MUPR"

from "EmployeeResponsibilityInDepartments" "ref_shop"

left join "Employees" as "E1" on "ref_shop"."EmployeeId"="E1"."Id" --ФИО начальника цеха
left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id" -- цех
left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" -- название ответственности 
left join "REKURS" on "ref_shop"."DepartmentId"="REKURS"."ID_KOT"  -- связь с рекурсией для вывода OBJID
where "ResponsibilityTypeId" in (106)
and "ref_shop"."IsActual" IN (true)
--and "E1"."PersonalNumber" in ('10619535')
),

"ITOG_BPSJ" as (
select  
	"Id" as "Id проверки"
	,"ID_несоответсвия"
	,"FULL_PROV"."БПСЖ"
	,"FULL_PROV"."DATE"
	,"FULL_PROV"."Допустивший нар."
	,"FULL_PROV"."Аудитор"
	,"FULL_PROV"."TN_Auditor"
	,"FULL_PROV"."LINK_V"
	,"FULL_PROV"."TN_Допустивший"
	,"FOREMAN_OBJID"."FIO_TN_PROF" as "Допустивший_FIO_TN_PROF"
	,"FOREMAN_OBJID"."OBJID_Цех" as "Допустивший_OBJID_Цех"
	,"FOREMAN_OBJID"."Цех" as "Допустивший_Цех"
	,"FOREMAN_OBJID2"."FIO_TN_PROF" as "Аудитор_FIO_TN_PROF"
	,"FOREMAN_OBJID2"."OBJID_Цех" as "Аудитор_OBJID_Цех"
	,"FOREMAN_OBJID2"."Цех" as "Аудитор_Цех"
	,("FOREMAN_OBJID"."OBJID_Цех"::text||EXTRACT(year FROM "FULL_PROV"."DATE"::date)||EXTRACT(Month FROM "FULL_PROV"."DATE"::date))::numeric as "STRUCT_YEAR_MONTH"	
	,"MUPR"."MUPR_OBJID_Цех" 
	,"MUPR"."TN_MUPR" 
	,"MUPR"."MUPR_Цех" as  "Цех_МУПР"
	,case 
		when "FULL_PROV"."TN_Auditor"::numeric="MUPR"."TN_MUPR"::numeric --если аудитором был свой мупр
	then 1
		when "FOREMAN_OBJID"."OBJID_Цех"="FOREMAN_OBJID2"."OBJID_Цех"
	then 1
		else 0 end as "Внутренние_БПСЖ"
	,case
		when "FULL_PROV"."TN_Auditor"::numeric="MUPR"."TN_MUPR"::numeric  --если аудитором был свой мупр
	then 0
		when "FOREMAN_OBJID"."OBJID_Цех"="FOREMAN_OBJID2"."OBJID_Цех"
	then 0
		else 1 end as "Внешние_БПСЖ"
	
from "FULL_PROV"
	
/*_________ связь с Допустившим нарушение на момент нарушения ________________*/
left join "FOREMAN_OBJID" -- место работы Допустившего нарушение связь с рекурсией для вывода OBJID урвня цеха
	on "FOREMAN_OBJID".PERNR::numeric ="FULL_PROV"."TN_Допустивший"::numeric
		and "FULL_PROV"."DATE" between  "FOREMAN_OBJID".BEGDA and "FOREMAN_OBJID".ENDDA

		/*_________ связь с Аудитором на момент нарушения ________________*/
left join "FOREMAN_OBJID" as "FOREMAN_OBJID2" -- место работы Допустившего нарушение связь с рекурсией для вывода OBJID урвня цеха
	on "FOREMAN_OBJID2".PERNR::numeric ="FULL_PROV"."TN_Auditor"::numeric
		and "FULL_PROV"."DATE" between  "FOREMAN_OBJID2".BEGDA and "FOREMAN_OBJID2".ENDDA

/*_________ связь с МУПРами   ________________*/
left join "MUPR" -- выводим при совпадении цеха МУПРа и табельного номера МУПРа с цехом Проверяемого и табельного номера Аудитора
on "MUPR"."MUPR_OBJID_Цех"::text||"TN_MUPR"::text="FOREMAN_OBJID"."OBJID_Цех"::text||("FULL_PROV"."TN_Auditor"::numeric)::text  	
		
		where "БПСЖ" is not null
and "Depart_Проверяемый" is not null
)

select * from "ITOG_BPSJ"
where  "STRUCT_YEAR_MONTH"	 is not null
--and "Id проверки" in (344617)