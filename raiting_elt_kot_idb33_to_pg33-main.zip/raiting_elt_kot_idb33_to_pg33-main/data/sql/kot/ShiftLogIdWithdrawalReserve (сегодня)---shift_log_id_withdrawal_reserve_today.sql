with _last as ( -- время посл.проверки
select distinct  sl."Id", max(s."StartDateTime") "StartDateTime"
from public."ShiftLogs"  sl
join public."Shifts" s on sl."Id"=s."ShiftLogId" and sl."IsActual"=true --and s."IsWithdrawalReserve" is true 
join public."ShiftEquipment" se on s."Id"=se."ShiftId" --and se."WatchingTime" is not null
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
group by sl."Id") 
,_last_rez as ( -- время посл.проверки
select distinct  sl."Id" "ShiftLogId", max(s."StartDateTime") "StartDateTime"
from public."ShiftLogs"  sl
join public."Shifts" s on sl."Id"=s."ShiftLogId" and s."IsWithdrawalReserve" is true and sl."IsActual"=true
join public."ShiftEquipment" se on s."Id"=se."ShiftId" --and se."WatchingTime" is not null
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
group by sl."Id")
select distinct  sl."Id" "ShiftLogId"
,current_date "Date_rez"
,case 
	when sl."TimeDay"='00:00:00' and "TimeNight"='00:00:00' then 'день'
	when sl."TimeDay" is null  and "TimeNight" is null then 'день'
	when sl."TimeDay" is not null then 'день'
	end "сменa"
,case 
	when "TimeNight"='00:00:00' then null
	when sl."TimeNight" is not null and now()::time>sl."TimeNight"  then 'ночь'
	end "сменaN"
,id."ExternalId"::numeric DepartmentId 
, case when sl."TimeDay" is null and sl."TimeNight" is null then 1 else 0 end "Периодически используемые"
from public."ShiftLogs" sl
join public."Shifts" s on sl."Id"=s."ShiftLogId" and sl."DateTo" is null 
join _last_rez on  s."ShiftLogId"=_last_rez."ShiftLogId"
join _last on _last_rez."ShiftLogId"=_last."Id" and _last_rez."StartDateTime"=_last."StartDateTime"
join public."Departments" d on sl."DepartmentId"=d."Id"
join public."ImportDepartments" id on d."Id"=id."DepartmentId"
join public."ShiftEquipment" se on s."Id"=se."ShiftId" 
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
where (sl."TimeDay"<>'00:00:00' or "TimeNight"<>'00:00:00') and (sl."TimeDay" is not null or "TimeNight" is not null)
and sl."IsActual"=true