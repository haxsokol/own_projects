/*_____________ ищем пользоватлей, которым будет доступен просмотр различных подразделений  ________________________________*/	
select 
	"E1"."Email" as "Upn"
    ,"E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                  as "Пользователь" 
	,"E1"."PersonalNumber" as "Табельный номер"
	,"BusinessUnits"."Name"
	,"UserBusinessUnits"."BusinessUnitId"
	,char_length("E1"."Email")
	,"E1"."Email"
	,substring("E1"."Email" from 1 for position ('@' in "E1"."Email")-1)  as "SHORT_UPN" --короткий  UPN до собаки
	,"BusinessUnits"."LocationId"
	,"Locations"."Name" as "Location_Name"
from "Users" 

/*_____________ Расшифровываем пользователей, имеющих эту роль для вывода EMAIL (UPN) и табельного номера ________________________________*/			
left join "Employees" as "E1" 
	on "Users"."EmployeeId"="E1"."Id" 
			and "E1"."IsActual" IN (true) and char_length("E1"."Email")>0-- берем только актуальных и с почтой

/*_____________ Связываем с таблицей Вилиал пользователя ________________________________*/			
left join "UserBusinessUnits" 
	on "Users"."Id"="UserBusinessUnits"."UserId" 
		and "UserBusinessUnits"."IsActual" IN (true) -- берем только актуальных	
	
/*_____________ Расшифровываем название филиалов ________________________________*/			
left join "BusinessUnits" 
	on "BusinessUnits"."Id"="UserBusinessUnits"."BusinessUnitId" 
		and "BusinessUnits"."IsActual" IN (true)-- берем только актуальных		

/*_____________ Бизнес единица  ________________________________*/		
LEFT JOIN "Locations" 
	ON "BusinessUnits"."LocationId" = "Locations"."Id"


/*_____________ Настройка ограничений и условий ________________________________*/	
where "Users"."IsActual" IN (true) --
and "E1"."Email" is not null
and "E1"."PersonalNumber" is not null
--and "E1"."PersonalNumber" like ('7000678%') --тест на пользователе

