WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)')
	else COALESCE("L4"."ROOT_NAME",'Участки(Ур-нь цеха не задан)') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"


FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок
),
/*___________________ генерация виртуального календаря по одной на каждую неделю_____________________________________*/	
"CALENDAR_month" as (
	SELECT 	distinct 
	r::date as "DATE"
		,EXTRACT(month from r) as "№_месяца"
		,date_trunc('month',r) ::date as "FIRST_DAY_month"

	FROM generate_series('2024-01-01',now()::date, '1 month') as r
		
		),

"RAB_ZONE" as (
select 
"Risk_WorkAreas"."Id" as "ID_Rab_ZONE"
,"Risk_WorkAreas"."Name" as "Name_Rab_ZONE"
,"WorkRegionDepartmentId"
,"Axes"
,"Ranks"
,"MarkFrom"
,"MarkOn"
,"RegNumber"
,"InvNumber"
,"Address"
,"AddInfo"
,"DEP1"."DepartmentId"
,"REKURS"."WORKS_OBJID"

from 

"Risk_WorkAreas"



/*__________________ Связанная таблица с цехами _______________________________*/
left join "WorkRegionDepartments" as "DEP1"
	on "Risk_WorkAreas"."WorkRegionDepartmentId"="DEP1"."Id" 
		and "DEP1"."IsActual" IN (true)

/*__________________ Связанная таблица с рекурсией _______________________________*/
left join "REKURS"
	on "DEP1"."DepartmentId"="REKURS"."ID_KOT"		

	where "Risk_WorkAreas"."IsActual" IN (true)
)
		
select 

"RAB_ZONE".*
,"DATE"
,"WORKS_OBJID"||EXTRACT(year FROM (date_trunc('month',"DATE"))::date)||EXTRACT(Month FROM (date_trunc('month',"DATE"))::date) as "STRUCT_YEAR_MONTH"

from "RAB_ZONE","CALENDAR_month"		
	
