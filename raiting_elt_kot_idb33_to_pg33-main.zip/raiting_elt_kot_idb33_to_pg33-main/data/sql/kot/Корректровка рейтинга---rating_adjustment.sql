WITH  

/* _____ Принадлежность к службе  ________ */
"DOSTIP_IN_EDIT" as (
select 
    "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табельный номер
                                  as "Пользователь" 
	,"E1"."PersonalNumber" as "Табельный номер"

from  "Employees" as  "E1"

/*_____________ Связь сотрудников и принадлежност к службе ________________________________*/	
left join "Employees_Services" 
	on "E1"."Id"="Employees_Services"."EmployeeId" 
		and "Employees_Services"."IsActual" IN (true) --только актуальные записи пользователей из связанной таблицы
		
/*_____________ Сам справчоник Принадлежность к службе ________________________________*/	
left join "Services" 
	on "Employees_Services"."ServiceId"="Services"."Id" 
		and "Services"."IsActual" IN (true) --только актуальные записи пользователей из связанной таблицы		
where 
"Services"."Id" in (118) --берем именно право на корректировку рейтинга
),


"KORRECTIV" as (
select 
	"AC"."Id" as "CardId"
	,'https://kot.severstal.com/audits_industry/card/'||"AC"."Id" as "LinkCard"
	,"ExecutionDate" as "DATE"
	,"DepartmentName"
	,"import"."ExternalId"||EXTRACT(year FROM "ExecutionDate"::date)||EXTRACT(Month FROM "ExecutionDate"::date) as "STRUCT_YEAR_MONTH"
   ,"BALL"."Mark" as "Балл"
   ,"AII"."Requirement"
   , "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                  as "Аудитор" 
    FROM "AuditIndustryCards" as "AC"


/* _______________ Связь с событиями __________________________*/  
left join "Events" as "EV" -- Событие к аудиту
       on "AC"."EventId"="EV"."Id"
 
/* _______________ Связь с подразделениями __________________________*/  
left join "EventDepartments" as "ED" -- Событие к аудиту
       on "ED"."EventId"="EV"."Id"
       
 /* _______________Место проведения Аудита__________________________*/
join "Departments" as "D"
       on "ED"."DepartmentId"="D"."Id"      

/* _______________ перекодировочная для OBJID цехов __________________________*/     
left join "ImportDepartments" as "import"  
on "D"."Id"::integer="import"."DepartmentId"::integer -- цех OBJID цехов	*/  
       
/* _______________ Для определения вида аудита и фильтра по нему __________________________*/  
left join "AuditIndustryKinds" as "AIK"--Вид аудита
       on "AC"."AuditKindId"= "AIK"."Id" and "AIK"."IsActual" in (true)
        

/* _______________ Связываем с таблицей задействованные лица __________________________*/  
left join "InvolvedAuditIndustry" as "STAK"--задействованные лица
       on "AC"."Id"= "STAK"."AuditIndustryCardId" 
       and "STAK"."IsActual" in (true)  and     "STAK"."TypeOfInvolved"=0 --берем только актульные записи и только аудиторов (0), если 1 - соаудиторы

/* _______________ Связываем с расшифровкой задействованные лица. вытаскиваем ИД аудитора __________________________*/  
left join "EventParticipants" as "UCHASTNIK_AUDITOR"--задействованные лица
       on "STAK"."EventParticipantId"= "UCHASTNIK_AUDITOR"."Id" 
       and "UCHASTNIK_AUDITOR"."IsActual" in (true) --берем только актульные записи

/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/  
left join "Employees" as "E1" --задействованные лица
       on "UCHASTNIK_AUDITOR"."EmployeeId"= "E1"."Id" 
       and "E1"."IsActual" IN (true) --берем только актульные записи      
       
/* _______________Вопрос в карте аудита__________________________*/    
       
left join "AuditIndustryCardQuestions" as "ACQ"
       on  "AC"."Id"="ACQ"."AuditIndustryCardId" and "ACQ"."IsActual" in (true)
       
left join "AuditIndustryInquirers" as "AII" -- Опросник
       on "ACQ"."AuditIndustryInquirerId"="AII"."Id" and "AII"."IsActual" in (true)

/* _______________ балл за каждый вопрос__________________________*/    
left join "AuditIndustryGrades" as "BALL"
	  on  "BALL"."Id"="ACQ"."GradeId" and "BALL"."IsActual" in (true)
 
/* _______________ связь с правом на корректировку __________________________*/    
left join "DOSTIP_IN_EDIT"
	  on  "DOSTIP_IN_EDIT"."Табельный номер"="E1"."PersonalNumber" 
	  
	  
WHERE "AC"."IsActual" IN (true) --только актуальные записи
and "GroupOfDirectionId" in (117)  -- Корректировка рейтинга
and "DOSTIP_IN_EDIT" is not null --только с правом на корреткровку из принадлежности к службе
),

"KORR_TAB" as (
select 
	"KORRECTIV"."CardId"
	,"KORRECTIV"."LinkCard"
		,"KORRECTIV"."DATE"
			,"KORRECTIV"."DepartmentName"
				,"KORRECTIV"."STRUCT_YEAR_MONTH"
				,"KORRECTIV"."Аудитор"
	,"K1"."Балл" as "Блок №1"
	,"K2"."Балл" as "№1 Ежесменное тестирование"
	,"K3"."Балл" as "№2 Обязательное обучение"
	,"K4"."Балл" as "№3.1 Дисциплина по безопасности"
	,"K5"."Балл" as "№3.2 Дисциплина по безопасности"
	,"K6"."Балл" as "№3.3 Дисциплина по безопасности"	
	,"K7"."Балл" as "№4 Извлечение уроков"	
	,"K8"."Балл" as "№5 Контроль соблюдения БПСЖ"	
	,"K9"."Балл" as "№6 Оценка рисков рутинных работ"
	,"K10"."Балл" as "№7 Эффективность управления КББ"	
	,"K11"."Балл" as "№8 Проекты по ОТ и ПБ"	
	,"K12"."Балл" as "Фальсификация / сокрытие данных"
	,"K13"."Балл" as "Неудовлетворительная оценка"	
	,"K14"."Балл" as "Неудовлетворительные проверки"	
	,"K15"."Балл" as "Формальное закрытие мероприятий"
	
FROM "KORRECTIV" 
/* _______________ балл за 1 блок__________________________*/    
left join "KORRECTIV" as "K1"
	  on  "K1"."CardId"||"K1"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K1"."Requirement" like ('Блок №1%')
	  
/* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K2"
	  on  "K2"."CardId"||"K2"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K2"."Requirement" like ('№1 Ежесменное тестирование%')	  
	  
	 /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K3"
	  on  "K3"."CardId"||"K3"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K3"."Requirement" like ('№2 Обязательное обучение%')	  
  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K4"
	  on  "K4"."CardId"||"K4"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K4"."Requirement" like ('№3.1 Дисциплина по безопасности%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K5"
	  on  "K5"."CardId"||"K5"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K5"."Requirement" like ('№3.2 Дисциплина по безопасности%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K6"
	  on  "K6"."CardId"||"K6"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K6"."Requirement" like ('№3.3 Дисциплина по безопасности%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K7"
	  on  "K7"."CardId"||"K7"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K7"."Requirement" like ('№4 Извлечение уроков%')	  
	  
 /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K8"
	  on  "K8"."CardId"||"K8"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K8"."Requirement" like ('№5 Контроль соблюдения БПСЖ%')	  
 

	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K9"
	  on  "K9"."CardId"||"K9"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K9"."Requirement" like ('№6 Оценка рисков рутинных работ%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K10"
	  on  "K10"."CardId"||"K10"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K10"."Requirement" like ('№7 Эффективность управления КББ%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K11"
	  on  "K11"."CardId"||"K11"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K11"."Requirement" like ('№8 Проекты по ОТ и ПБ%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K12"
	  on  "K12"."CardId"||"K12"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K12"."Requirement" like ('Фальсификация / сокрытие данных%')	  
	  
	  /* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K13"
	  on  "K13"."CardId"||"K13"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K13"."Requirement" like ('Неудовлетворительная оценка%')	  
	  
	/* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K14"
	  on  "K14"."CardId"||"K14"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K14"."Requirement" like ('Неудовлетворительные проверки%')	  
	
	/* _______________ балл за №1 Ежесменное тестирование __________________________*/    
left join "KORRECTIV" as "K15"
	  on  "K15"."CardId"||"K15"."Requirement"="KORRECTIV"."CardId"||"KORRECTIV"."Requirement" and "K15"."Requirement" like ('Формальное закрытие мероприятий%')	  	  
	  )
	  
select  
"CardId"
,"LinkCard"
,"DATE"
,"DepartmentName"
,"STRUCT_YEAR_MONTH"
,"Аудитор"
,max("Блок №1") as "Блок №1"
,max("№1 Ежесменное тестирование") as "№1 Ежесменное тестирование"
,max("№2 Обязательное обучение") as "№2 Обязательное обучение"
,max("№3.1 Дисциплина по безопасности") as "№3.1 Дисциплина по безопасности"
,max("№3.2 Дисциплина по безопасности") as "№3.2 Дисциплина по безопасности"
,max("№3.3 Дисциплина по безопасности") as "№3.3 Дисциплина по безопасности"
,max("№4 Извлечение уроков") as "№4 Извлечение уроков"
,max("№5 Контроль соблюдения БПСЖ") as "№5 Контроль соблюдения БПСЖ"
,max("№6 Оценка рисков рутинных работ") as "№6 Оценка рисков рутинных работ"
,max("№7 Эффективность управления КББ") as "№7 Эффективность управления КББ"
,max("№8 Проекты по ОТ и ПБ") as "№8 Проекты по ОТ и ПБ"
,max("Фальсификация / сокрытие данных") as "Фальсификация / сокрытие данных"
,max("Неудовлетворительная оценка") as "Неудовлетворительная оценка"
,max("Неудовлетворительные проверки") as "Неудовлетворительные проверки"
,max("Формальное закрытие мероприятий") as "Формальное закрытие мероприятий"


from "KORR_TAB"
group by "CardId","LinkCard","DATE","DepartmentName","STRUCT_YEAR_MONTH","Аудитор"