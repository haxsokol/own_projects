select distinct  sl."Id", sl."Name",sl."DateFrom"::date 
,case 
	when sl."DateTo" is null then current_date-1
	else sl."DateTo"::date end "DateTo"
,case 
	when sl."TimeDay"='00:00:00' and "TimeNight"='00:00:00' then 'день'
	when sl."TimeDay" is null  and "TimeNight" is null then 'день'
	when sl."TimeDay" is not null then 'день'
	end "сменa"
,case 
	when "TimeNight"='00:00:00' then null
	when sl."TimeNight" is not null then 'ночь'
	end "сменaN"
,id."ExternalId"::numeric DepartmentId
from public."ShiftLogs" sl
join public."Shifts" s on sl."Id"=s."ShiftLogId"
join public."Departments" d on sl."DepartmentId"=d."Id"
join public."ImportDepartments" id on d."Id"=id."DepartmentId"
join public."ShiftEquipment" se on s."Id"=se."ShiftId" 
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
where (sl."TimeDay"<>'00:00:00' or "TimeNight"<>'00:00:00') and (sl."TimeDay" is not null or "TimeNight" is not null)
and sl."IsActual"=true