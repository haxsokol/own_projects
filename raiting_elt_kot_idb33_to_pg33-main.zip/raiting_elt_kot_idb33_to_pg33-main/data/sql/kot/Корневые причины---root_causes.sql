WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)')
	else COALESCE("L4"."ROOT_NAME",'Участки(Ур-нь цеха не задан)') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"


FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок
),


"Event"  as (
/*___________________ группировка для вычисления одного иденификатора _____________________________________*/

select distinct

"InjurySeverstal"."InjuryId"-- идентификатор карты происшествия
	,"InjuryDate"::date	
	,"ResponsibleDepartmentId"
	,"WORKS_OBJID" 
	,"InjuryCauses"."Paragraph"||' '||"InjuryCauses"."Cause"||' ('||"InjuryCauses"."Code"||')'  as "Корневые"
	,"InjuryCauses"."Id" as "ID_Корневой"
	,date_trunc('month',"InjuryDate")::date as "FIRST_DAY"
	,((date_trunc('month',"InjuryDate") + interval '12 month') - interval '1 day')::date as "LAST_DAY"

	
from "InjurySeverstal"

/*_____ для поиска корневых причин ____*/
left join "InjurySeverstalRootCauses"
	on "InjurySeverstal"."Id"="InjurySeverstalRootCauses"."InjurySeverstalId" and "InjurySeverstalRootCauses"."IsActual" IN (true)

/*_____ для вывода идентификатора корневых причин ____*/
left join "InjuryCauses" 
on "InjurySeverstalRootCauses"."InjuryCauseId"="InjuryCauses"."Id" --	and "InjuryCauses"."IsActual" IN (true)

/*_____ для вывода идентификатора корневых причин ____*/
left join "REKURS" 	
	on "REKURS"."ID_KOT"="InjurySeverstal"."ResponsibleDepartmentId"

where 

--"InjurySeverstal"."InjuryId" in (47,4650) and --тест на конкртеной карте происшествия 
"InjurySeverstal"."IsActual" in (true)
and "InjuryCauses"."Id" is not null	
--and "InjuryCauses"."Id" in (156)
--and "InjurySeverstal"."ResponsibleDepartmentId" in (890)

),


/*___________________ генерация виртуального календаря_____________________________________*/		
"CALENDAR" as (
SELECT * FROM generate_series('2023-01-01',
                               now()::date, '1 month') as r
               ),


"ITOG_REITING" as (
select 
"Event"."InjuryId"
,'https://kot.severstal.com/injuries/injuries-severstal/'||"Event"."InjuryId" as "LinkCard"
,"Event"."Корневые"
,count ("Event2"."ID_Корневой")-1 as "Количество повторений"
,"Event"."WORKS_OBJID"||EXTRACT(year FROM "Event"."InjuryDate"::date)||EXTRACT(Month FROM "Event"."InjuryDate"::date) as "STRUCT_YEAR_MONTH"
/*_____ вывод идентификаторов присшествий с посторением причин  ____*/
,string_agg("Event2"."InjuryId"::text, ';
			' ORDER BY "Event"."InjuryId") AS "Где повторы"


			from "Event"

/*_____ соединяем само с собой  ____*/
left join "Event" as "Event2"
on "Event"."ID_Корневой"="Event2"."ID_Корневой"	
	and "Event"."ResponsibleDepartmentId"="Event2"."ResponsibleDepartmentId"
		and "Event"."InjuryDate" between "Event2"."FIRST_DAY" and "Event2"."LAST_DAY"
	
group by 
"Event"."InjuryId"
,"Event"."InjuryDate"
,"Event"."ResponsibleDepartmentId"
,"Event"."WORKS_OBJID" 
,"Event"."Корневые"
,"Event"."ID_Корневой"
,"Event"."FIRST_DAY"
,"Event"."LAST_DAY"
)


select * from  "ITOG_REITING"
where  "Количество повторений">=1