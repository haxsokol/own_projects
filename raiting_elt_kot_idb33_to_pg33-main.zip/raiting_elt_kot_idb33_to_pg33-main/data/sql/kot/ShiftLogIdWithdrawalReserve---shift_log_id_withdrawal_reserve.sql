with _last as ( -- время посл.проверки
select distinct  sl."Id", max(s."StartDateTime") "StartDateTime"
from public."ShiftLogs"  sl
join public."Shifts" s on sl."Id"=s."ShiftLogId" --and s."IsWithdrawalReserve" is true and sl."IsActual"=true
join public."ShiftEquipment" se on s."Id"=se."ShiftId" --and se."WatchingTime" is not null
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
group by sl."Id")
,_last_rez as ( -- время посл.проверки/резерв
select distinct  sl."Id", max(s."StartDateTime") "StartDateTime"
from public."ShiftLogs"  sl
join public."Shifts" s on sl."Id"=s."ShiftLogId" and s."IsWithdrawalReserve" is true and sl."IsActual"=true
join public."ShiftEquipment" se on s."Id"=se."ShiftId" --and se."WatchingTime" is not null
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
group by sl."Id")
,loc_rez as ( -- id оборудования со статусом в резерве
select 
distinct  
s."ShiftLogId" --Id журнала
FROM 
public."Shifts" s 
join public."ShiftLogs" sl on s."ShiftLogId"=sl."Id" and s."IsWithdrawalReserve" is true and sl."IsActual"=true
join public."ShiftEquipment" se on s."Id"=se."ShiftId" 
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
)
, _dat as (
select 
distinct  
 s."ShiftLogId" --Id журнала 
,s."StartDateTime"  --Время приёма смены
FROM 
public."Shifts" s 
join loc_rez on s."ShiftLogId"=loc_rez."ShiftLogId" --and s."IsWithdrawalReserve" is false 
)
, _dat_rez as (
select 
distinct  
 s."ShiftLogId" 
,s."StartDateTime"  
,_dat."StartDateTime"   "EndDateTime"
,"TimeDay"
,"TimeNight"
,case 
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  
	(s."StartDateTime"::time>=sl."TimeNight"-interval '1' hour or s."StartDateTime"::time<sl."TimeDay"-interval '1' hour) --интервал между началами смены со сдвигом на час назад (те, кто пришел раньше и заполнил)
	then 'ночь' 
	else 'день' 
	end "смена"
,case 
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  
	(_dat."StartDateTime"::time>=sl."TimeNight"-interval '1' hour or _dat."StartDateTime"::time<sl."TimeDay"-interval '1' hour) --интервал между началами смены со сдвигом на час назад (те, кто пришел раньше и заполнил)
	then 'ночь' 
	else 'день' 
	end "сменаEnd"
FROM 
public."Shifts" s 
join public."ShiftLogs" sl on s."ShiftLogId"=sl."Id" and sl."IsActual"=true 
join loc_rez on s."ShiftLogId"=loc_rez."ShiftLogId" and s."IsWithdrawalReserve" is true
left join _dat on s."ShiftLogId"=_dat."ShiftLogId"
group by  s."ShiftLogId" 
,s."StartDateTime"
,_dat."StartDateTime"
,"TimeDay"
,"TimeNight"
having _dat."StartDateTime" >s."StartDateTime" --or _dat."StartDateTime" is null
)
, res as ( 
select 
distinct  
 "ShiftLogId" --Id журнала 
,_dat_rez."смена"
,case 
	when "смена"='ночь' and "StartDateTime"::time>=_dat_rez."TimeNight" then "StartDateTime"::date+1 else "StartDateTime"::date end "StartDateTimeRez"
,case 
	when "сменаEnd"='день' then	min("EndDateTime"::date)-1 else min("EndDateTime"::date) end "EndDateTimeRez"
--,min("EndDateTime"::date)-1 "EndDateTimeRez"
,case 
	when "смена"='ночь' then (min("EndDateTime"::date)-"StartDateTime"::date-1)else (min("EndDateTime"::date)-"StartDateTime"::date) end "dn"
FROM _dat_rez
group by "ShiftLogId"
,"StartDateTime"
,_dat_rez."смена"
,"сменаEnd"
,_dat_rez."TimeNight" )
 select 
distinct  
 res."ShiftLogId" --Id журнала 
,"StartDateTimeRez"
,res."EndDateTimeRez"
,id."ExternalId"::numeric DepartmentId 
, case when sl."TimeDay" is null and sl."TimeNight" is null then 1 else 0 end "Периодически используемые"
,'день' "c1"
, case when sl."TimeNight" is null then null else 'ночь' end "c2"
from public."ShiftLogs" sl
join res on sl."Id"=res."ShiftLogId" and sl."IsActual"=true
join public."Departments" d on sl."DepartmentId"=d."Id"
join public."ImportDepartments" id on d."Id"=id."DepartmentId"
union
select 
distinct  
 _last_rez."Id" --Id журнала 
,_last_rez."StartDateTime"::date "StartDateTimeRez"
, case when sl."DateTo" is null then current_date::date-1 else sl."DateTo"::date end "EndDateTimeRez" 
,id."ExternalId"::numeric DepartmentId 
, case when sl."TimeDay" is null and sl."TimeNight" is null then 1 else 0 end "Периодически используемые"
,'день' "c1"
, case when sl."TimeNight" is null then null else 'ночь' end "c2"
from public."ShiftLogs" sl
join _last_rez on sl."Id"=_last_rez."Id" and _last_rez."StartDateTime"::date<current_date::date
join _last on _last_rez."Id"=_last."Id" and _last_rez."StartDateTime"=_last."StartDateTime"
join public."Departments" d on sl."DepartmentId"=d."Id"
join public."ImportDepartments" id on d."Id"=id."DepartmentId"