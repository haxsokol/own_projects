WITH RECURSIVE 

       "LV_SUBD" AS (
SELECT 
                    "Departments"."Id"
    , "Departments"."BusinessUnitId"
    , "Departments"."ParentDepartmentId" AS "ParentId"
    , COALESCE("DepartmentLevelId"
    , 1) AS "LevelId"
    , "DepartmentName" AS "D_Name"
    , "Departments"."Id" AS "ROOT_ID"
    , "DepartmentName" AS "ROOT_NAME"
    , CASE 
                         WHEN "Departments"."Id" IN ('29970')
        --присваиваем признак цеха для Стальных решений вручную
                    THEN 4
        ELSE COALESCE("DepartmentLevelId"
        , 1)
    END AS "ROOT_L"
    , "importd"."ExternalId"
    , "Documents"."Number"::NUMERIC
FROM
    "Departments"
LEFT JOIN "ImportDepartments" AS "importd" 
                             ON
    "Departments"."Id" = "importd"."DepartmentId" AND "importd"."ExternalId" !~ '[a-zA-Zа-яА-Я]'
LEFT JOIN "Documents" 
                        ON
    "importd"."ExternalId"::NUMERIC = "Documents"."Number"::NUMERIC
    AND "Description" IN ('Рейтинг цеха')
    AND "Documents"."IsActual" IN (TRUE)
UNION ALL
SELECT 
                    "DEP"."Id" AS "Id"
    , "DEP"."BusinessUnitId"
    , "DEP"."ParentDepartmentId" AS "ParentId"
    , "DEP"."DepartmentLevelId" AS "LevelId"
    , "DEP"."DepartmentName" AS "D_Name"
    , "LV_SUBD"."ROOT_ID" AS "ROOT_ID"
    , "LV_SUBD"."ROOT_NAME" AS "ROOT_NAME"
    , "LV_SUBD"."ROOT_L" AS "ROOT_L"
    , "LV_SUBD"."ExternalId"
    , "LV_SUBD"."Number"
FROM
    "Departments" AS "DEP"
JOIN "LV_SUBD"
             ON
    "DEP"."ParentDepartmentId" = "LV_SUBD"."Id"

             
       )
,
       
"REKURS" AS (
SELECT
    "D"."IsActual"
    , "D"."Id" AS "ID_KOT"
    , "importd"."ExternalId" AS "OBJID"
    , "D"."DepartmentName" AS "NAME"
    , "L_REITING"."ExternalId" AS "L_REITING"
FROM
    "Departments" AS "D"
LEFT JOIN "BusinessUnits" AS "BU"
    -- Предприятия
       ON
    "D"."BusinessUnitId" = "BU"."Id"
LEFT JOIN "Locations"
    -- Бизнес единици
       ON
    "BU"."LocationId" = "Locations"."Id"
LEFT JOIN "DepartmentLevels" AS "DL"
       ON
    "D"."DepartmentLevelId" = "DL"."Id"
    AND "DL"."IsActual"
    -- Название уровней структуры
LEFT JOIN "ImportDepartments" AS "importd" 
       ON
    "D"."Id" = "importd"."DepartmentId"
    --and "importd"."IsActual" IN (true) -- ID из САП

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
LEFT JOIN "LV_SUBD" AS "L_REITING"
       ON
    "D"."Id" = "L_REITING"."Id"
    AND ("L_REITING"."ROOT_L" = 5
        OR "L_REITING"."ROOT_L" = 4)
    AND "L_REITING"."Number" IS NOT NULL
WHERE
    "L_REITING"."ExternalId" IS NOT NULL
    AND "importd"."ExternalId" IS NOT NULL
    --and "L5"."ExternalId" in ('34101') 
    --and "D"."Id" in ('29970','29997','30026')
       
       )
,
/* _______________ Связываем для выявления желтой и красной зоны из справочника __________________________*/    
"RAIT" AS (
SELECT
    "AuditIndustryRatings"."StartDate"
    , CASE
        WHEN "AuditIndustryRatings"."EndDate" IS NULL
THEN CURRENT_DATE
        ELSE "AuditIndustryRatings"."EndDate"
    END AS "EndDate"
    , "AuditIndustryRatings"."AuditIndustryKindId"
    , "AuditIndustryRatings"."RatingGrade"
    , "AuditIndustryRatings"."MinAmount"
    , CASE
        WHEN "AuditIndustryRatings"."MaxAmount">1
            AND "AuditIndustryRatings"."MaxAmount" = 100
            -- от 0 до 100, и 100, тогда 100
THEN 100
            WHEN "AuditIndustryRatings"."MaxAmount">1
            -- от 0 до 100, и не 100, тогда минус 1, т.к. исключительно
    THEN "AuditIndustryRatings"."MaxAmount"-1
            WHEN "AuditIndustryRatings"."MaxAmount" <= 1
            AND "AuditIndustryRatings"."MaxAmount" = 1
            -- от 0 до 1, и 1, тогда 1
        THEN 1
            WHEN "AuditIndustryRatings"."MaxAmount" <= 1
            -- от 0 до 1, и НЕ 1, тогда минус 0.01, т.к. исключительно
            THEN "AuditIndustryRatings"."MaxAmount"-0.01
            ELSE 0
        END AS "MaxAmount"
        , CASE
            WHEN "AuditIndustryRatings"."RatingGrade" IN ('Амбиция', 'Безопасная зона', '   Все требования соблюдены, замечания и несоответствия отсутствуют.', 'Удовлетворительно')
THEN 'Зеленая зона'
            WHEN "AuditIndustryRatings"."RatingGrade" IN ('База')
THEN 'Желтая зона'
            ELSE 'Красная зона'
        END AS "NEUD"
        , CASE
            WHEN "AuditIndustryRatings"."RatingGrade" IN ('Амбиция', 'Безопасная зона', '   Все требования соблюдены, замечания и несоответствия отсутствуют.', 'Удовлетворительно')
THEN 0
            WHEN "AuditIndustryRatings"."RatingGrade" IN ('База', 'Зона внимания')
THEN 10
            ELSE 30
        END AS "Ball"
        , "AuditIndustryRatings"."IsActual" IN (TRUE) AS "Актуальность"
    FROM
        "AuditIndustryRatings"
    WHERE
        "AuditIndustryRatings"."AuditIndustryKindId" NOT IN (34, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 61, 27, 63, 28, 29, 30, 31, 32, 65, 66, 62, 64, 67, 105, 106, 107, 103, 108, 
109, 110, 111, 112, 113, 114, 115, 126, 163, 220, 269, 401, 717, 1140, 12, 217, 218, 118, 119, 96, 121, 122, 123, 124, 125, 271, 216, 219, 272, 312, 273, 313, 
274, 275, 311, 314, 315, 397, 398, 399, 458, 459, 1023, 120, 1122, 1074, 1071, 1081, 1075, 1041, 1141, 615, 450, 452, 453, 454, 455, 456, 457, 460, 461, 470, 
471, 963, 967, 968, 965, 624, 619, 620, 625, 626, 627, 718, 719, 720, 721, 722, 723, 813, 827, 877, 1022, 449, 1120, 469, 468, 463, 462, 1076, 1078, 1077, 1079, 
1083, 1085, 1024, 970, 969, 971, 1145, 988, 1088, 1119, 1073, 987, 1086, 1144, 1070, 1175, 1040, 1082, 708, 709, 520, 710, 712, 713, 518, 360, 959, 958, 964, 966, 
962, 960, 961, 97, 98, 99, 100, 101, 102, 116, 117, 201, 202, 224, 221, 222, 223, 400, 451, 466, 989, 200, 1080, 1102, 1093, 1121, 1092, 361, 359)
        -- ДОБАВИЛ ЭТУ СТРОКУ, УБРАТЬ ПОСЛЕ ТОГО, КАК РЕШАТ ВОПРОС С -infifnity в "AuditIndustryRatings"."StartDate"
        --AND "AuditIndustryRatings"."IsActual" = TRUE


)
, 

"PROIZVODITEL" AS (
SELECT 
    "AC"."Id" AS "CardId"
    , 'https://kot.severstal.com/audits_industry/card/' || "AC"."Id" AS "LinkCard"
    , "RAIT"."Ball"
    , "RAIT"."NEUD"
    , "RAIT"."AuditIndustryKindId"
    , "FinalScore" AS "%"
    , "ExecutionDate"::DATE AS "DATE"
    , "DepartmentName"
    , "D"."Id" AS "MESTO_AUDITA"
    ,("import"."ExternalId" || EXTRACT(YEAR
FROM
    "ExecutionDate"::date)|| EXTRACT(MONTH
FROM
    "ExecutionDate"::date))::NUMERIC AS "STRUCT_YEAR_MONTH"
    , "GroupOfDirectionId"
    , CASE 
         WHEN 
   "E1"."Discriminator" IN ('ExternalEmployee')
   THEN "E1"."LastName" || ' ' ||
        -- ФАМИЛИЯ
        substring("E1"."FirstName"
    FROM
        1 FOR 1)|| '. ' ||
        --имя с точкой
                    COALESCE(substring("E1"."SecondName"
    FROM
        1 FOR 1)|| '.'
        , '')
        --отчество с точкой
                                || ', ' || "E1"."Position"
        -- должность    
        ELSE "E1"."LastName" || ' ' ||
        -- ФАМИЛИЯ
        substring("E1"."FirstName"
    FROM
        1 FOR 1)|| '. ' ||
        --имя с точкой
                    COALESCE(substring("E1"."SecondName"
    FROM
        1 FOR 1)|| '.'
        , '')
        --отчество с точкой
                           || ' (' || "E1"."PersonalNumber" || ')'
        --табльный номер
                                || ', ' || "PN1"."Name"
        -- должность                       
    END AS "Аудитор"
    , CASE 
         WHEN 
   "E1"."Discriminator" IN ('ExternalEmployee')
   THEN "E1"."Position"
        -- должность внутренняя
        ELSE "PN1"."Name"
        -- должность внешняя             
    END AS "Должность_Аудитора"
    , CASE 
         WHEN "ImportExternalEmployees"."ExternalId" IS NOT NULL
    THEN "ImportExternalEmployees". "ExternalId"
        ELSE "E1"."PersonalNumber"
    END AS "TN_Auditor"
    , "PT1"."DepartmentId" AS "Место_Работы_Аудитора"
    , CASE 
        WHEN "REKURS2"."NAME" IS NOT NULL
    THEN "REKURS2"."NAME"
        ELSE "ExOrg_A"."Name"
    END AS "МЕСТО_РАБ_АУДИТОРА_ПОДР"
    , CASE 
        WHEN "E2"."PersonalNumber" IS NULL
    THEN 'Подрядчик'
        ELSE    
    "E2"."LastName" || ' ' ||
        -- ФАМИЛИЯ
        substring("E2"."FirstName"
    FROM
        1 FOR 1)|| '. ' ||
        --имя с точкой
                    COALESCE(substring("E2"."SecondName"
    FROM
        1 FOR 1)|| '.'
        , '')
        --отчество с точкой
                           || ' (' || "E2"."PersonalNumber" || ')'
        --табльный номер
    END AS "Проверяемый"
    , "E2"."PersonalNumber" AS "TN_Проверяемого"
    , "PT2"."DepartmentId" AS "Место_Работы_Проверяемого"
    , "AIK"."DirectionAuditCheckId"
    --идентифиактор аудита
    , "AIK"."Name"
    -- название аудита
    , "AC"."AuditorPkLevel"
FROM
    "AuditIndustryCards" AS "AC"

/* _______________ Связь с событиями __________________________*/
LEFT JOIN "Events" AS "EV"
    -- Событие к аудиту
       ON
    "AC"."EventId" = "EV"."Id"
/* _______________ Связь с подразделениями __________________________*/
LEFT JOIN "EventDepartments" AS "ED"
    -- Событие к аудиту
       ON
    "ED"."EventId" = "EV"."Id"
       
 /* _______________Место проведения Аудита__________________________*/
JOIN "Departments" AS "D"
       ON
    "ED"."DepartmentId" = "D"."Id"      

/* _______________ перекодировочная для OBJID цехов __________________________*/
LEFT JOIN "ImportDepartments" AS "import"  
    ON
    "D"."Id"::integer = "import"."DepartmentId"::integer
    -- цех OBJID цехов    */  
       
       
/* _______________ Для определения вида аудита и фильтра по нему __________________________*/
LEFT JOIN "AuditIndustryKinds" AS "AIK"
    --Вид аудита
       ON
    "AC"."AuditKindId" = "AIK"."Id"
    --and "AIK"."IsActual" in (true)

/* _______________ Связываем с таблицей задействованные лица __________________________*/
LEFT JOIN "InvolvedAuditIndustry" AS "STAK"
    --задействованные лица
       ON
    "AC"."Id" = "STAK"."AuditIndustryCardId"
    AND "STAK"."IsActual" IN (TRUE)
        AND "STAK"."TypeOfInvolved" = 0
        --берем только актульные записи и только аудиторов (0), если 1 - соаудиторы

/* _______________ Связываем с расшифровкой задействованные лица. вытаскиваем ИД аудитора __________________________*/
    LEFT JOIN "EventParticipants" AS "UCHASTNIK_AUDITOR"
        --задействованные лица
       ON
        "STAK"."EventParticipantId" = "UCHASTNIK_AUDITOR"."Id"
        AND "UCHASTNIK_AUDITOR"."IsActual" IN (TRUE)
        --берем только актульные записи

/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/
    LEFT JOIN "Employees" AS "E1"
        --задействованные лица
       ON
        "UCHASTNIK_AUDITOR"."EmployeeId" = "E1"."Id"
            AND "E1"."IsActual" IN (TRUE)
            --берем только актульные записи

/* _______________ Связываем с таблицей персонала Employees Назначение сотрудника__________________________*/
        LEFT JOIN "InternalEmployeePositionTypes" AS "IEPT1"
            -- Назначение сотрудника
    ON
            "E1"."Id" = "IEPT1"."InternalEmployeeId"
                AND "IEPT1"."IsActual" IN (TRUE)

/* _______________ Связываем с таблицей подрядного персонала ImportExternalEmployees для вывода личного номера аудитора__________________________*/
            LEFT JOIN "ImportExternalEmployees"    
    ON
                "E1"."Id" = "ImportExternalEmployees"."ExternalEmployeeId"
                    AND "ImportExternalEmployees"."IsActual" IN (TRUE)
 
/* _______________ Связываем Назначение сотрудника с место работы аудитора __________________________*/
                LEFT JOIN "PositionTypes" AS "PT1"
                    -- место работы аудитора
    ON
                    "IEPT1"."PositionTypeId" = "PT1"."Id"
                    --and "PT1"."IsActual" in (true)

    /* _______________Место работы Аудиора, рашифровка из рекурсии__________________________*/
                LEFT JOIN "REKURS" AS "REKURS2"
    ON
                    "REKURS2"."ID_KOT" = "PT1"."DepartmentId"
                LEFT JOIN "PositionNames" AS "PN1"
                    -- должность аудитора    
    ON
                    "PT1"."PositionNameId" = "PN1"."Id"
                        AND "PN1"."IsActual" IN (TRUE)
                    LEFT JOIN "ExternalOrganizations" AS "ExOrg_A"
                        -- Подрядная организация аудитора
    ON
                        "E1"."ExternalOrganizationId" = "ExOrg_A"."Id"
                            AND "ExOrg_A"."IsActual" IN (TRUE)
    
/* _______________ Связываем с таблицей Ответственные лица аудита __________________________*/
                        LEFT JOIN "ResponsibleForAuditIndustry" AS "OTV"
                            --задействованные лица
       ON
                            "AC"."Id" = "OTV"."AuditIndustryCardId"
                                AND "OTV"."IsActual" IN (TRUE)
                                    AND "OTV"."ResponsibilityType" = 0
                                    --берем только актульные записи и проверяемого (0), если 1 - Руководители проекта

/* _______________ Связываем с расшифровкой Ответственные лица. вытаскиваем ИД проверяемого __________________________*/
                                LEFT JOIN "EventParticipants" AS "UCHASTNIK_PROVERZEM"
                                    --задействованные лица
       ON
                                    "OTV"."EventParticipantId" = "UCHASTNIK_PROVERZEM"."Id"
                                    AND "UCHASTNIK_PROVERZEM"."IsActual" IN (TRUE)
                                    --берем только актульные записи
     
/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/
                                LEFT JOIN "Employees" AS "E2"
                                    --задействованные лица
       ON
                                    "UCHASTNIK_PROVERZEM"."EmployeeId" = "E2"."Id"
                                        AND "E2"."IsActual" IN (TRUE)
                                        --берем только актульные записи
     
/* _______________ Связываем с таблицей персонала Employees Назначение сотрудника__________________________*/
                                    LEFT JOIN "InternalEmployeePositionTypes" AS "IEPT2"
                                        -- Назначение сотрудника
    ON
                                        "E2"."Id" = "IEPT2"."InternalEmployeeId"
                                            AND "IEPT2"."IsActual" IN (TRUE)

/* _______________ Связываем Назначение сотрудника с место работы аудитора __________________________*/
                                        LEFT JOIN "PositionTypes" AS "PT2"
                                            -- место работы аудитора
    ON
                                            "IEPT2"."PositionTypeId" = "PT2"."Id"
                                            --and "PT1"."IsActual" in (true)
    
/* _______________ Связываем для выявления желтой и красной зоны из справочника __________________________*/
                                        LEFT JOIN "AuditIndustryRatings"
    ON
                                            "AIK"."Id" = "AuditIndustryRatings"."AuditIndustryKindId"
                                                AND "AuditIndustryRatings"."IsActual" IN (TRUE)
    
/* _______________ Связываем таблицу с оценками __________________________*/
                                            LEFT JOIN "RAIT"
                                                -- таблица с оценками
    ON
                                                "AIK"."Id" = "RAIT"."AuditIndustryKindId"
                                            WHERE
                                                "AC"."IsActual" IN (TRUE)
                                                --только актуальные записи
                                                --and "AC"."Id" in (2009) --проверка на конкретном аудите
                                                --and "AIK"."DirectionAuditCheckId" not in (21,19,95) -- не оценка производителя работ, не цифровой обход не корректировка рейтинга цехов
                                                --and "AIK"."Id" not in (449) -- не СОУТ
                                                    AND "ExecutionDate" IS NOT NULL
                                                    --берем только закрытые аудиты
                                                    -- ЭТУ СТРОКУ РАСКОММЕРНИТРОВАТЬ ПОСЛЕ ТОГО, КАК РЕШАТ ВОПРОС С -infifnity в "AuditIndustryRatings"."StartDate"
                                                    AND "ExecutionDate" BETWEEN "RAIT"."StartDate" AND "RAIT"."EndDate"
                                                    AND "FinalScore" BETWEEN "RAIT"."MinAmount" AND "RAIT"."MaxAmount"
                                                    AND "AC"."AuditorPkLevel" IN (4, 5, 6)
                                                        AND ("AC"."IsContractor" IN (FALSE)
                                                            OR "AC"."IsContractor" IS NULL)
)
,

/*___________________ Ответственные лица. МУПРы_____________________________________*/    

"MUPR" AS (
SELECT 
       "E1"."LastName" || ' ' ||
    -- ФАМИЛИЯ
    substring("E1"."FirstName"
FROM
    1 FOR 1)|| '. ' ||
    --имя с точкой
                    COALESCE(substring("E1"."SecondName"
FROM
    1 FOR 1)|| '.'
    , '')
    --отчество с точкой
                           || ' (' || "E1"."PersonalNumber" || ')'
    --табльный номер
                                  AS "ФИО МУПР"
    , "D1"."DepartmentName" AS "Цех"
    -- Цех
    -- ,"D1"."Id" as "ID_SHOP_MUPR1" --идентификатор цеха
    , "ref_shop"."DepartmentId" AS "ID_SHOP_MUPR"
    --идентификатор цеха
    , "REKURS"."OBJID" AS "OBJID_MUPR"
    , "E1"."PersonalNumber" AS "TN_MUPR"
FROM
    "EmployeeResponsibilityInDepartments" "ref_shop"
LEFT JOIN "Employees" AS "E1" ON
    "ref_shop"."EmployeeId" = "E1"."Id"
    --ФИО начальника цеха
LEFT JOIN "Departments" AS "D1" ON
    "ref_shop"."DepartmentId" = "D1"."Id"
    -- цех
LEFT JOIN "ResponsibilityTypes" AS "Ref_OTV" ON
    "ref_shop"."ResponsibilityTypeId" = "Ref_OTV"."Id"
    -- название ответственности
LEFT JOIN "REKURS" ON
    "ref_shop"."DepartmentId" = "REKURS"."ID_KOT"
    -- связь с рекурсией для вывода OBJID
WHERE
    "ResponsibilityTypeId" IN (106)
        AND "ref_shop"."IsActual" IN (TRUE)
)
,

"AUDIT" AS (
SELECT
    DISTINCT
    "PROIZVODITEL"."CardId"
    , "PROIZVODITEL"."LinkCard"
    , "PROIZVODITEL"."Ball"
    , "PROIZVODITEL"."AuditIndustryKindId"
    , "PROIZVODITEL"."%"
    , "PROIZVODITEL"."NEUD"
    , "PROIZVODITEL"."DATE"
    , "PROIZVODITEL"."DepartmentName"
    , "PROIZVODITEL"."DirectionAuditCheckId"
    , "PROIZVODITEL"."Name"
    , "PROIZVODITEL"."Аудитор"
    , "PROIZVODITEL"."Должность_Аудитора"
    , "REKURS"."L_REITING" AS "OBJID_Аудитора"
    , CASE 
        WHEN "МЕСТО_РАБ_АУДИТОРА_ПОДР" IS NOT NULL
    THEN "МЕСТО_РАБ_АУДИТОРА_ПОДР"
        ELSE "REKURS"."NAME"
    END AS "Цех_Аудитора"
    , "REKURS2"."L_REITING" AS "OBJID_Места_Аудита"
    , "REKURS2"."NAME" AS "Цех_Места_Аудита"
/*  ,case 
        when "MUPR"."OBJID_MUPR" is null
    then 'Аудитор - не МУПР'
        else  "MUPR"."OBJID_MUPR"
    end as "OBJID_MUPR"*/
    , CASE 
        WHEN "MUPR"."OBJID_MUPR" IS NULL
    THEN 'Аудитор - не МУПР'
        ELSE "MUPR"."Цех"
    END AS "Цех_МУПР"
    , "STRUCT_YEAR_MONTH"
    , CASE 
        WHEN "MUPR"."OBJID_MUPR" IS NOT NULL
        -- Аудитор МУПР своего цеха
    THEN 0
        WHEN "REKURS2"."L_REITING" = "REKURS"."L_REITING"
        --цех проверяемого равен месту проведения аудита
    THEN 0
        ELSE 1
    END AS "Внешние_проверяющие"
FROM
    "PROIZVODITEL"

/* _______________ Связываем рекурсию с место работы аудитора __________________________*/
LEFT JOIN "REKURS"
    -- место работы аудитора с рекурсией для вывода OBJID урвня цеха
    ON
    "REKURS"."ID_KOT" = "PROIZVODITEL"."Место_Работы_Аудитора"
    
/* _______________ Связываем рекурсию с местом проведения аудита __________________________*/
LEFT JOIN "REKURS" AS "REKURS2"
    -- место проведения аудита для вывода OBJID урвня цеха
    ON
    "REKURS2"."ID_KOT" = "PROIZVODITEL"."MESTO_AUDITA"
    
/*_________ связь с МУПРами   ________________*/
LEFT JOIN "MUPR"
    -- выводим при совпадении цеха МУПРа и табельного номера МУПРа с цехом Проверяемого и табельного номера Аудитора
    ON
    "MUPR"."OBJID_MUPR" || "TN_MUPR" = "REKURS2"."L_REITING" || "TN_Auditor"
)
,



"AUDIT_VNESH" AS
(
SELECT
    *
FROM
    "AUDIT"
WHERE
    "Внешние_проверяющие" = 1
    AND "STRUCT_YEAR_MONTH" IS NOT NULL
)

SELECT
    *
    , RANK() OVER(PARTITION BY "OBJID_Места_Аудита" ORDER BY "DATE" DESC) AS "НомераАудитовПоЦеху"
FROM
    "AUDIT_VNESH"
WHERE
    "AuditIndustryKindId" IN (1246)
    -- оставляем только аудиты СУОТ 
    AND "OBJID_Места_Аудита" IS NOT NULL