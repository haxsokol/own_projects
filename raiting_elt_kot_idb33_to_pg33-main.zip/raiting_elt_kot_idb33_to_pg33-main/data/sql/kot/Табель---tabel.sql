
WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" in (true)
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),
"Event"  as (
/*___________________ берем ПСП и смертельные для вычитания 30 и 100 баллов (исключаем травматизм легкий и тяжелый, он отдельно) _____________________________________*/
select 
"InjurySeverstal"."InjuryId" as "CardID"-- идентификатор карты происшествия
,'https://kot.severstal.com/injuries/injuries-severstal/'||"InjurySeverstal"."InjuryId" as "LinkCard"
,"InjuryDate"::date	 as "Дата"
,"REKURS"."WORKS_OBJID"::numeric as "OBJID"
,left("class"."Code", 4)||' '||"class"."Name" as "Name"
,CASE 
	when "TRAVM"."InjuryGrade" in (2)   -- 2, там Смерть 
then -100 
	WHEN "InjurySeverstal"."AftermathPeopleId" IN (5, 4) 
THEN  -30	
	else 0 
end as "Penalty"
,case 
    when "TRAVM"."InjuryGrade" in (2)
then (date_trunc('month', "InjuryDate"::date)::date+interval '11 month')::date
   else date_trunc('month', "InjuryDate"::date)::date 
end as "Date_End_1"

from "InjurySeverstal"

LEFT join "Injurys" 
	on "InjurySeverstal"."InjuryId" = "Injurys"."Id" and "Injurys"."IsActual" IN (true) 
LEFT JOIN "InjurySeverstalResponsibleDepartments" ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId"
 and (("InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null )
	and	"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" in (1))

left join	"REKURS" 
	on "REKURS"."ID_KOT"="InjurySeverstalResponsibleDepartments"."DepartmentId"
	
left join "InjuryAftermathPeople" 
	on "InjurySeverstal"."AftermathPeopleId" = "InjuryAftermathPeople"."Id"
left join "InjurySections" as "class" 
	on "Injurys"."InjurySectionId" = "class"."Id" 
left join "InjuryHurt" as "TRAVM" 
	on "TRAVM"."SingleInjuryId"="Injurys"."Id" -- реестр 
		or "TRAVM"."GroupInjuryId"="Injurys"."Id" -- реестр или групповое или единичное
where 
--"InjurySeverstal"."InjuryId" in (4312) and --тест на конкртеной карте происшествия 
"Injurys"."IsActual" in (true)
and "Injurys"."OnProduction" in (true)
and "InjurySeverstalResponsibleDepartments"."InjurySeverstalId" is not null
and  ("TRAVM"."InjuryGrade" not in (1,0) or "TRAVM"."InjuryGrade" is null) --убираю легкие и тяжелые травмы, т.к. за них отдельный штраф за часы отсутствия
),

/*___________________ генерация виртуального календаря_____________________________________*/		
"CALENDAR" as (SELECT * FROM generate_series('2023-03-01',
                               now()::date, '1 month') as r
                               ),
                               
"REITING" as (select distinct 
"Event".*
,date_trunc('month', "Дата")::date as "Date_Start"
,date_trunc('month', "Date_End_1")::date as "Date_End"

from "Event"
where
"Penalty"<>0
),


"ITOG_REITING" as (
select 
"REITING".*
,(("OBJID")::TEXT||EXTRACT(year FROM "r"::date)||EXTRACT(Month FROM "r"::date))::numeric  as "STRUCT_YEAR_MONTH"
,case 
	when "OBJID"::TEXT||EXTRACT(year FROM "r"::date)||EXTRACT(Month FROM "r"::date)="OBJID"::TEXT||EXTRACT(year FROM "Дата"::date)||EXTRACT(Month FROM "Дата"::date)
then 1
   else 0
end as "STRUCT_YEAR_MONTH_FAKT"   

from "REITING", "CALENDAR" 

/*___________________ объединени двух таблиц_____________________________________*/		          
where "CALENDAR"."r" between "Date_Start" and "Date_End"
and "Дата">=to_date('01032023','ddmmyyyy')
order by "Дата"
),

/*___________________ генерация виртуального календаря по одной на каждую неделю_____________________________________*/	
"CALENDAR_monts" as (
	SELECT 	distinct 
	r::date as "DATE"
		,EXTRACT(month from r) as "№_месяца"

	FROM generate_series('2023-01-01',now()::date, '1 day') as r
		
		),
		
/*___________________ ищем травмы с периодом нетрудоспособности _____________________________________*/	
"TRAVM_RATING" as (
select 
"Injurys"."Id" as "CardID"
,"InjuryDate"::date
,"TRAVM"."EmployeeFio"
,"TRAVM"."InternalEmployeeId"
,"E1"."PersonalNumber"
,'https://kot.severstal.com/injuries/injuries-severstal/'||"Injurys"."Id" as "LinkCard"
,"ThirdPersonFio"
,"InjuryHurtSeverstal"."SickDaysBegin"::date as "DATE_START"
,case 
	when "TRAVM"."SickFinishDate" is null
then now()::date
	else "TRAVM"."SickFinishDate"::date 
end as "DATE_END"

,"REKURS"."WORKS_OBJID" as "WORKS_OBJID"
,"InjurySeverstalResponsibleDepartments"."DepartmentId"
,"REKURS"."ID_KOT"

from "InjuryHurt"  as "TRAVM" 

left join "Employees" as "E1" 
	on "TRAVM"."InternalEmployeeId"="E1"."Id"  -- фио травмировавшегося в единой базе кота с учетом уволенных
left join "Injurys" 
	on "TRAVM"."SingleInjuryId"="Injurys"."Id" or "TRAVM"."SingleInjuryId"="Injurys"."Id" -- реестр или групповое или единичное

left join "InjuryHurtSeverstal" 
	on "TRAVM"."Id"="InjuryHurtSeverstal"."InjuryHurtId" 

LEFT JOIN "InjurySeverstal"  
	ON "TRAVM"."SingleInjuryId" = "InjurySeverstal"."InjuryId" -- для единичного травматизма

/*_____ связываем с таблицей "Ответствееность (Внутреннее расследование)" Виновник (собственный персонал)   ________*/	
LEFT JOIN "InjurySeverstalResponsibleDepartments" 
	ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId"
 and (("InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null )
	and	"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" in (1))	
	
	/*___________________ связываем с рекурсией для получения цеха виновника _____________________________________*/		
left join	"REKURS" 
	on "REKURS"."ID_KOT"="InjurySeverstalResponsibleDepartments"."DepartmentId"
	
	
where 
("TRAVM"."EmployeeFio" is not null or "TRAVM"."ThirdPersonFio"is not null) 
and ("TRAVM"."IsActual" is null or "TRAVM"."IsActual" in (true))
--and "Injurys"."Id" in (4503) --тест на карте

),



"ITOG_TRAVM" as (
select 
"TRAVM_RATING"."CardID"
,"TRAVM_RATING"."LinkCard" 
,"TRAVM_RATING"."InjuryDate" as "Дата"
,"WORKS_OBJID"::numeric as "OBJID"
,'Допущен травматизм с потерей трудоспособности' as "Name"
,count("DATE")*-3 as "Penalty"
,"TRAVM_RATING"."DATE_END" as "Date_End_1"
,"TRAVM_RATING"."DATE_START" as "Date_Start"
,"TRAVM_RATING"."DATE_END" as "Date_End"
,(("WORKS_OBJID"::numeric)::text||EXTRACT(year FROM max("DATE")::date)||EXTRACT(Month FROM max("DATE")::date))::numeric as "STRUCT_YEAR_MONTH"
,case 
	when "WORKS_OBJID"::TEXT||EXTRACT(year FROM "TRAVM_RATING"."InjuryDate"::date)||EXTRACT(Month FROM "TRAVM_RATING"."InjuryDate"::date)
="WORKS_OBJID"::TEXT||EXTRACT(year FROM max("DATE")::date)||EXTRACT(Month FROM max("DATE")::date)
        then 1
      		 else 0
       end as "STRUCT_YEAR_MONTH_FAKT"

from "TRAVM_RATING","CALENDAR_monts"

/*___________________ объединение с каледарем_____________________________________*/	
where "CALENDAR_monts"."DATE" between "TRAVM_RATING"."DATE_START" and "TRAVM_RATING"."DATE_END"

group by "TRAVM_RATING"."CardID"
,"TRAVM_RATING"."InjuryDate"
,"TRAVM_RATING"."EmployeeFio"
,"TRAVM_RATING"."InternalEmployeeId"
,"TRAVM_RATING"."PersonalNumber"
,"TRAVM_RATING"."LinkCard"
,"TRAVM_RATING"."ThirdPersonFio"
,"TRAVM_RATING"."DATE_START"
,"TRAVM_RATING"."DATE_END"
,"№_месяца"
,"WORKS_OBJID"
),

/* берем происшествия в те месяцы, в которых нужно обнулять ЧЧ  */
"ITOG_TRAVM_TABEL" as (
select "STRUCT_YEAR_MONTH",max ("STRUCT_YEAR_MONTH_FAKT") as"STRUCT_YEAR_MONTH_FAKT"  from "ITOG_TRAVM"
where "STRUCT_YEAR_MONTH_FAKT" in (1)
group by "STRUCT_YEAR_MONTH"

union
select "STRUCT_YEAR_MONTH",max ("STRUCT_YEAR_MONTH_FAKT") as"STRUCT_YEAR_MONTH_FAKT"  from "ITOG_REITING"
where "STRUCT_YEAR_MONTH_FAKT" in (1)
group by "STRUCT_YEAR_MONTH"

),
/*___ переводки основные и временные ____*/
FOREMAN AS (
SELECT distinct
"NHRS"."FIO_TN"||','||chr(10)||"PA0001".OBJID_A_NAME as "FIO_TN_PROF"
,"PA0001".STRUCT_ID
,"PA0001".BEGDA as BEGDA
,CASE 
	WHEN  "PA0001".ENDDA::date>now()::date 
		THEN now()::date
	ELSE "PA0001".ENDDA::date
		END as ENDDA
,"PA0001".ORGEH::numeric as OBJID_A
,"PA0001".OBJID_A_NAME
,"PA0001".HRSROOT_ID
,"PA0001".PERNR
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"

left join 
	(select distinct 
case 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
			||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
				||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
					||chr(10)||'('||HRSROOT_ID||')'
	else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||TN||')'
				end as"FIO_TN"
		,CASE 
			WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
		THEN HRSROOT_ID
			ELSE TN 
		END AS PERNR   
		FROM otpb.power_bi_nhrs_full_mv
		 where 
		(DATE_END::date>to_date('01012018','ddmmyyyy') or DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
		AND TYPE_WORKER NOT IN ('Ученичество','Практика')) "NHRS"
		on "NHRS".pernr="PA0001".PERNR

WHERE ("PA0001".MASSN_NAME NOT IN ('Приостановление действия ТД','Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
	OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
	AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') 
	and "NHRS"."FIO_TN" is not null
		
UNION all--из НХРС начальники
select 
case 
	WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||"FULL".HRSROOT_ID||'),'
					||chr(10)||PROF_P
else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
	||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
		||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
			||chr(10)||'('||TN||'),'
				||chr(10)||PROF_P
	
	end as "FIO_TN_PROF"
,"FULL".STRUCT_ID
,"FULL".DATE_BEG::date as BEGDA
, CASE 
	WHEN  "FULL".DATE_END::date>now()::date	
		THEN now()::date
	WHEN  "FULL".DATE_END::date IS NULL AND "FULL".DATE_OF_DISMISSAL::date IS NOT NULL
		THEN "FULL".DATE_OF_DISMISSAL::date
	WHEN  "FULL".DATE_END::date IS NULL	
		THEN now()::date 
	ELSE "FULL".DATE_END::date 
		END as ENDDA
,STRUCT_OBJID.OBJID::numeric  as OBJID_A
,PROF_P AS OBJID_A_NAME
	,"FULL".HRSROOT_ID
	,CASE 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	THEN "FULL".HRSROOT_ID
		ELSE TN 
	END AS PERNR   
	FROM otpb.power_bi_nhrs_full_mv "FULL"
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
	on "FULL".STRUCT_ID=STRUCT_OBJID."struct_id"
		 
left join (
SELECT distinct
"PA0001".HRSROOT_ID
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"
WHERE ("PA0001".MASSN_NAME NOT IN ('Приостановление действия ТД','Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
	OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
	AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') 
		) "PA001"
	on  "PA001".HRSROOT_ID="FULL".HRSROOT_ID
	where 
	("FULL".DATE_END::date>to_date('01012018','ddmmyyyy') or "FULL".DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
	AND TYPE_WORKER NOT IN ('Ученичество','Практика') 
	and "PA001".HRSROOT_ID is null
	),

	/* _____ соединяем с перекодировочной struct_id и OBJID    _____  */
"FOREMAN_OBJID" as (
select FOREMAN.*
,"REKURS"."L_REITING"::numeric  as "OBJID_Цех"
,"REKURS"."WORKSHOPS" as "Цех"
from FOREMAN
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
	on FOREMAN.STRUCT_ID=STRUCT_OBJID."struct_id"

/*_________ связь с рекурсией для вывода цеха Аудитора  ________________*/
left join "REKURS"  
	on "REKURS"."OBJID"::numeric =STRUCT_OBJID.OBJID::numeric	
	where FOREMAN.PERNR>0
	--and FOREMAN.PERNR in (10608275) --тест
	and "REKURS"."L_REITING" is not null
), 
 
/* берем человекочасы и группируем по человеку, году и месяцу */
"TABEL" as (
SELECT
	year as "year"
	,month as "month"
	,sum (FACT_H) as "WORK_TIME"
	,PERNR as "PERNR_TABEL"
	,to_date('01.'||MONTH||'.'||YEAR,'dd.mm.yyyy') as "DATE"
FROM (
			SELECT
			to_char(DATA,'YYYY') as YEAR,
			to_char(DATA,'MM') as MONTH,
			PERNR,
			CASE 
				WHEN FACT_H>24
			THEN FACT_H-24 
				ELSE FACT_H 
			END as FACT_H
			FROM otpb.idb33_zhcmi896_tbt_mv
			where
			--PERNR in ('10479547') and --фильтр по Бердину
			DATA>=to_date('01012024','ddmmyyyy')
			and FACT_H>0
			and status_ch not in (3)
) M_HOUR
GROUP BY YEAR,MONTH,PERNR
),

/* Соединяем таблицу с переводками с таблицей с табелем сгруппированным по месяцу и человеку  */
"TABEL_FOREMAN_OBJID" as (
select
"FOREMAN_OBJID"."OBJID_Цех"
,"FOREMAN_OBJID"."Цех"
,"TABEL"."year"
,"TABEL"."month"
,sum ("TABEL"."WORK_TIME") as "WORK_TIME"
,("FOREMAN_OBJID"."OBJID_Цех"||"TABEL"."year"||("TABEL"."month")::numeric)::numeric as "STRUCT_YEAR_MONTH"

from "FOREMAN_OBJID"
left join "TABEL"
	on "TABEL"."PERNR_TABEL"="FOREMAN_OBJID".PERNR
		and "TABEL"."DATE" between  "FOREMAN_OBJID".BEGDA and "FOREMAN_OBJID".ENDDA

where 	"TABEL"."year" is not null 
--and  "FOREMAN_OBJID"."OBJID_Цех" in (20035433,20057063)
	

group by "FOREMAN_OBJID"."OBJID_Цех","FOREMAN_OBJID"."Цех","TABEL"."year","TABEL"."month"

ORDER by "OBJID_Цех","year","month"
),

/* Соединяем таблицу с переводками с происшествиями  */
"TABEL_Injury" as (
select
	"TABEL_FOREMAN_OBJID"."OBJID_Цех"
	,"TABEL_FOREMAN_OBJID"."Цех"
	,"TABEL_FOREMAN_OBJID"."year"
	,"TABEL_FOREMAN_OBJID"."month"
	,"TABEL_FOREMAN_OBJID"."STRUCT_YEAR_MONTH"
	,case 
		when "ITOG_TRAVM_TABEL"."STRUCT_YEAR_MONTH_FAKT"=1
	then 0
			when "TABEL_FOREMAN_OBJID"."WORK_TIME" is null
	then 0
		else "TABEL_FOREMAN_OBJID"."WORK_TIME"
	end as "WORK_TIME"
	,"ITOG_TRAVM_TABEL"."STRUCT_YEAR_MONTH_FAKT"
from "TABEL_FOREMAN_OBJID"
	left join "ITOG_TRAVM_TABEL"
		on "ITOG_TRAVM_TABEL"."STRUCT_YEAR_MONTH"="TABEL_FOREMAN_OBJID"."STRUCT_YEAR_MONTH"

--where 	"TABEL_FOREMAN_OBJID"."STRUCT_YEAR_MONTH" in (20035433202411)
ORDER by "STRUCT_YEAR_MONTH","year","month"
),

/* Итоговый расчет с нарастающим итогом */
"ITOG" as (
select 
"OBJID_Цех" as "ORG_ID"
,"Цех"
,"year"
,"month"
,"STRUCT_YEAR_MONTH"
,"STRUCT_YEAR_MONTH_FAKT"
,ROW_NUMBER() OVER (partition BY "OBJID_Цех" ORDER BY "OBJID_Цех","year","month") AS "Index"
,"WORK_TIME"
from "TABEL_Injury"
ORDER by "OBJID_Цех","year","month"
)

select 
*
from "ITOG"
