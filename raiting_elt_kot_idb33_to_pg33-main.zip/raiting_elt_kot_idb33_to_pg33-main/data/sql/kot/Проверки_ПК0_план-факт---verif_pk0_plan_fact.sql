
WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" in (true)
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),

"CALENDAR" as (
SELECT (EXTRACT(year  from r)::text||EXTRACT(month  from r)::text) as "year_month"
FROM generate_series('2024-02-01',now()::date, '1 month') as r
			),
	
/*справочник Ответственные лица.Рейтинг цехов. Максимальный балл ПК-1*/
"MAX" as (
select 
"D1"."DepartmentName" as "Цех" -- Цех
,"Ref_OTV"."Name"
,"import"."ExternalId"::numeric  as "OBJID"
,"ResponsibilityTypeId"
       
from "EmployeeResponsibilityInDepartments" "ref_shop"

	left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id" -- цех
	left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" -- название ответственности
	left join "ImportDepartments" as "import" on "D1"."Id"="import"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
where "ResponsibilityTypeId" in (183) --183 - Рейтинг цехов. Максимальный балл Проверка локаций и КББ (ОРБ),184 - Рейтинг цехов. Максимальный балл ПК-1
and "ref_shop"."IsActual" IN (true)
),
			
maximum as (
select 
("MAX"."OBJID"::text||"CALENDAR"."year_month")::numeric as "STRUCT_YEAR_MONTH"
,1 as "PLAN"
,1 as "FACT"
from "CALENDAR","MAX"		
),

f as ( -- id смен, где проверены все КББ оборудования
select distinct  s."Id"
from public."Shifts" s 
join public."ShiftEquipment" se on s."Id"=se."ShiftId"
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true
where s."DeleteDateTime" is null
group by s."Id"
having count(se."WatchingTime")=COUNT(se."ShiftLogEquipmentId")
)
,res as (
select 
distinct  
 s."Id"  -- Id смены
,s."ShiftLogId" --Id журнала 
,s."StartDateTime"  --Время приёма смены
,s."EndDateTime"  --Время сдачи смены
,MAX(se."WatchingTime") WATCHINGTIME 
,case 
	when e4."ExternalOrganizationId" is null 
	then concat(e4."LastName",' ',substring(e4."FirstName" from 1 for 1),'.',substring(e4."SecondName" from 1 for 1),'. (',cast(replace(e4."PersonalNumber",':','') as numeric),')') 
	--else concat(e4."LastName",' ',substring(e4."FirstName" from 1 for 1),'.',substring(e4."SecondName" from 1 for 1),'. (ПО)') --подрядчики
	else concat(e4."LastName",' ',e4."FirstName",' ',e4."SecondName",' (ПО)') --подрядчики, полное ФИО
	end "FIO (TN)"  --Сменщик "ID_WORKER"
,s."CrewId" --Бригада
,count(se."WatchingTime") q_fact 
,count(se."ShiftLogEquipmentId") q_plan
,case 
	when s."IsWithdrawalReserve"=true
	then 1
	when f."Id" is not null 
	then 1 
	else 0 
	end  fact_1
,id."ExternalId"::numeric  REVISIONDEPARTMENTID
,case 
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  (s."StartDateTime"::time>=sl."TimeNight"-interval '1' hour)-- or s."StartDateTime"::time<sl."TimeDay"-interval '1' hour ) 
	then s."StartDateTime"::date+sl."TimeNight"
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  ( s."StartDateTime"::time<sl."TimeDay"-interval '1' hour ) 
	then s."StartDateTime"::date-1+sl."TimeNight"
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  (s."StartDateTime"::time<sl."TimeNight"-interval '1' hour or s."StartDateTime"::time>=sl."TimeDay"-interval '1' hour) 
	then s."StartDateTime"::date+sl."TimeDay"  
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is null or "TimeNight"='00:00:00')  
	then s."StartDateTime"::date+sl."TimeDay" 
	when ("TimeDay" is null or "TimeDay"='00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') 
	then s."StartDateTime"::date+sl."TimeNight"
	else s."StartDateTime" 
	end "Начало смены"
,case 
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  (s."StartDateTime"::time>=sl."TimeNight"-interval '1' hour)-- or s."StartDateTime"::time<sl."TimeDay"-interval '1' hour ) 
	then s."StartDateTime"::date+sl."TimeNight"+interval '1 minute'* sl."TimeToAcceptance"
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  ( s."StartDateTime"::time<sl."TimeDay"-interval '1' hour ) 
	then s."StartDateTime"::date-1+sl."TimeNight"+interval '1 minute'* sl."TimeToAcceptance"
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  (s."StartDateTime"::time<sl."TimeNight"-interval '1' hour or s."StartDateTime"::time>=sl."TimeDay"-interval '1' hour) and sl."TimeToAcceptance" is not null
	then s."StartDateTime"::date+sl."TimeDay"+interval '1 minute'* sl."TimeToAcceptance"  
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is null or "TimeNight"='00:00:00') and sl."TimeToAcceptance" is not null
	then s."StartDateTime"::date+sl."TimeDay"+interval '1 minute'* sl."TimeToAcceptance"
	when ("TimeDay" is null or "TimeDay"='00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and sl."TimeToAcceptance" is not null
	then s."StartDateTime"::date+sl."TimeNight"+interval '1 minute'* sl."TimeToAcceptance"
	end "Конец приемки смены"
,case 
	when ("TimeDay" is not null or "TimeDay"<>'00:00:00') and ("TimeNight" is not null or "TimeNight"<>'00:00:00') and  
	(s."StartDateTime"::time>=sl."TimeNight"-interval '1' hour or s."StartDateTime"::time<sl."TimeDay"-interval '1' hour) --интервал между началами смены со сдвигом на час назад (те, кто пришел раньше и заполнил)
	then 'ночь' 
	else 'день' 
	end "смена"
,s."ShiftNumber"  --Номер смены
,case 
	when ("TimeDay" is null or "TimeDay"='00:00:00') and ("TimeNight" is null or "TimeNight"='00:00:00') 
	then 1 
	else 0 
	end "Периодически используемые"
,case 
	when sl."TimeDay"='00:00:00' then null
	else sl."TimeDay" end "TimeDay"
,case 
	when "TimeNight"='00:00:00'	then null 
	else sl."TimeNight" end "TimeNight"
,sl."TimeToAcceptance", s."IsWithdrawalReserve" 
FROM 
public."Shifts" s 
left join f ON s."Id"=f."Id" --только заполненные КББ
join public."Employees" e4 on s."EmployeeId"=e4."Id" 
join public."ShiftLogs" sl on s."ShiftLogId"=sl."Id" and sl."IsActual"=true
left join public."ShiftEquipment" se on s."Id"=se."ShiftId" 
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
join public."ImportDepartments" id on sl."DepartmentId"=id."DepartmentId" 
where s."DeleteDateTime" is null  and s."IsActual" =true
group by s."Id"  -- Id смены
,s."ShiftLogId" --Id журнала 
,s."StartDateTime"  --Время приёма смены
,s."EndDateTime"  --Время сдачи смены
,e4."LastName",e4."FirstName",e4."SecondName",e4."PersonalNumber",e4."ExternalOrganizationId" 
,s."CrewId" --Бригада
,s."ShiftNumber"  --Номер смены
,id."ExternalId"
,sl."TimeDay",sl."TimeNight",sl."TimeToAcceptance" 
,f."Id", s."IsWithdrawalReserve"  )
,res2 as ( --промежуточная таблица для поиска айди смены после выхода из резерва
select distinct  
 res."Id"  -- Id смены
,res."ShiftLogId" --Id журнала
,max(r."Id") "Id2"
from res
join res r on res."ShiftLogId"=r."ShiftLogId" and r."IsWithdrawalReserve"=true and res."IsWithdrawalReserve"=false and res."Id">r."Id"
group by res."Id"  
,res."ShiftLogId")
,res3 as ( --таблица для поиска айди смены после выхода из резерва
select distinct  
 min(res2."Id")  "Id"-- Id смены
,res2."ShiftLogId" --Id журнала
,res2."Id2" 
from res2
group by res2."Id2"  
,res2."ShiftLogId" )
,loc_ontime as (
select 
distinct  
 res."ShiftLogId" --Id журнала 
,res."CrewId" --Бригада
,case 
	when res."Конец приемки смены" is not null and	res.WATCHINGTIME between res."StartDateTime" and res."Конец приемки смены"
	then 1 
	else 0 
	end "По расписанию"
,res.REVISIONDEPARTMENTID
,res."TimeToAcceptance"
,case
	when res.WATCHINGTIME::time<res."TimeDay" and res."StartDateTime"::date=res.WATCHINGTIME::date-1 then res."StartDateTime"::date--ночная смена отн-ся к пред.дню.несмотря что проверка была за час до дн.смены (смена началась накануне)
	when res.WATCHINGTIME::time<res."TimeDay" and res."StartDateTime"::time<res."TimeDay"-interval '1' hour and res."StartDateTime"::date=res.WATCHINGTIME::date then res."StartDateTime"::date-1--ночная смена отн-ся к пред.дню.несмотря что проверка была за час до дн.смены (смена началась накануне)
	when res.WATCHINGTIME::time<(res."TimeDay"-interval '1' hour) then res.WATCHINGTIME::date-1 --ночная смена отн-ся к пред.дню
else res.WATCHINGTIME::date 
end "Дата"
from res
where res.WATCHINGTIME between res."StartDateTime" and res."Конец приемки смены"
and res."TimeToAcceptance" is not null and res."TimeToAcceptance" > 0 and res."TimeToAcceptance"<720)

,res4 as (
select distinct  
 res."Id"  -- Id смены
,res."ShiftLogId" --Id журнала 
,res."StartDateTime"
,res."EndDateTime"  --Время сдачи смены
,res.WATCHINGTIME 
,res."FIO (TN)"   --Сменщик "ID_WORKER"
,res."CrewId" --Бригада
,res.q_fact 
,res.q_plan
,res.fact_1
,case 
	when lo."По расписанию"=1 then 1 
	when res."TimeToAcceptance" is null then 1
	when res."TimeToAcceptance" >= 720 then 1
	when res.WATCHINGTIME is null then null
	when ("TimeDay" is null or "TimeDay"='00:00:00') and ("TimeNight" is null or "TimeNight"='00:00:00')  then 1
	when res3."Id" is not null and res.WATCHINGTIME between res."StartDateTime" and res."StartDateTime"+interval '1 minute'*res."TimeToAcceptance" then 1 --журналы из резерва считаются от начала входа в журнал
	when res."Конец приемки смены" is not null and	res.WATCHINGTIME between res."StartDateTime" and res."Конец приемки смены"
	then 1 
	else 0 
	end "По расписанию"
--,res.REVISIONDEPARTMENTID
,res."Начало смены"
,res."Конец приемки смены"
,res."смена"
,res."ShiftNumber"
,res."Периодически используемые"
,case 
	when res."IsWithdrawalReserve"=true then 1 end "IsWithdrawalReserve"
,case
	when res.WATCHINGTIME is null and res."StartDateTime"::time<res."TimeDay"-interval '1' hour then res."StartDateTime"::date-1 
	when res.WATCHINGTIME is null  then res."StartDateTime"::date  
	when res.WATCHINGTIME::time<res."TimeDay" and res."StartDateTime"::date=res.WATCHINGTIME::date-1 then res."StartDateTime"::date--ночная смена отн-ся к пред.дню.несмотря что проверка была за час до дн.смены (смена началась накануне)
	when res.WATCHINGTIME::time<res."TimeDay" and res."StartDateTime"::time<res."TimeDay"-interval '1' hour and res."StartDateTime"::date=res.WATCHINGTIME::date then res."StartDateTime"::date-1--ночная смена отн-ся к пред.дню.несмотря что проверка была за час до дн.смены (смена началась накануне)
	when res.WATCHINGTIME::time<(res."TimeDay"-interval '1' hour) then res.WATCHINGTIME::date-1 --ночная смена отн-ся к пред.дню
else res.WATCHINGTIME::date 
end "Дата"
,"REKURS"."L_REITING" as REVISIONDEPARTMENTID

from res
left join res3 on res."Id"=res3."Id"
left join loc_ontime lo 
	on res."ShiftLogId"=lo."ShiftLogId" 
	and res.revisiondepartmentid=lo.revisiondepartmentid 
		and res."CrewId"=lo."CrewId"
			and (res.WATCHINGTIME::date=lo."Дата" or res.WATCHINGTIME::date=lo."Дата"-1)

/*_________ связь с рекурсией для вывода журналов ниже цеха  ________________*/
left join "REKURS"  -- 
	on "REKURS"."OBJID"::numeric=res.REVISIONDEPARTMENTID::numeric	

),

group_smena as(
select 
case 
	when fact_1=1 
then count (distinct "Id") 
	else 0
end as fact_1 
,count (distinct "Id") as "PLAN"
,"Дата"
,revisiondepartmentid
,"ShiftLogId"
--,смена
,((revisiondepartmentid::integer)::text||EXTRACT(year from "Дата")||EXTRACT(months from "Дата"))::numeric   as STRUCT_YEAR_MONTH

from res4
--where 
--REVISIONDEPARTMENTID IN (20008399)
--AND "Дата" >=to_date('01102024','ddmmyyyy') and "Дата" <= to_date('31102024','ddmmyyyy')
group by
"Дата"
,revisiondepartmentid
,"ShiftLogId"
--,смена
,fact_1
),

ITOG as (
select 
STRUCT_YEAR_MONTH as "STRUCT_YEAR_MONTH"
,sum ("PLAN") as "PLAN"
,sum(FACT_1) as "FACT"


from group_smena
group by STRUCT_YEAR_MONTH
)

--SELECT * FROM group_smena
/*WHERE REVISIONDEPARTMENTID IN (20008397)
AND "Дата" >=to_date('01102024','ddmmyyyy') and "Дата" <= to_date('31102024','ddmmyyyy')
*/

select * from ITOG
union
select * from maximum
--where "STRUCT_YEAR_MONTH" in (20008397202410) 