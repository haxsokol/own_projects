WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                         when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                          else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
                        left join "ImportDepartments" as "importd" 
                             on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
                        on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
                            and"Description" IN ('Рейтинг цеха')
                                and "Documents"."IsActual" in (true)
                                                 
                             
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
        and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
            and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),
/* _______________ Связываем для выявления желтой и красной зоны из справочника __________________________*/    
"RAIT" as (
select 
"AuditIndustryRatings"."StartDate"
,case 
    when "AuditIndustryRatings"."EndDate" is null
then now()
    else "AuditIndustryRatings"."EndDate"
end as "EndDate"
,"AuditIndustryRatings"."AuditIndustryKindId"
,"AuditIndustryRatings"."RatingGrade"
,"AuditIndustryRatings"."MinAmount"
,case 
    when "AuditIndustryRatings"."MaxAmount">1 and "AuditIndustryRatings"."MaxAmount"=100 -- от 0 до 100, и 100, тогда 100
then 100
        when "AuditIndustryRatings"."MaxAmount">1  -- от 0 до 100, и не 100, тогда минус 1, т.к. исключительно
    then "AuditIndustryRatings"."MaxAmount"-1
            when "AuditIndustryRatings"."MaxAmount"<=1 and "AuditIndustryRatings"."MaxAmount"=1 -- от 0 до 1, и 1, тогда 1
        then 1
                when "AuditIndustryRatings"."MaxAmount"<=1 -- от 0 до 1, и НЕ 1, тогда минус 0.01, т.к. исключительно
            then "AuditIndustryRatings"."MaxAmount"-0.01
        else 0
end as "MaxAmount"
, case 
    when "AuditIndustryRatings"."RatingGrade" in ('Амбиция','Безопасная зона','   Все требования соблюдены, замечания и несоответствия отсутствуют.', 'Удовлетворительно')
then 'Зеленая зона'
    when "AuditIndustryRatings"."RatingGrade" in ('База','Зона внимания')
then 'Желтая зона'  
    else 'Красная зона'
end as "NEUD"
, case 
    when "AuditIndustryRatings"."RatingGrade" in ('Амбиция','Безопасная зона','   Все требования соблюдены, замечания и несоответствия отсутствуют.','Удовлетворительно')
then 0
    when "AuditIndustryRatings"."RatingGrade" in ('База','Зона внимания')
then 10 
    else 30
end as "Ball"
,"AuditIndustryRatings"."IsActual" in (true) as "Актуальность"

from    "AuditIndustryRatings"

where "AuditIndustryRatings"."AuditIndustryKindId" not in (34, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 61, 27, 63, 28, 29, 30, 31, 32, 65, 66, 62, 64, 67, 105, 106, 107, 103, 108, 
109, 110, 111, 112, 113, 114, 115, 126, 163, 220, 269, 401, 717, 1140, 12, 217, 218, 118, 119, 96, 121, 122, 123, 124, 125, 271, 216, 219, 272, 312, 273, 313, 
274, 275, 311, 314, 315, 397, 398, 399, 458, 459, 1023, 120, 1122, 1074, 1071, 1081, 1075, 1041, 1141, 615, 450, 452, 453, 454, 455, 456, 457, 460, 461, 470, 
471, 963, 967, 968, 965, 624, 619, 620, 625, 626, 627, 718, 719, 720, 721, 722, 723, 813, 827, 877, 1022, 449, 1120, 469, 468, 463, 462, 1076, 1078, 1077, 1079, 
1083, 1085, 1024, 970, 969, 971, 1145, 988, 1088, 1119, 1073, 987, 1086, 1144, 1070, 1175, 1040, 1082, 708, 709, 520, 710, 712, 713, 518, 360, 959, 958, 964, 966, 
962, 960, 961, 97, 98, 99, 100, 101, 102, 116, 117,201,202,224,221,222,223,400,451,466,989,200,1080,1102,1093,1121,1092,361,359)

-- ДОБАВИЛ ЭТУ СТРОКУ, УБРАТЬ ПОСЛЕ ТОГО, КАК РЕШАТ ВОПРОС С -infifnity в "AuditIndustryRatings"."StartDate"
--AND "AuditIndustryRatings"."IsActual" = TRUE


), 

"PROIZVODITEL" as (
select 
    "AC"."Id" as "CardId"
    ,'https://kot.severstal.com/audits_industry/card/'||"AC"."Id" as "LinkCard"
    ,"RAIT"."Ball"
    ,"RAIT"."NEUD"
    ,"RAIT"."AuditIndustryKindId"
    ,"FinalScore" as "%"
    ,"ExecutionDate" as "DATE"
    ,"DepartmentName"
    ,"D"."Id" as "MESTO_AUDITA"
    ,("import"."ExternalId"||EXTRACT(year FROM "ExecutionDate"::date)||EXTRACT(Month FROM "ExecutionDate"::date))::numeric as "STRUCT_YEAR_MONTH"
    ,"GroupOfDirectionId"
    ,case 
         when 
   "E1"."Discriminator" in ('ExternalEmployee')
   then     "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                                ||', '||"E1"."Position"  -- должность    
   
    else     "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                ||', '||"PN1"."Name" -- должность                       
                                
                       end   as  "Аудитор" 
     ,case 
         when 
   "E1"."Discriminator" in ('ExternalEmployee')
   then    "E1"."Position"  -- должность внутренняя
   
    else     "PN1"."Name" -- должность внешняя             
                                
                       end   as  "Должность_Аудитора"                   
                       
                       
    ,case 
         when "ImportExternalEmployees"."ExternalId" is not null
    then     "ImportExternalEmployees". "ExternalId"
        else    "E1"."PersonalNumber" 
    end as "TN_Auditor" 
    ,"PT1"."DepartmentId" as "Место_Работы_Аудитора"

    , case 
        when "REKURS2"."NAME" is not null
    then "REKURS2"."NAME"
        else "ExOrg_A"."Name"
    end as "МЕСТО_РАБ_АУДИТОРА_ПОДР"
    
    , case 
        when "E2"."PersonalNumber" is null
    then 'Подрядчик'
    else    
    "E2"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E2"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E2"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E2"."PersonalNumber"||')'--табльный номер
     end as "Проверяемый" 
    ,"E2"."PersonalNumber" as "TN_Проверяемого" 
   ,"PT2"."DepartmentId" as "Место_Работы_Проверяемого"
    ,"AIK"."DirectionAuditCheckId" --идентифиактор аудита
    ,"AIK"."Name" -- название аудита
    ,"AC"."AuditorPkLevel"

        
    FROM "AuditIndustryCards" as "AC"

/* _______________ Связь с событиями __________________________*/  
left join "Events" as "EV" -- Событие к аудиту
       on "AC"."EventId"="EV"."Id"
/* _______________ Связь с подразделениями __________________________*/  
left join "EventDepartments" as "ED" -- Событие к аудиту
       on "ED"."EventId"="EV"."Id"
       
 /* _______________Место проведения Аудита__________________________*/
join "Departments" as "D"
       on "ED"."DepartmentId"="D"."Id"      

/* _______________ перекодировочная для OBJID цехов __________________________*/     
left join "ImportDepartments" as "import"  
    on "D"."Id"::integer="import"."DepartmentId"::integer -- цех OBJID цехов    */  
       
       
/* _______________ Для определения вида аудита и фильтра по нему __________________________*/  
left join "AuditIndustryKinds" as "AIK"--Вид аудита
       on "AC"."AuditKindId"= "AIK"."Id" --and "AIK"."IsActual" in (true)

/* _______________ Связываем с таблицей задействованные лица __________________________*/  
left join "InvolvedAuditIndustry" as "STAK"--задействованные лица
       on "AC"."Id"= "STAK"."AuditIndustryCardId" 
       and "STAK"."IsActual" in (true)  and     "STAK"."TypeOfInvolved"=0 --берем только актульные записи и только аудиторов (0), если 1 - соаудиторы

/* _______________ Связываем с расшифровкой задействованные лица. вытаскиваем ИД аудитора __________________________*/  
left join "EventParticipants" as "UCHASTNIK_AUDITOR"--задействованные лица
       on "STAK"."EventParticipantId"= "UCHASTNIK_AUDITOR"."Id" 
       and "UCHASTNIK_AUDITOR"."IsActual" in (true) --берем только актульные записи

/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/  
left join "Employees" as "E1" --задействованные лица
       on "UCHASTNIK_AUDITOR"."EmployeeId"= "E1"."Id" 
       and "E1"."IsActual" IN (true) --берем только актульные записи

/* _______________ Связываем с таблицей персонала Employees Назначение сотрудника__________________________*/  
 left join "InternalEmployeePositionTypes" as "IEPT1" -- Назначение сотрудника
    on "E1"."Id"="IEPT1"."InternalEmployeeId" and "IEPT1"."IsActual" in (true)

/* _______________ Связываем с таблицей подрядного персонала ImportExternalEmployees для вывода личного номера аудитора__________________________*/  
 left join "ImportExternalEmployees"    
    on "E1"."Id"="ImportExternalEmployees"."ExternalEmployeeId" and "ImportExternalEmployees"."IsActual" in (true)
 
/* _______________ Связываем Назначение сотрудника с место работы аудитора __________________________*/  
left join "PositionTypes" as "PT1" -- место работы аудитора
    on "IEPT1"."PositionTypeId"="PT1"."Id" --and "PT1"."IsActual" in (true)

    /* _______________Место работы Аудиора, рашифровка из рекурсии__________________________*/
left join "REKURS" as  "REKURS2"
    on  "REKURS2"."ID_KOT"="PT1"."DepartmentId"     
    
left join "PositionNames" as "PN1" -- должность аудитора    
    on "PT1"."PositionNameId" = "PN1"."Id" and  "PN1"."IsActual" in (true)  
    
left join "ExternalOrganizations" as "ExOrg_A" -- Подрядная организация аудитора
    on "E1"."ExternalOrganizationId"="ExOrg_A"."Id"and "ExOrg_A"."IsActual" IN (true)
    
/* _______________ Связываем с таблицей Ответственные лица аудита __________________________*/  
left join "ResponsibleForAuditIndustry" as "OTV"--задействованные лица
       on "AC"."Id"= "OTV"."AuditIndustryCardId" 
       and "OTV"."IsActual" in (true)  and     "OTV"."ResponsibilityType"=0 --берем только актульные записи и проверяемого (0), если 1 - Руководители проекта

/* _______________ Связываем с расшифровкой Ответственные лица. вытаскиваем ИД проверяемого __________________________*/  
left join "EventParticipants" as "UCHASTNIK_PROVERZEM"--задействованные лица
       on "OTV"."EventParticipantId"= "UCHASTNIK_PROVERZEM"."Id" 
       and "UCHASTNIK_PROVERZEM"."IsActual" in (true) --берем только актульные записи
     
/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/  
left join "Employees" as "E2" --задействованные лица
       on "UCHASTNIK_PROVERZEM"."EmployeeId"= "E2"."Id" 
       and "E2"."IsActual" IN (true) --берем только актульные записи
     
/* _______________ Связываем с таблицей персонала Employees Назначение сотрудника__________________________*/  
 left join "InternalEmployeePositionTypes" as "IEPT2" -- Назначение сотрудника
    on "E2"."Id"="IEPT2"."InternalEmployeeId" and "IEPT2"."IsActual" in (true)

/* _______________ Связываем Назначение сотрудника с место работы аудитора __________________________*/  
left join "PositionTypes" as "PT2" -- место работы аудитора
    on "IEPT2"."PositionTypeId"="PT2"."Id" --and "PT1"."IsActual" in (true)
    
/* _______________ Связываем для выявления желтой и красной зоны из справочника __________________________*/    
left join   "AuditIndustryRatings"
    on "AIK"."Id"="AuditIndustryRatings"."AuditIndustryKindId" and "AuditIndustryRatings"."IsActual" in (true)
    
/* _______________ Связываем таблицу с оценками __________________________*/  
left join "RAIT" -- таблица с оценками
    on "AIK"."Id"="RAIT"."AuditIndustryKindId" 


WHERE "AC"."IsActual" IN (true) --только актуальные записи
--and "AC"."Id" in (2009) --проверка на конкретном аудите
--and "AIK"."DirectionAuditCheckId" not in (21,19,95) -- не оценка производителя работ, не цифровой обход не корректировка рейтинга цехов
--and "AIK"."Id" not in (449) -- не СОУТ
and "ExecutionDate" is not null --берем только закрытые аудиты

-- ЭТУ СТРОКУ РАСКОММЕРНИТРОВАТЬ ПОСЛЕ ТОГО, КАК РЕШАТ ВОПРОС С -infifnity в "AuditIndustryRatings"."StartDate"
and  "ExecutionDate" between "RAIT"."StartDate" and "RAIT"."EndDate"

and  "FinalScore" between "RAIT"."MinAmount" and "RAIT"."MaxAmount"
and "AC"."AuditorPkLevel" in (4,5,6)
and ("AC"."IsContractor" IN (false) or "AC"."IsContractor" is null)
),

/*___________________ Ответственные лица. МУПРы_____________________________________*/    

"MUPR" as (
    select 
       "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                  as "ФИО МУПР" 
       ,"D1"."DepartmentName" as "Цех" -- Цех
      -- ,"D1"."Id" as "ID_SHOP_MUPR1" --идентификатор цеха
       ,"ref_shop"."DepartmentId" as "ID_SHOP_MUPR" --идентификатор цеха
        ,"REKURS"."OBJID" as "OBJID_MUPR"
         ,"E1"."PersonalNumber" as "TN_MUPR"  
       
from "EmployeeResponsibilityInDepartments" "ref_shop"

       left join "Employees" as "E1" on "ref_shop"."EmployeeId"="E1"."Id" --ФИО начальника цеха
       left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id" -- цех
       left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" -- название ответственности
       left join "REKURS" on "ref_shop"."DepartmentId"="REKURS"."ID_KOT" -- связь с рекурсией для вывода OBJID
where "ResponsibilityTypeId" in (106)
and "ref_shop"."IsActual" IN (true)
),

"AUDIT" as (
select distinct
    "PROIZVODITEL"."CardId"
    ,"PROIZVODITEL"."LinkCard"
        ,"PROIZVODITEL"."Ball"
        ,"PROIZVODITEL"."AuditIndustryKindId"
            ,"PROIZVODITEL"."%"
                ,"PROIZVODITEL"."NEUD"
                    ,"PROIZVODITEL"."DATE"
                        ,"PROIZVODITEL"."DepartmentName"
                            ,"PROIZVODITEL"."DirectionAuditCheckId"
                                ,"PROIZVODITEL"."Name"
                                ,"PROIZVODITEL"."Аудитор" 
                                ,"PROIZVODITEL"."Должность_Аудитора"    
    ,"REKURS"."L_REITING" as "OBJID_Аудитора"
    ,case 
        when "МЕСТО_РАБ_АУДИТОРА_ПОДР" is not null
    then "МЕСТО_РАБ_АУДИТОРА_ПОДР"
    else "REKURS"."NAME" 
        end as "Цех_Аудитора"
    ,"REKURS2"."L_REITING" as "OBJID_Места_Аудита"
    ,"REKURS2"."NAME" as "Цех_Места_Аудита"
/*  ,case 
        when "MUPR"."OBJID_MUPR" is null
    then 'Аудитор - не МУПР'
        else  "MUPR"."OBJID_MUPR"
    end as "OBJID_MUPR"*/
    ,case 
        when "MUPR"."OBJID_MUPR" is null
    then 'Аудитор - не МУПР'
        else "MUPR"."Цех"
    end as "Цех_МУПР"
    ,"STRUCT_YEAR_MONTH"    
    , case 
        when "MUPR"."OBJID_MUPR" is not null  -- Аудитор МУПР своего цеха
    then 0
            when "REKURS2"."L_REITING"="REKURS"."L_REITING" --цех проверяемого равен месту проведения аудита
    then 0
        else 1
    end as "Внешние_проверяющие"    
    
from "PROIZVODITEL"

/* _______________ Связываем рекурсию с место работы аудитора __________________________*/  
left join "REKURS" -- место работы аудитора с рекурсией для вывода OBJID урвня цеха
    on "REKURS"."ID_KOT"="PROIZVODITEL"."Место_Работы_Аудитора"
    
/* _______________ Связываем рекурсию с местом проведения аудита __________________________*/  
left join "REKURS" as "REKURS2" -- место проведения аудита для вывода OBJID урвня цеха
    on "REKURS2"."ID_KOT"="PROIZVODITEL"."MESTO_AUDITA"
    
/*_________ связь с МУПРами   ________________*/
left join "MUPR" -- выводим при совпадении цеха МУПРа и табельного номера МУПРа с цехом Проверяемого и табельного номера Аудитора
    on "MUPR"."OBJID_MUPR"||"TN_MUPR"="REKURS2"."L_REITING"||"TN_Auditor"
),




"AUDIT_VNESH" as
(
select * from "AUDIT" 
where "Внешние_проверяющие"=1
and "STRUCT_YEAR_MONTH" is not null
)

select * from "AUDIT_VNESH"
WHERE "AuditIndustryKindId" NOT IN (449, 1247, 1246) -- убираем Аудиты СУОТ


