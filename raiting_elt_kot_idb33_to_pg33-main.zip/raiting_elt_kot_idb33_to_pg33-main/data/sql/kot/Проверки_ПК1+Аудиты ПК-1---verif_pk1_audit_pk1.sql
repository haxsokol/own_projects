with res as (select distinct 
 r."EventId"
,r."RevisionTypeId" 
,cast(replace(e2."PersonalNumber",':','') as numeric)"PersonalNumber"
,id."ExternalId"::int 
,e."BeginDate"
,case
	when e."ExecutionDate" is not null and e."ExecutionTime" is not null 
	then e."ExecutionDate" + e."ExecutionTime"
	else e."ExecutionDate"
	end ExecutionDateTime
,r."TalkWithEmployee"
,concat('https://kot.severstal.com/revisions_severstal/card/',r."Id") link
,e."CreationDateTime" + INTERVAL '3' HOUR "CreationDateTime" --сдвиг в системе
,rd2."Id" IdDeadlyRisk
,CASE 
	WHEN e."ExecutionDate" is not null
	THEN e."ExecutionDate"::date
	WHEN e."BeginDate" is not null
	THEN e."BeginDate"::date
	END "Дата"
,e."Comment"
,vece."EventId" "Id_мероприятие"--убрать
,e3."Theme" "Откл. КББ"
,e4."Theme" "Мероприятия по устранению отк-я КББ"
,e4."EndingDate" "План дата вып. мероп"
,e4."ExecutionDate"  "Факт дата вып. мероп"
from public."Revisions" r 
join public."Events" e on r."EventId"=e."Id" and r."RevisionTypeId" in (1,4) and r."AuditorPkLevel"=1 
join public."EventParticipants" ep on r."AuditorId" =eP."Id" 
join public."Employees" e2 on ep."EmployeeId"=e2."Id" and e2."PersonalNumber" is not null and e2."EndDate" is null
left join public."RevisionDepartments" rd on r."Id"=rd."RevisionId" and rd."IsActual" IN (true)
left join public."RevisionDepartments_ViolationEvents" rv on rd."Id"=rv."RevisionDepartmentId"
left join public."ViolationEvents" ve on rv."ViolationEventId" = ve."Id" and ve."IsActual" IN (true)
left join public."Events" e3 on ve."EventId"=e3."Id" and e3."IsActual" IN (true)
left join public."ViolationKindSections" vks on ve."ViolationKindSectionId"=vks."Id"
left join public."Risk_Dangers" rd2 on ve."DangerId" = rd2."Id" and rd2."IsActual" IN (true) and rd2."IsDeadlyRisk"=true 
left join public."InternalEmployeePositionTypes" iept on e2."Id"=iept."InternalEmployeeId" and iept."EndDate" is null
left join public."PositionTypes" pt on iept."PositionTypeId"=pt."Id" 
left join public."ImportDepartments" id on pt."DepartmentId"=id."DepartmentId"
	left join public."Violation_EliminationCausesEvent" vece on ve."Id"=vece."ViolationEventId" and vece."IsActual"=true 
	left join public."Events" e4 on vece."EventId"=e4."Id" and e4."IsActual"=true
where concat(r."RevisionTypeId", ve."ViolationNature") <> '40'
)

,ODOY as (
select  
 e."Id"
,rd2."Id" IdDeadlyRisk
,CASE
	WHEN ve."ViolationNature" = 0
	THEN count(ve."ViolationNature") END "cntOD"
,CASE
	WHEN ve."ViolationNature" = 1
	THEN count(ve."ViolationNature") END "cntOY"  
,vebr."BasicRuleId"
from public."ViolationEvents" ve
left join public."RevisionDepartments_ViolationEvents" rv on rv."ViolationEventId" = ve."Id" and ve."IsActual" IN (true)
left join public."RevisionDepartments" rd on rd."Id"=rv."RevisionDepartmentId"
left join public."Revisions" r on r."Id"=rd."RevisionId" and rd."IsActual" IN (true)
left join public."Events" e on e."Id"=r."EventId" and r."RevisionTypeId" in (1,4) and r."AuditorPkLevel"=1 
left join public."Risk_Dangers" rd2 on ve."DangerId" = rd2."Id" and rd2."IsActual" IN (true) and rd2."IsDeadlyRisk"=true
	left join public."ViolationEventBasicRules" vebr on ve."Id" = vebr."ViolationEventId" and vebr."IsActual"=true and vebr."BasicRuleId" not in (39,43)
	left join public."BasicRules" br on vebr."ViolationEventId" = br."Id" and br."IsActual"=true and br."Id" not in (39,43)
where concat(r."RevisionTypeId", ve."ViolationNature") <> '40'
group by rd2."Id", e."Id", ve."ViolationNature", vebr."BasicRuleId"
)

select distinct 
 res."EventId"
,res."RevisionTypeId" 
,res."PersonalNumber"
,res."ExternalId"::int "DepartmentId"
,res."BeginDate"
,res.ExecutionDateTime "Дата и время выполнения"
,res."TalkWithEmployee"
,res.link
,res."CreationDateTime" 
,res."Дата"
,CASE 	
	WHEN (res."CreationDateTime"::date - res."Дата") <= 1.4 OR  res."CreationDateTime" IS NULL THEN 'Оформлено в течение смены' 
	WHEN (res."CreationDateTime"::date - res."Дата") >= 3.4  THEN 'Оформлено с просрочкой'
	WHEN (res."CreationDateTime"::date - res."Дата") >  1.4  THEN 'Оформлено в следующей смене' 
   END   comm 
,ODOY."cntOD"
,ODOY."cntOY"
,ODOY.IdDeadlyRisk
,ODOY."BasicRuleId"
,res."Comment"
,res."EventId" "Id_мероприятие"--убрать
,res."Откл. КББ"
,res."Мероприятия по устранению отк-я КББ"
,res."План дата вып. мероп"
,res."Факт дата вып. мероп"
from res
left join ODOY on res."EventId"= ODOY."Id"

union all

(with res as (select distinct 
 aic."EventId"
,e."EventTypeId" as "RevisionTypeId"
,cast(replace(e2."PersonalNumber",':','') as numeric)"PersonalNumber"
,id."ExternalId"::int
,e."BeginDate" 
,case
	when e."ExecutionDate" is not null and e."ExecutionTime" is not null 
	then e."ExecutionDate" + e."ExecutionTime"
	else e."ExecutionDate"
	end "ExecutionDateTime"
,null::int as "TalkWithEmployee" 
,concat('https://kot.severstal.com/audits_severstal/card/',aic."Id") link
,e."CreationDateTime" + INTERVAL '3' HOUR "CreationDateTime" --сдвиг в системе
,CASE
	WHEN e."ExecutionDate" is not null
	THEN e."ExecutionDate"::date
	WHEN e."BeginDate" is not null
	THEN e."BeginDate"::date
	END "Дата"
,e."Comment"
,vece."EventId" "Id_мероприятие"--убрать
,e."Theme" "Откл. КББ"
,e4."Theme" "Мероприятия по устранению отк-я КББ"
,e4."EndingDate" "План дата вып. мероп"
,e4."ExecutionDate"  "Факт дата вып. мероп"
from public."AuditIndustryCards" aic 
join public."Events" e on aic."EventId"=e."Id" and e."EventTypeId"=10 and aic."AuditorPkLevel"=2 and aic."IsActual" IN (true)
join public."EventParticipants" ep on ep."EventId"=e."Id" and ep."ParticipantType" =2
join public."Employees" e2 on ep."EmployeeId"=e2."Id" and e2."PersonalNumber" is not null and e2."EndDate" is null
join public."InvolvedAuditIndustry" iai on iai."EventParticipantId"=ep."Id" and iai."TypeOfInvolved"=0
left join public."InternalEmployeePositionTypes" iept on e2."Id"=iept."InternalEmployeeId" and iept."EndDate" is null
left join public."PositionTypes" pt on iept."PositionTypeId"=pt."Id" 
left join public."ImportDepartments" id on pt."DepartmentId"=id."DepartmentId"
	left join public."AuditIndustryCardQuestions" aicq2 on aic."Id" = aicq2."AuditIndustryCardId" 
	left join public."ViolationEvents" ve on aicq2."ViolationId" = ve."Id" and ve."IsActual" IN (true)
	left join public."Violation_EliminationCausesEvent" vece on ve."Id"=vece."ViolationEventId" and vece."IsActual"=true 
	left join public."Events" e4 on vece."EventId"=e4."Id" and e4."IsActual"=true
)

,ODOY as (
select  
 e."Id"
,rd2."Id" IdDeadlyRisk
,CASE
	WHEN ve."ViolationNature" = 0
	THEN count(ve."ViolationNature") END "cntOD"
,CASE
	WHEN ve."ViolationNature" = 1
	THEN count(ve."ViolationNature") END "cntOY"
,vebr."BasicRuleId"
from public."ViolationEvents" ve
left join public."AuditIndustryCardQuestions" aicq on aicq."ViolationId"=ve."Id" 
left join public."AuditIndustryCards" aic on aic."Id"=aicq."AuditIndustryCardId" and aic."AuditorPkLevel"=2 
left join public."Events" e on aic."EventId"=e."Id" and e."EventTypeId"=10
left join public."Risk_Dangers" rd2 on ve."DangerId" = rd2."Id" and rd2."IsActual" IN (true) and rd2."IsDeadlyRisk"=true
	left join public."ViolationEventBasicRules" vebr on ve."Id" = vebr."ViolationEventId" and vebr."IsActual"=true and vebr."BasicRuleId" not in (39,43)
	left join public."BasicRules" br on vebr."ViolationEventId" = br."Id" and br."IsActual"=true and br."Id" not in (39,43)
group by rd2."Id", e."Id", ve."ViolationNature", vebr."BasicRuleId"
)

select distinct 
 res."EventId"
,res."RevisionTypeId"
,res."PersonalNumber"
,res."ExternalId"::int "DepartmentId"
,res."BeginDate" 
,res."ExecutionDateTime" "Дата и время выполнения"
,res."TalkWithEmployee"
,res.link
,res."CreationDateTime" 
,res."Дата"
,CASE 	
	WHEN (res."CreationDateTime"::date - res."Дата") <= 1.4 OR  res."CreationDateTime" IS NULL THEN 'Оформлено в течение смены' 
	WHEN (res."CreationDateTime"::date - res."Дата") >= 3.4  THEN 'Оформлено с просрочкой'
	WHEN (res."CreationDateTime"::date - res."Дата") >  1.4  THEN 'Оформлено в следующей смене' 
   END   comm 
,ODOY."cntOD"
,ODOY."cntOY"
,ODOY.IdDeadlyRisk
,ODOY."BasicRuleId"
,res."Comment"
,res."EventId" "Id_мероприятие"--убрать
,res."Откл. КББ"
,res."Мероприятия по устранению отк-я КББ"
,res."План дата вып. мероп"
,res."Факт дата вып. мероп"
from res
left join ODOY on res."EventId"= ODOY."Id")