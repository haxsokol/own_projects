with res as (select distinct 
 aic."EventId"
,e."EventTypeId" as "RevisionTypeId"
,cast(replace(e2."PersonalNumber",':','') as numeric)"PersonalNumber"
,id."ExternalId"::int
,e."BeginDate" 
,e."EndingDate" 
,e."ExecutionDate" + e."ExecutionTime" "ExecutionDate"
,null as "TalkWithEmployee" 
,concat('https://kot.severstal.com/audits_severstal/card/',aic."Id") link
,e."CreationDateTime" +interval '3' hour "CreationDateTime" --сдвиг в системе
,CASE 
	WHEN e."ExecutionTime" is not null  and e."ExecutionTime"<> '00:00:00' and extract (hour from e."ExecutionTime") <8 --указааны дата и время выполнения и время выполнения до 8 утра - предыдущ.день
	THEN e."ExecutionDate"::date-1
	WHEN e."ExecutionTime" is not null and extract (hour from e."ExecutionTime")>=8 --указааны дата и время выполнения и время выполнения > 8 утра - соотв.день
	THEN e."ExecutionDate"::date
	WHEN e."BeginDate"::date=(e."CreationDateTime"+interval '3' hour)::date+1 AND extract (hour from (e."CreationDateTime"+interval '3' hour))>=20 --дата создания равна предыдущ.дате проверки и время занесения после 8 вечера - предыдущ.день
	THEN e."BeginDate"::date-1 
	WHEN e."BeginDate"::date=(e."CreationDateTime"+interval '3' hour)::date-1 AND extract (hour from (e."CreationDateTime"+interval '3' hour))<8 --дата создания равна предыдущ.дате проверки и время занесения до 8 утра - предыдущ.день
	THEN e."BeginDate"::date
	WHEN e."BeginDate"::date=(e."CreationDateTime"+interval '3' hour)::date AND extract (hour from (e."CreationDateTime"+interval '3' hour))<8  --дата создания равна дате проверки и время занесения до 8 утра - предыдущ.день
	THEN e."BeginDate"::date-1
	WHEN e."ExecutionDate" is not null and e."ExecutionTime" is null  --- соотв.день выполнения проверки
	THEN e."ExecutionDate"::date
	ELSE e."BeginDate"::date END "Дата"
,CASE 
	WHEN e."ExecutionTime" is not null  and e."ExecutionTime"<> '00:00:00' and extract (hour from e."ExecutionTime") <8 --указааны дата и время выполнения и время выполнения до 8 утра - предыдущ.день
	THEN 'Дата проверки перенеслась на предыдущие сутки'
	WHEN e."BeginDate"::date=e."CreationDateTime"::date+1 AND extract (hour from e."CreationDateTime")>=20 --дата создания равна предыдущ.дате проверки и время занесения после 8 вечера - предыдущ.день
	THEN 'Дата проверки перенеслась на предыдущие сутки'
	WHEN e."BeginDate"::date=e."CreationDateTime"::date AND extract (hour from e."CreationDateTime")<5  --дата создания равна дате проверки и время занесения до 8 утра - предыдущ.день
	THEN 'Дата проверки перенеслась на предыдущие сутки'
	END "Комментарии"
from public."AuditIndustryCards" aic 
join public."Events" e on aic."EventId"=e."Id" and e."EventTypeId"=10 and aic."AuditorPkLevel"=2 
join public."EventParticipants" ep on ep."EventId"=e."Id" and ep."ParticipantType" =2
join public."Employees" e2 on ep."EmployeeId"=e2."Id" and e2."PersonalNumber" is not null and e2."EndDate" is null
join public."InvolvedAuditIndustry" iai on iai."EventParticipantId"=ep."Id" and iai."TypeOfInvolved"=0
--left join public."RevisionDepartments" rd on r."Id"=rd."RevisionId" and rd."IsActual" IN (true)
--left join public."RevisionDepartments_ViolationEvents" rv on rd."Id"=rv."RevisionDepartmentId"
--left join public."ViolationEvents" ve on rv."ViolationEventId" = ve."Id" and ve."IsActual" IN (true)
--left join public."Events" e3 on ve."EventId"=e3."Id" and e3."IsActual" IN (true)
--left join public."ViolationKindSections" vks on ve."ViolationKindSectionId"=vks."Id"
--left join public."Risk_Dangers" rd2 on ve."DangerId" = rd2."Id" and rd2."IsActual" IN (true) and rd2."IsDeadlyRisk"=true 
left join public."InternalEmployeePositionTypes" iept on e2."Id"=iept."InternalEmployeeId" and iept."EndDate" is null
left join public."PositionTypes" pt on iept."PositionTypeId"=pt."Id" 
left join public."ImportDepartments" id on pt."DepartmentId"=id."DepartmentId"
)

,ODOY as (
select  
 e."Id"
,rd2."Id" IdDeadlyRisk
,CASE
	WHEN ve."ViolationNature" = 0
	THEN count(ve."ViolationNature") END "cntOD"
,CASE
	WHEN ve."ViolationNature" = 1
	THEN count(ve."ViolationNature") END "cntOY"  
from public."ViolationEvents" ve
left join public."AuditIndustryCardQuestions" aicq on aicq."ViolationId"=ve."Id" 
left join public."AuditIndustryCards" aic on aic."Id"=aicq."AuditIndustryCardId" and aic."AuditorPkLevel"=2 
left join public."Events" e on aic."EventId"=e."Id" and e."EventTypeId"=10
left join public."Risk_Dangers" rd2 on ve."DangerId" = rd2."Id" and rd2."IsActual" IN (true) and rd2."IsDeadlyRisk"=true 
group by rd2."Id", e."Id", ve."ViolationNature"
)

select distinct 
 res."EventId"
,res."RevisionTypeId"
,res."PersonalNumber"
,res."ExternalId"::int
,res."BeginDate" 
,res."EndingDate" 
,res."ExecutionDate" "Дата и время выполнения"
,res."TalkWithEmployee"
--,res."ExecutionDate" " 
--,res."ExecutionTime" 
,res.link
,res."CreationDateTime" 
,res."Дата"
,res."Комментарии"
,CASE 	
	WHEN (res."CreationDateTime"::date - res."Дата") <= 1.4 OR  res."CreationDateTime" IS NULL THEN 'Оформлено в течение смены' 
	WHEN (res."CreationDateTime"::date - res."Дата") >= 3.4  THEN 'Оформлено с просрочкой'
	WHEN (res."CreationDateTime"::date - res."Дата") >  1.4  THEN 'Оформлено в следующей смене' 
   END   comm 
,ODOY."cntOD"
,ODOY."cntOY"
,ODOY.IdDeadlyRisk
from res
left join ODOY on res."EventId"= ODOY."Id"