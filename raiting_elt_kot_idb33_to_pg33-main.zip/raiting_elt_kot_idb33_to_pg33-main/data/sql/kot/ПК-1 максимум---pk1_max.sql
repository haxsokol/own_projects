WITH

"CALENDAR" as (
SELECT (EXTRACT(year  from r)::text||EXTRACT(month  from r)::text) as "year_month"
FROM generate_series('2024-02-01',now()::date, '1 month') as r
			),
	
/*справочник Ответственные лица.Рейтинг цехов. Максимальный балл ПК-1*/
"MAX" as (
select 
"D1"."DepartmentName" as "Цех" -- Цех
,"Ref_OTV"."Name"
,"import"."ExternalId"::numeric  as "OBJID"
,"ResponsibilityTypeId"
       
from "EmployeeResponsibilityInDepartments" "ref_shop"

	left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id" -- цех
	left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" -- название ответственности
	left join "ImportDepartments" as "import" on "D1"."Id"="import"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
where "ResponsibilityTypeId" in (184) --183 - Рейтинг цехов. Максимальный балл Проверка локаций и КББ (ОРБ),184 - Рейтинг цехов. Максимальный балл ПК-1
and "ref_shop"."IsActual" IN (true)
),
			
maximum as (
select 
("MAX"."OBJID"::text||"CALENDAR"."year_month")::numeric as "STRUCT_YEAR_MONTH"
,1 as "План",1 as "Факт",100 as "ПК-1,%",1 as "ПК-1, балл",'Выполнен' as "График ПК-1"
from "CALENDAR","MAX"		
)
	
select * from maximum
