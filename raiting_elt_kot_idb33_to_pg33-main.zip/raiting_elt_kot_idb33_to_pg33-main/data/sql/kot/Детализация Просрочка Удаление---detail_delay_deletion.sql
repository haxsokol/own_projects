WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                                    when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                                     else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    
                                               
                    FROM "Departments"
                                               left join "ImportDepartments" as "importd" 
                                                                        on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
            when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then "L5"."ExternalId"
            else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
            when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)')
            else COALESCE("L4"."ROOT_NAME",'Участки(Ур-нь цеха не задан)') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"


FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок
),

"PROV" as (

select 
"Events"."Id" as "Id_События"
,"Events"."IsActual" as "Актуальность"
,'https://kot.severstal.com/events/plannings/events/single/'||"Events"."Id" as "Link_MER"
,"EV2"."Id" as "Id_Несоответствия"
,'https://kot.severstal.com/revisions_severstal/violation_event/'||"EV2"."Id" as "Link_Несоответствия"
            ,
                        COALESCE("EV2"."Description",'Нет данных')
                                    as "Описание Несоответствия"   
,"Events"."EndingDate"::DATE as "DATE_PLAN"
,"Events"."ExecutionDate"::DATE as "DATE_FACT"
,"Events"."ConfirmationDate"::DATE as "DATE_PODTVER"
,"EventEndingDateChangeHistory"."EndingDateOld"::DATE as "DATE_PLAN_OLD"
,"EventEndingDateChangeHistory"."SettlementDate"::DATE as "DATE_KORR_OLD"
,"Events"."LastModificationDateTime"::DATE as "DATE_MODIF"
,"REKURS"."WORKS_OBJID"
,"REKURS"."WORKSHOPS"
,"Events"."Description" as "Описание мероприятия"
            ,coalesce( --для подстановки текста'Не определен', если пусто
            "E1"."LastName"||' '||
                        substring("E1"."FirstName" from 1 for 1)||'. '||
                                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                                               "E1"."PersonalNumber"||')'
                                    ,'Не определен')
                                               as "Ответственный" 
,case 
            when"AuditIndustryCardQuestions"."AuditIndustryCardId" is not null -- аудит не пусто
then "AuditIndustryCardQuestions"."AuditIndustryCardId" 
            when  "EliminationCausesEvents"."InjuryId" is not null -- происшествия не пусто
then "EliminationCausesEvents"."InjuryId"
            when "CommitteeAgendasItemProtocols_Events"."EventId" is not null --комитеты не пусто
then "CommitteeAgendasItemProtocols"."CommitteeEventId"
            when "Shifts"."ShiftLogId" is not null -- журналы не пусто
then "Shifts"."ShiftLogId"
            when "Revisions"."Id"  is not null -- проверки не пусто
then "Revisions"."Id"   
            else "EV2"."Id" 
end      as "ID_источника"
,case 
            when"AuditIndustryCardQuestions"."AuditIndustryCardId" is not null -- аудит не пусто
then 'Аудит'   
            when "EliminationCausesEvents"."InjuryId" is not null -- происшествия не пусто
                        then 'Происшествия' 
            when "CommitteeAgendasItemProtocols_Events"."EventId" is not null --комитеты не пусто
                        then 'Комитет'            
            when "Shifts"."ShiftLogId" is not null -- журналы не пусто
                        then 'Журналы'         
            when "Revisions"."Id"  is not null -- проверки не пусто
                        then 'Проверка/ПАБ'            
                        
when "EV2"."EventTypeId" in (7) 
                        then 'Мероприятие'
                                    when "EV2"."EventTypeId" in (9) 
                                               then 'Несоответствие'
                                                           when "EV2"."EventTypeId" in (6) 
                                                                       then 'СОУТ'
                                                                                   when "EV2"."EventTypeId" in (4) 
                                                                                               then 'Проверка'
                                                                                                          when "EV2"."EventTypeId" in (3) 
                                                                                                                      then 'Обучение'
                                                                                                                                  when "EV2"."EventTypeId" in (2) 
                                                                                                                                              then 'Происшествие'
                                                                                                                                                          when "EV2"."EventTypeId" in (1) 
                                                                                                                                                                     then 'Медосмотры'
                                                                                                                                                                                 when "EV2"."EventTypeId" in (11) 
                                                                                                                                                                                             then 'Комитеты'
                                                                                                                                                                                                         when "EV2"."EventTypeId" in (10) 
                                                                                                                                                                                                                     then 'Аудит'
                                                                                                                                                                                                                                when "EV2"."EventTypeId" in (16) 
                                                                                                                                                                                                                                            then 'Планирование'
else 'Нет источника'
            end as "Тип источника"
,case 
            when "AuditIndustryCardQuestions"."AuditIndustryCardId" is not null -- аудит не пусто
then CONCAT('https://kot.severstal.com/audits_industry/card',"AuditIndustryCardQuestions"."AuditIndustryCardId")
            when "EliminationCausesEvents"."InjuryId" is not null -- происшествие не пусто
                        then CONCAT('https://kot.severstal.com/injuries/injuries-severstal/', "EliminationCausesEvents"."InjuryId") 
when "Revisions"."Id" is not null -- проверки не пусто
                        then CONCAT('https://kot.severstal.com/revisions_severstal/card/', "Revisions"."Id") 
            when "CommitteeAgendasItemProtocols_Events"."EventId" is not null --комитеты не пусто
                        then CONCAT('https://kot.severstal.com/committees/committees/', "CommitteeAgendasItemProtocols"."CommitteeEventId") 
                                    when "Shifts"."ShiftLogId" is not null -- журналы не пусто
                                    then CONCAT('https://kot.severstal.com/audits_industry/shift_log/', "Shifts"."ShiftLogId") 
                                                           when "Violation_EliminationCausesEvent"."EventId" is not null 
                                                then CONCAT('https://kot.severstal.com/revisions_severstal/violation_event/', "EV2"."Id" ) 
                                                           END as "link_ev" -- Ссылка на мероприятие

,case 
                        when "ViolationEvents2"."ViolationNature"=0 then 'ОД'
                        when "Revisions"."TalkWithEmployee"=0 then 'ОД'
                        when "ViolationEvents2"."ViolationNature"=1 then 'ОУ'
                        when "Revisions"."TalkWithEmployee"=1 then'БД'
                        when "ViolationEvents2"."ViolationNature" is null then 'Без замечаний'
            end as "Характер нарушения"

,"Events"."ParentEventId" as "Есть групповое"                  
,"Events"."LastModificationDateTime" "Дата и время удаления"
            ,"E2"."LastName"||' '||
                        substring("E2"."FirstName" from 1 for 1)||'. '||
                                    COALESCE(substring("E2"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                                               "E2"."PersonalNumber"||')' as "Удаливший"            

from "Events"

left join "EventEndingDateChangeHistory"
            on "EventEndingDateChangeHistory"."EventId"="Events"."Id"
            
/*_____________________________Ответственный за мероприятие________________________________*/

left join "EventParticipants" as "EvPr_Act"
            on "Events"."Id"="EvPr_Act"."EventId" 
                        --and "EvPr_Act"."IsActual" IN (true) 
                                    and "EvPr_Act"."ParticipantType"=2 -- Ответственный

left join "Employees" as "E1" 
            on "EvPr_Act"."EmployeeId"="E1"."Id" and "E1"."IsActual" IN (true)          

left join "InternalEmployeePositionTypes" as "IEPT3" -- Назначение сотрудника
            on "E1"."Id"="IEPT3"."InternalEmployeeId" and "IEPT3"."IsActual" in (true)
            
left join "PositionTypes" as "PT3" -- место работы аудитора
            on "IEPT3"."PositionTypeId"="PT3"."Id" --and "PT3"."IsActual" in (true)    

left join "REKURS" 
            on "REKURS"."ID_KOT"="PT3"."DepartmentId" 

/*_____  таблица для связи события и несоответствия ________*/      
left join "Violation_EliminationCausesEvent" 
            on "Events"."Id"="Violation_EliminationCausesEvent"."EventId" or "Events"."ParentEventId"="Violation_EliminationCausesEvent"."EventId"
            and "Violation_EliminationCausesEvent"."IsActual" in (true)

/*_____  таблица для вычисления ИД несоответствия ________*/                  
left join "ViolationEvents" 
            on "Violation_EliminationCausesEvent"."ViolationEventId"="ViolationEvents"."Id"             and "ViolationEvents"."IsActual" in (true)
            
/*_____  таблица несоответствия ________*/                  
left join "Events" as "EV2" 
            on "ViolationEvents"."EventId"="EV2"."Id" or "EV2"."ParentEventId"="ViolationEvents"."EventId"
                        and "EV2"."IsActual" in (true)

            
            
/*_____  для связи с комитетами ________*/                    
left join "CommitteeAgendasItemProtocols_Events"
            on "Events"."Id"="CommitteeAgendasItemProtocols_Events"."EventId" or "Events"."ParentEventId"="CommitteeAgendasItemProtocols_Events"."EventId" 
                        and "CommitteeAgendasItemProtocols_Events"."IsActual" in (true)
            
/*_____  для связи с протоколом комитета ________*/               
left join "CommitteeAgendasItemProtocols" 
            on "CommitteeAgendasItemProtocols_Events"."CommitteeAgendaItemProtocolId"="CommitteeAgendasItemProtocols"."Id" and "CommitteeAgendasItemProtocols"."IsActual" in (true)
            
/*_____  для связи с происшествиями ________*/           
left join "Injurys"
            on "Events"."Id"="Injurys"."EventId" or "Events"."ParentEventId"="Injurys"."EventId" 
                        and "Injurys"."IsActual" in (true)

            
/*_____  таблица для вычисления ИД с журналами ________*/                        
left join "ViolationEvents"  as "ViolationEvents2"
            on "EV2"."Id"="ViolationEvents2"."EventId"  and "ViolationEvents2"."IsActual" in (true)    

/*_____ связь ИД журналов и нарушений ________*/     
left join "ShiftEquipment"  
            on "ViolationEvents2"."Id"="ShiftEquipment"."ViolationEventId" --and "ShiftEquipment"."IsOperational" = false 

/*_____  ИД с журналов и нарушений ________*/                        
left join "Shifts"  
            on "ShiftEquipment"."ShiftId"="Shifts"."Id" --and "ShiftLogs"."IsActual" = true       

left join "RevisionDepartments_ViolationEvents" as "Rev_Viol" --Отдел нарушения в проверке
            on "ViolationEvents2"."Id"="Rev_Viol"."ViolationEventId"  and "Rev_Viol"."IsActual" IN (true)     

            
left join "RevisionDepartments" as "RevDE" --Отдел проверки
            on "Rev_Viol"."RevisionDepartmentId"="RevDE"."Id" and "RevDE"."IsActual" IN (true)   
            
            
left join "Revisions" -- события для проверки
on "RevDE"."RevisionId"="Revisions"."Id" and "Revisions"."IsActual"  IN (true)    
            

left join "EliminationCausesEvents" -- события для проверки
            on "Events"."Id"="EliminationCausesEvents"."EventId" or "Events"."ParentEventId"="EliminationCausesEvents"."EventId" 
                        and "EliminationCausesEvents"."IsActual"  IN (true)           

                        
/*______ вопрос к карте аудита  ____________*/             
left join            "AuditIndustryCardQuestions"           
            on "AuditIndustryCardQuestions"."ViolationId"="ViolationEvents"."Id" 

/*______ Пользоваитель, удаливший мероприятие  ____________*/               
left join            "Users"            
            on "Users"."Id"="Events"."LastModificationUserId" 

/*______ Сотрудник, удаливший мероприятие (для вывода ФИО и табельного)  ____________*/              
left join "Employees" as "E2" 
            on "Users"."EmployeeId"="E2"."Id" and "E2"."IsActual" IN (true)    
            
where "Events"."EventTypeId" in (7)
--and "Events"."Id" IN (1114913)
and "Events"."IsActual" in (false)  --только удаленные
and "Events"."IsGroup" in (false)
and "Events"."EndingDate">=to_date('30112023','ddmmyyyy')
and "Users"."LastName" != 'Система КОТ'),


"PROV_FULL" as (
select  
"PROV".*
,now()::date
,case 
          when "DATE_KORR_OLD">"DATE_PLAN_OLD"
       then 1
       when "DATE_MODIF">"DATE_PLAN"
       then 1
       when "DATE_FACT">"DATE_PLAN"
       then 1
       when "DATE_PLAN"<"DATE_PODTVER"
       then 1

            else 0
end as "PROSR"
,case 
            when "DATE_PLAN_OLD" is null 
then "DATE_PLAN"
            else "DATE_PLAN_OLD"
end as "DATE"
,case 
            when "DATE_PLAN_OLD" is null 
then "WORKS_OBJID"||EXTRACT(year FROM "DATE_PLAN"::date)||EXTRACT(Month FROM "DATE_PLAN"::date)

            else "WORKS_OBJID"||EXTRACT(year FROM "DATE_PLAN_OLD"::date)||EXTRACT(Month FROM "DATE_PLAN_OLD"::date)
end as "STRUCT_YEAR_MONTH"

from "PROV"
)

select * from "PROV_FULL" 
where "PROSR"=1
