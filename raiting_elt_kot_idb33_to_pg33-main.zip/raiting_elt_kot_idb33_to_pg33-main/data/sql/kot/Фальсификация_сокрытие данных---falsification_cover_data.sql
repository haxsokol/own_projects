WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                         when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                          else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric                                           
                    FROM "Departments"
                        left join "ImportDepartments" as "importd" 
                             on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
                        on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
                            and"Description" IN ('Рейтинг цеха')
                                and "Documents"."IsActual" in (true)
         
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"          
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
        and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
            and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),

/*___ переводки основные и временные ____*/
FOREMAN AS (
SELECT distinct
"NHRS"."FIO_TN"||','||chr(10)||"PA0001".OBJID_A_NAME as "FIO_TN_PROF"
,"PA0001".STRUCT_ID
,"PA0001".BEGDA as BEGDA
,CASE 
    WHEN  "PA0001".ENDDA::date>now()::date 
        THEN now()::date
    ELSE "PA0001".ENDDA::date
        END as ENDDA
,"PA0001".ORGEH::numeric as OBJID_A
,"PA0001".OBJID_A_NAME
,"PA0001".HRSROOT_ID
,"PA0001".PERNR
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"

left join 
    (select distinct 
case 
        WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
    then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
            ||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
                ||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
                    ||chr(10)||'('||HRSROOT_ID||')'
    else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
        ||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
            ||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
                ||chr(10)||'('||TN||')'
                end as"FIO_TN"
        ,CASE 
            WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
        THEN HRSROOT_ID
            ELSE TN 
        END AS PERNR   
        FROM otpb.power_bi_nhrs_full_mv
         where 
        (DATE_END::date>to_date('01012018','ddmmyyyy') or DATE_END::date IS NULL)   -- ограничить дату окончания 2018 годом, старые переводы нам не нужны
        AND TYPE_WORKER NOT IN ('Ученичество','Практика')) "NHRS"
        on "NHRS".pernr="PA0001".PERNR

WHERE ("PA0001".MASSN_NAME NOT IN ('Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 
                                    'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
    OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
    AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') -- 31.07.2025 убрано из IN ('Ученик') потому что проводят аудиты в том числе ученикам, потом вернул обратно т.к. генер другие лишние строки
    and "NHRS"."FIO_TN" is not null
        
UNION all--из НХРС начальники
select 
case 
    WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
        ||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
            ||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
                ||chr(10)||'('||"FULL".HRSROOT_ID||'),'
                    ||chr(10)||PROF_P
else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
    ||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
        ||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
            ||chr(10)||'('||TN||'),'
                ||chr(10)||PROF_P
    
    end as "FIO_TN_PROF"
,"FULL".STRUCT_ID
,"FULL".DATE_BEG::date as BEGDA
, CASE 
    WHEN  "FULL".DATE_END::date>now()::date 
        THEN now()::date
    WHEN  "FULL".DATE_END::date IS NULL AND "FULL".DATE_OF_DISMISSAL::date IS NOT NULL
        THEN "FULL".DATE_OF_DISMISSAL::date
    WHEN  "FULL".DATE_END::date IS NULL 
        THEN now()::date 
    ELSE "FULL".DATE_END::date 
        END as ENDDA
,STRUCT_OBJID.OBJID::numeric  as OBJID_A
,PROF_P AS OBJID_A_NAME
    ,"FULL".HRSROOT_ID
    ,CASE 
        WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
    THEN "FULL".HRSROOT_ID
        ELSE TN 
    END AS PERNR   
    FROM otpb.power_bi_nhrs_full_mv "FULL"
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
    on "FULL".STRUCT_ID=STRUCT_OBJID."struct_id"
         
left join (
SELECT distinct
"PA0001".HRSROOT_ID
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"
WHERE ("PA0001".MASSN_NAME NOT IN ('Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
    OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
    AND "PA0001".PERSK_NAME NOT IN ('прочие') 
        ) "PA001"
    on  "PA001".HRSROOT_ID="FULL".HRSROOT_ID
    where 
    ("FULL".DATE_END::date>to_date('01012018','ddmmyyyy') or "FULL".DATE_END::date IS NULL) -- ограничить дату окончания 2018 годом, старые переводы нам не нужны
    AND TYPE_WORKER NOT IN ('Ученичество','Практика') 
    and "PA001".HRSROOT_ID is null
    ),

    /* _____ соединяем с перекодировочной struct_id и OBJID    _____  */
"FOREMAN_OBJID" as (
select FOREMAN.*
,case 
    when STRUCT_OBJID.OBJID is null
then STRUCT_OBJID.struct_id
    else  STRUCT_OBJID.OBJID
end as "OBJID"
,"REKURS"."L_REITING"::numeric  as "OBJID_Цех"
,"REKURS"."NAME" as "Цех"
from FOREMAN
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
    on FOREMAN.STRUCT_ID=STRUCT_OBJID."struct_id"

/*_________ связь с рекурсией для вывода цеха Аудитора  ________________*/
left join "REKURS"  -- 
    on "REKURS"."OBJID"::numeric =STRUCT_OBJID.OBJID::numeric   
    where FOREMAN.PERNR>0
    --and FOREMAN.PERNR in (10608275) --тест
),

"AUDIT" as (
select 
    "AC"."Id" as  "ИД_Проверки"
    ,'https://kot.severstal.com/audits_industry/card/'||"AC"."Id" as "LINK"
    ,"EV"."ExecutionDate"::date as "DATE"
    ,'Аудит' as "Вид проверки"
,"E1"."LastName"||' '||
                substring("E1"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E1"."PersonalNumber","ExOrg_A"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E1"."Position","PN1"."Name"),'') 
 as "Аудитор"
,case 
    when "E1"."PersonalNumber" is not null and "E1"."PersonalNumber" like ('%:%') 
then  COALESCE(substring("E1"."PersonalNumber" from 3 for position (':' in "E1"."PersonalNumber")+10),"ExOrg_A"."Name")
    else "E1"."PersonalNumber"
end as "TN_Auditor" 
,"ViolationEvents"."EventId" as "ID_несоответсвия"
,'https://kot.severstal.com/revisions_severstal/violation_event/'||"ViolationEvents"."EventId" as "LINK_V"
,"ViKS"."Name" as "Направ несоответсвия"
,"ViKS"."Id" as "ID_Направ_несоответсвия"
,'Тема: '||"Events"."Theme"||chr(10)||chr(10)||
        'Описание: '||  COALESCE("Events"."Description",'Нет данных')||chr(10)||chr(10)||
            'Комментарий: '||COALESCE("Events"."Comment",'Нет данных') as "Описание_Несоответствия"   
 ,"E4"."LastName"||' '||
        substring("E4"."FirstName" from 1 for 1)||'. '||
            COALESCE(substring("E4"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                COALESCE("E4"."PersonalNumber","ExOrg_WN"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E4"."Position","PN4"."Name"),'') 
                            as "Допустивший нар."
,case 
    when "E4"."PersonalNumber" like ('%:%')
then substring("E4"."PersonalNumber" from 3 for position (':' in "E4"."PersonalNumber")+10)
    else "E4"."PersonalNumber"
end as "TN_Допустивший" --табельный номер Допустивший
/*________________________Персонал__________________________________________________*/  
,"E2"."LastName"||' '||
                substring("E2"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E2"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E2"."PersonalNumber","ExOrg_PROV"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E2"."Position","PN1"."Name"),'') 
as "Проверяемый" --именно проверяеммый, не допустивший
,case 
    when "E4"."PersonalNumber" like ('%:%') --у допустившего есть :
then  COALESCE(substring("E4"."PersonalNumber" from 3 for position (':' in "E4"."PersonalNumber")+10),"ExOrg_WN"."Name")
    when "E4"."PersonalNumber" not like ('%:%') and "E4"."PersonalNumber" is not null --у допустившего нет :
then  "E4"."PersonalNumber"
    when "E2"."PersonalNumber" like ('%:%') -- после проверки допустившего проверка у проверяемого
then  COALESCE(substring("E2"."PersonalNumber" from 3 for position (':' in "E2"."PersonalNumber")+10),"ExOrg_PROV"."Name")
    else "E2"."PersonalNumber"
end as "TN_Допустивший_Проверяемый"  -- или допустивший или проверяемый

,case 
    when "E4"."PersonalNumber" is not null
then  "E4"."LastName"||' '||
        substring("E4"."FirstName" from 1 for 1)||'. '||
            COALESCE(substring("E4"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                COALESCE("E4"."PersonalNumber","ExOrg_WN"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E4"."Position","PN4"."Name"),'') 

    else "E2"."LastName"||' '||
                substring("E2"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E2"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E2"."PersonalNumber","ExOrg_PROV"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E2"."Position","PN1"."Name"),'') 
end as "ФИО_Допустивший_Проверяемый"     -- или допустивший или проверяемый
,"import"."ExternalId"::numeric AS "OBJID_Места"
,"D"."DepartmentName" as "Место_проверки"
,case 
        when "E4"."Discriminator" is null
then 'Нет допустившего'
    when "E4"."Discriminator" in ('ExternalEmployee')
then 'Подрядчик'
    else 'Сотрудник'
end as "Подрядчик/Сотрудник_Допустивший"
,case 
            when "E2"."Discriminator" is null
then 'Нет Проверяемого'
    when "E2"."Discriminator" in ('ExternalEmployee')
then 'Подрядчик'
    else 'Сотрудник'
end as "Подрядчик/Сотрудник_Проверяемый"

FROM "AuditIndustryCards" as "AC"

/* _______________ Связь с событиями __________________________*/  
left join "Events" as "EV" -- Событие к аудиту
       on "AC"."EventId"="EV"."Id"
 
/* _______________ Связь с подразделениями __________________________*/  
left join "EventDepartments" as "ED" -- Событие к аудиту
       on "ED"."EventId"="EV"."Id"
       
 /* _______________Место проведения Аудита__________________________*/
join "Departments" as "D"
       on "ED"."DepartmentId"="D"."Id"      

left join "BusinessUnits" "BUS" -- предприятия
on "D"."BusinessUnitId"="BUS"."Id" and "BUS"."IsActual"  IN (true)

LEFT 
 JOIN "Locations" ON "BUS"."LocationId" = "Locations"."Id"
    
/* _______________ перекодировочная для OBJID цехов __________________________*/     
left join "ImportDepartments" as "import"  
on "D"."Id"::integer="import"."DepartmentId"::integer -- цех OBJID цехов    */  
       
/* _______________ Для определения вида аудита и фильтра по нему __________________________*/  
left join "AuditIndustryKinds" as "AIK"--Вид аудита
       on "AC"."AuditKindId"= "AIK"."Id" and "AIK"."IsActual" in (true)

/* _______________ Связываем с таблицей задействованные лица __________________________*/  
left join "InvolvedAuditIndustry" as "STAK"--задействованные лица
       on "AC"."Id"= "STAK"."AuditIndustryCardId" 
       and "STAK"."IsActual" in (true)  and     "STAK"."TypeOfInvolved"=0 --берем только актульные записи и только аудиторов (0), если 1 - соаудиторы

/* _______________ Связываем с расшифровкой задействованные лица. вытаскиваем ИД аудитора __________________________*/  
left join "EventParticipants" as "UCHASTNIK_AUDITOR"--задействованные лица
       on "STAK"."EventParticipantId"= "UCHASTNIK_AUDITOR"."Id" 
       and "UCHASTNIK_AUDITOR"."IsActual" in (true) --берем только актульные записи

/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/  
left join "Employees" as "E1" --задействованные лица
       on "UCHASTNIK_AUDITOR"."EmployeeId"= "E1"."Id" 
    --   and "E1"."IsActual" IN (true) --берем только актульные записи      
  
left join "InternalEmployeePositionTypes" as "IEPT1" -- Назначение сотрудника
    on "E1"."Id"="IEPT1"."InternalEmployeeId" and "IEPT1"."IsActual" in (true)
    
left join "PositionTypes" as "PT1" -- место работы аудитора, связь
    on "IEPT1"."PositionTypeId"="PT1"."Id" --and "PT3"."IsActual" in (true)
 
    /* _______________Место работы Аудиора, рашифровка из рекурсии__________________________*/
       
left join "PositionNames" as "PN1" -- должность аудитора    
    on "PT1"."PositionNameId" = "PN1"."Id" and  "PN1"."IsActual" in (true)

left join "ExternalOrganizations" as "ExOrg_A" -- Подрядная организация аудитора
    on "E1"."ExternalOrganizationId"="ExOrg_A"."Id"and "ExOrg_A"."IsActual" IN (true)
                                                                      
/* _______________Вопрос в карте аудита__________________________*/    
       
left join "AuditIndustryCardQuestions" as "ACQ"
       on  "AC"."Id"="ACQ"."AuditIndustryCardId" and "ACQ"."IsActual" in (true)
       
left join "AuditIndustryInquirers" as "AII" -- Опросник
       on "ACQ"."AuditIndustryInquirerId"="AII"."Id" and "AII"."IsActual" in (true)

/* _______________ балл за каждый вопрос__________________________*/    
left join "AuditIndustryGrades" as "BALL"
      on  "BALL"."Id"="ACQ"."GradeId" and "BALL"."IsActual" in (true)
      
  /*______ вопрос к карте аудита  ____________*/        
left join   "ViolationEvents"   
    on "ACQ"."ViolationId"="ViolationEvents"."Id"   
    
/*_____  таблица несоответствия ________*/      
left join "Events" 
    on "ViolationEvents"."EventId"="Events"."Id"
        and "Events"."IsActual" in (true)     

left join "ViolationKindSections" as "ViKS" --Раздел нарушения (Справочник направлений нарушений)
    on "ViolationEvents"."ViolationKindSectionId"="ViKS"."Id"
/*___________________ Допустивший несоответствие_____________________________________*/ 
                
left join "EventParticipants" as "EP4" --Участник события
    on "ViolationEvents"."EventId"="EP4"."EventId" 
        and "EP4"."IsActual" IN (true) 
        and "EP4"."ParticipantType"=4 -- 4 - нарушитель

left join "Employees" as "E4" 
    on "EP4"."EmployeeId"="E4"."Id" and "E4"."IsActual" IN (true)

left join "InternalEmployeePositionTypes" as "IEPT4" -- Назначение сотрудника
    on "E4"."Id"="IEPT4"."InternalEmployeeId" and "IEPT4"."IsActual" in (true)
    
left join "PositionTypes" as "PT4" -- место работы допустившего несоответствие
    on "IEPT4"."PositionTypeId"="PT4"."Id" --and "PT4"."IsActual" in (true)
    
left join "PositionNames" as "PN4" -- должность допустившего несоответствие
on "PT4"."PositionNameId" = "PN4"."Id" and  "PN4"."IsActual" in (true)

left join "ExternalOrganizations" as "ExOrg_WN" -- Подрядная допустившего несоответствие
    on "E4"."ExternalOrganizationId"="ExOrg_WN"."Id" and "ExOrg_WN"."IsActual" IN (true)
/* _______________ Связываем с таблицей Ответственные лица аудита __________________________*/  
left join "ResponsibleForAuditIndustry" as "OTV"--задействованные лица
       on "AC"."Id"= "OTV"."AuditIndustryCardId" 
       and "OTV"."IsActual" in (true)  and   "OTV"."ResponsibilityType"=0 --берем только актульные записи и проверяемого (0), если 1 - Руководители проекта

/* _______________ Связываем с расшифровкой Ответственные лица. вытаскиваем ИД проверяемого __________________________*/  
left join "EventParticipants" as "UCHASTNIK_PROVERZEM"--задействованные лица
       on "OTV"."EventParticipantId"= "UCHASTNIK_PROVERZEM"."Id" 
       and "UCHASTNIK_PROVERZEM"."IsActual" in (true) --берем только актульные записи
     
/* _______________ Связываем ИД аудитора с таблицей персонала Employees __________________________*/  
left join "Employees" as "E2" --задействованные лица
       on "UCHASTNIK_PROVERZEM"."EmployeeId"= "E2"."Id" 
       and "E2"."IsActual" IN (true) --берем только актульные записи
     
/* _______________ Связываем с таблицей персонала Employees Назначение сотрудника__________________________*/  
 left join "InternalEmployeePositionTypes" as "IEPT2" -- Назначение сотрудника
    on "E2"."Id"="IEPT2"."InternalEmployeeId" and "IEPT2"."IsActual" in (true)

/* _______________ Связываем Назначение сотрудника с место работы аудитора __________________________*/  
left join "PositionTypes" as "PT2" -- место работы аудитора
    on "IEPT2"."PositionTypeId"="PT2"."Id" --and "PT1"."IsActual" in (true)

    left join "ExternalOrganizations" as "ExOrg_PROV" -- Подрядная допустившего несоответствие
    on "E2"."ExternalOrganizationId"="ExOrg_PROV"."Id" and "ExOrg_PROV"."IsActual" IN (true)
    
WHERE "AC"."IsActual" IN (true) --только актуальные записи
--and "AC"."Id" in (1802)
and "EV"."ExecutionDate" is not null
and "ViKS"."Id" in (151,152)
and "E4"."PersonalNumber" is not null --берем только по Допустившему, остальные не нужны
),

"FULL_PROV" as (select
    "REV"."Id" as  "ИД_Проверки"
    ,'https://kot.severstal.com/revisions_severstal/card/'||"REV"."Id" as "LINK"
    ,case
        when "ViolationNature"=0 or "REV"."TalkWithEmployee"=0 
            then "EveI"."BeginDate"::date
        else "EveI"."ExecutionDate" 
        end as "DATE"
    ,"REV_TYP"."Name" as "Вид проверки"
,case 
    when "REV"."AuditorId" is not null    --Аудитор
        then
            "E3"."LastName"||' '||
                substring("E3"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E3"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E3"."PersonalNumber","ExOrg_A"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E3"."Position","PN3"."Name"),'') 
        else 
"E6"."LastName"||' '||
                substring("E6"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E6"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E6"."PersonalNumber","ExOrg_A"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E6"."Position","ExOrg_A_Predsedat"."Name"),'') 
        end as "Аудитор"
,case 
    when "E6"."PersonalNumber" is not null and "E6"."PersonalNumber" like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
then  COALESCE(substring("E6"."PersonalNumber" from 3 for position (':' in "E6"."PersonalNumber")+10),"ExOrg_A"."Name")
    when "E6"."PersonalNumber" is not null and "E6"."PersonalNumber" not like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
then  "E6"."PersonalNumber"
    when "E3"."PersonalNumber" is not null and "E3"."PersonalNumber" like ('%:%') 
then  COALESCE(substring("E3"."PersonalNumber" from 3 for position (':' in "E3"."PersonalNumber")+10),"ExOrg_A"."Name")
    else "E3"."PersonalNumber"
end as "TN_Auditor" 

/*___________________ Несоответствия к проверке_____________________________________*/  
,"ViEv"."EventId" as "ID_несоответсвия"
,'https://kot.severstal.com/revisions_severstal/violation_event/'||"ViEv"."EventId" as "LINK_V"
,"ViKS"."Name" as "Направ несоответсвия"
,"ViKS"."Id" as "ID_Направ_несоответсвия"
,'Тема: '||"Eve_Vi"."Theme"||chr(10)||chr(10)||
        'Описание: '||  COALESCE("Eve_Vi"."Description",'Нет данных')||chr(10)||chr(10)||
            'Комментарий: '||COALESCE("Eve_Vi"."Comment",'Нет данных')
    as "Описание несоответствия"
,"E4"."LastName"||' '||
        substring("E4"."FirstName" from 1 for 1)||'. '||
            COALESCE(substring("E4"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                COALESCE("E4"."PersonalNumber","ExOrg_WN"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E4"."Position","PN4"."Name"),'') 
as "Допустивший нар."
,case 
    when "E4"."PersonalNumber" like ('%:%')
then substring("E4"."PersonalNumber" from 3 for position (':' in "E4"."PersonalNumber")+10)
    else "E4"."PersonalNumber"
end as "TN_Допустивший" --табельный номер Допустивший


/*________________________Персонал__________________________________________________*/  
,"E1"."LastName"||' '||
                substring("E1"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E1"."PersonalNumber","ExOrg_W"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E1"."Position","PN1"."Name"),'') 
as "Проверяемый" --именно проверяеммый, не допустивший
,case 
    when "E4"."PersonalNumber" like ('%:%') --у допустившего есть :
then  COALESCE(substring("E4"."PersonalNumber" from 3 for position (':' in "E4"."PersonalNumber")+10),"ExOrg_WN"."Name")
    when "E4"."PersonalNumber" not like ('%:%') and "E4"."PersonalNumber" is not null --у допустившего нет :
then  "E4"."PersonalNumber"
    when "E1"."PersonalNumber" like ('%:%') -- после проверки допустившего проверка у проверяемого
then  COALESCE(substring("E1"."PersonalNumber" from 3 for position (':' in "E1"."PersonalNumber")+10),"ExOrg_W"."Name")
    else "E1"."PersonalNumber"
end as "TN_Допустивший_Проверяемый"  -- или допустивший или проверяемый

,case 
    when "E4"."PersonalNumber" is not null
then  "E4"."LastName"||' '||
        substring("E4"."FirstName" from 1 for 1)||'. '||
            COALESCE(substring("E4"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                COALESCE("E4"."PersonalNumber","ExOrg_WN"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E4"."Position","PN4"."Name"),'') 

    else "E1"."LastName"||' '||
                substring("E1"."FirstName" from 1 for 1)||'. '||
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
                        COALESCE("E1"."PersonalNumber","ExOrg_W"."Name")||')'||
                            COALESCE(','||chr(10)||COALESCE("E1"."Position","PN1"."Name"),'') 
end as "ФИО_Допустивший_Проверяемый"     -- или допустивший или проверяемый
,"importd"."ExternalId"::numeric AS "OBJID_Места"
,"D1"."DepartmentName" as "Место_проверки"
,case 
            when "E4"."Discriminator" is null
then 'Нет допустившего'
    when "E4"."Discriminator" in ('ExternalEmployee')
then 'Подрядчик'
    else 'Сотрудник'
end as "Подрядчик/Сотрудник_Допустивший"
,case 
     when "E1"."Discriminator" is null
then 'Нет Проверяемого'
    when "E1"."Discriminator" in ('ExternalEmployee')
then 'Подрядчик'
    else 'Сотрудник'
end as "Подрядчик/Сотрудник_Проверяемый"

from "Revisions" as "REV"

join public."BusinessUnits" "BUS" -- предприятия
on "REV"."BusinessUnitId"="BUS"."Id" and "BUS"."IsActual"  IN (true)

left join public."ExternalOrganizations" as "ExOrg" -- Проверяемая организация
on "REV"."ExternalOrganizationId"= "ExOrg"."Id" and "ExOrg"."IsActual"  IN (true)

left join public."RevisionTypes" as "REV_TYP" -- виды проверок
on "REV"."RevisionTypeId"="REV_TYP"."Id" and "REV_TYP"."IsActual"  IN (true)

left join public."Events" as "EveI" -- события для проверки
on "REV"."EventId"="EveI"."Id" and "EveI"."IsActual"  IN (true)

/*_____________________________Направление Проверки_________________________________*/
left join public."DirectionsOfInspectionsAndAudits" as "DirInsp"-- справочник направлений проверки уровня группы
on "REV"."RevisionDirectionId"="DirInsp"."Id" and "DirInsp"."IsActual" IN (true)

left join public."GroupOfDirections" as "GrDir" -- справочник направлений проверки дочерних записей
on "REV"."GroupOfDirectionId"="GrDir"."Id" and "GrDir"."IsActual" IN (true)
/*________________________Персонал__________________________________________________*/
    /*___Проверяемый___*/
left join "EventParticipants" as "EP1" 
    on "REV"."SubjectId"="EP1"."Id" and "EP1"."IsActual" IN (true)
    
left join "Employees" as "E1" 
    on "EP1"."EmployeeId"="E1"."Id" and "E1"."IsActual" IN (true) --Проверяемый

left join public."InternalEmployeePositionTypes" as "IEPT1" -- Назначение проверяемого
    on "E1"."Id"="IEPT1"."InternalEmployeeId" and "IEPT1"."IsActual" in (true)
    
left join public."PositionTypes" as "PT1" -- место работы проверянмого
    on "IEPT1"."PositionTypeId"="PT1"."Id"-- and "PT1"."IsActual" in (true)
    
left join public."PositionNames" as "PN1" -- должность проверяемого 
on "PT1"."PositionNameId" = "PN1"."Id" and  "PN1"."IsActual" in (true)

left join public."ExternalOrganizations" as "ExOrg_W" -- Подрядная организация проверяемого
    on "E1"."ExternalOrganizationId"="ExOrg_W"."Id"and "ExOrg_W"."IsActual" IN (true)
            

/*__Аудитор__*/ 
left join "EventParticipants" as "EP3" 
    on "REV"."AuditorId"="EP3"."Id"  and "EP3"."IsActual" IN (true)

    left join "Employees" as "E3" 
    on "EP3"."EmployeeId"="E3"."Id" and "E3"."IsActual" IN (true) -- Аудитор

left join "InternalEmployeePositionTypes" as "IEPT3" -- Назначение сотрудника
    on "E3"."Id"="IEPT3"."InternalEmployeeId" and "IEPT3"."IsActual" in (true)
    
left join "PositionTypes" as "PT3" -- место работы аудитора
    on "IEPT3"."PositionTypeId"="PT3"."Id" --and "PT3"."IsActual" in (true)
    
left join "PositionNames" as "PN3" -- должность аудитора    
    on "PT3"."PositionNameId" = "PN3"."Id" and  "PN3"."IsActual" in (true)

left join public."ExternalOrganizations" as "ExOrg_A" -- Подрядная организация аудитора
    on "E3"."ExternalOrganizationId"="ExOrg_A"."Id"and "ExOrg_A"."IsActual" IN (true)
/*_______________________Место проведения проверки_________________________________*/   

left join public."RevisionDepartments" as "RevDE" --Отдел проверки
    on "REV"."Id"="RevDE"."RevisionId" and "RevDE"."IsActual" IN (true)

left join "RevisionDepartments_ViolationEvents" as "Rev_Viol" --Отдел нарушения в проверке
    on "RevDE"."Id"="Rev_Viol"."RevisionDepartmentId"  and "Rev_Viol"."IsActual" IN (true)

left join "Departments" as "D1" 
    on "RevDE"."DepartmentId"= "D1"."Id" --and "D1"."IsActual" IN (true) -- Место проверки

left join "ImportDepartments" as "importd" 
    on "D1"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
    
/*___________________ Несоответствия к проверке_____________________________________*/  

left join public."ViolationEvents" as "ViEv" -- Нарушение
    on "Rev_Viol"."ViolationEventId" = "ViEv"."Id" and "ViEv"."IsActual" IN (true)

left join public."Events" as "Eve_Vi" -- событие к Нарушению
    on "ViEv"."EventId"="Eve_Vi"."Id" and "Eve_Vi"."IsActual" IN (true)

left join public."ViolationKindSections" as "ViKS" --Раздел нарушения (Справочник направлений нарушений)
    on "ViEv"."ViolationKindSectionId"="ViKS"."Id"

/*___________________Допустивший несоответствие_____________________________________*/  
left join public."EventParticipants" as "EP4" --Участник события
    on "ViEv"."EventId"="EP4"."EventId" 
        and "EP4"."IsActual" IN (true) 
        and "EP4"."ParticipantType"=4 -- 4 - нарушитель

left join public."Employees" as "E4" 
    on "EP4"."EmployeeId"="E4"."Id" and "E4"."IsActual" IN (true)

left join public."InternalEmployeePositionTypes" as "IEPT4" -- Назначение сотрудника
    on "E4"."Id"="IEPT4"."InternalEmployeeId" and "IEPT4"."IsActual" in (true)
    
left join public."PositionTypes" as "PT4" -- место работы допустившего несоответствие
    on "IEPT4"."PositionTypeId"="PT4"."Id" --and "PT4"."IsActual" in (true)
    
left join public."PositionNames" as "PN4" -- должность допустившего несоответствие
on "PT4"."PositionNameId" = "PN4"."Id" and  "PN4"."IsActual" in (true)

left join public."ExternalOrganizations" as "ExOrg_WN" -- Подрядная допустившего несоответствие
    on "E4"."ExternalOrganizationId"="ExOrg_WN"."Id" and "ExOrg_WN"."IsActual" IN (true)

/*_______ Привязываем комиссию, будем выводить председателя комиссии ___________*/
left join "CommissionParticipants_Revision" 
    on "REV"."Id"="CommissionParticipants_Revision"."RevisionId" 
        and "CommissionParticipants_Revision"."IsActual" IN (true) and "CommissionParticipants_Revision"."IsTheChair" IN (true)
        
/*_______ Расшифровываем председателя ___________*/
left join "CommissionParticipants" 
    on "CommissionParticipants_Revision"."CommissionParticipantId"="CommissionParticipants"."Id" 
        and "CommissionParticipants"."IsActual" IN (true)

/*_______  для табельного номера председателя ___________*/
left join "Employees" as "E6" 
    on "CommissionParticipants"."EmployeeId"="E6"."Id"-- and "E6"."IsActual" IN (true) -- Аудитор

left join "ExternalOrganizations" as "ExOrg_A_Predsedat" -- Подрядная организация председателя комиссии
    on "E6"."ExternalOrganizationId"="ExOrg_A_Predsedat"."Id"and "ExOrg_A_Predsedat"."IsActual" IN (true)   



WHERE "REV"."IsActual" IN (true)
and "REV"."RevisionTypeId" in (4,1)
--and "CommissionId" is not null
--and "REV"."Id" IN (528932)
--and "ViEv"."EventId" =279376
and "EveI"."EndingDate">=to_date('01032024','ddmmyyyy')
and ("GrDir"."Id"not in (8) or "GrDir"."Id" is null) --ПК супервайзеры, Группа по развитию подрядных организаций
and "ViKS"."Id" in (151,152)
--and "E4"."PersonalNumber" is not null --берем только по Допустившему, остальные не нужны
union 
select * from "AUDIT"

),


"EVENT_FALSE" as (
select  distinct 

    "FULL_PROV"."ИД_Проверки"
    ,"FULL_PROV"."ID_несоответсвия"
    ,"FULL_PROV"."Вид проверки"
    ,"FULL_PROV"."LINK"
    ,"FULL_PROV"."DATE"
    ,"FULL_PROV"."Допустивший нар."
    ,"FULL_PROV"."Аудитор"
    ,"FULL_PROV"."TN_Auditor"
    ,"FULL_PROV"."Направ несоответсвия"
    ,"FULL_PROV"."ID_Направ_несоответсвия"
    ,case when "FOREMAN_OBJID"."OBJID_Цех" is not null
    then ("FOREMAN_OBJID"."OBJID_Цех"||(EXTRACT(year FROM "FULL_PROV"."DATE"::date))::text||EXTRACT(Month FROM "FULL_PROV"."DATE"::date) )::numeric 
    else ("FULL_PROV"."OBJID_Места"||(EXTRACT(year FROM "FULL_PROV"."DATE"::date))::text||EXTRACT(Month FROM "FULL_PROV"."DATE"::date) )::numeric 
    end as "STRUCT_YEAR_MONTH"  
    ,"FOREMAN_OBJID"."OBJID_Цех" as "OBJID_Допустивший"
    ,"FOREMAN_OBJID"."Цех" as "Цех_Допустивший"
    ,"FOREMAN_OBJID2"."OBJID_Цех" as "OBJID_Аудитора"
    ,"FOREMAN_OBJID2"."Цех" as "Цех_Аудитора"
    ,"FULL_PROV"."OBJID_Места"
    ,"Место_проверки"
    ,"Подрядчик/Сотрудник_Допустивший"
    ,"Подрядчик/Сотрудник_Проверяемый"
,case 
    when "OBJID_Места"="FOREMAN_OBJID2"."OBJID_Цех" and "FULL_PROV"."TN_Допустивший_Проверяемый" is null -- место проведения проверки равно месту работы аудитора, если нет ни проверяемого ни допустившего
then 1
    when "FOREMAN_OBJID"."OBJID_Цех"="FOREMAN_OBJID2"."OBJID_Цех" --если место работы аудитора равно месту работы допустившего
then 1
else 0 end as "Внутренние"

,case
    when "OBJID_Места"="FOREMAN_OBJID2"."OBJID_Цех" -- 01.08.2025 место проведения проверки равно месту работы аудитора
then 0 
    when "OBJID_Места"="FOREMAN_OBJID2"."OBJID_Цех" and "FULL_PROV"."TN_Допустивший_Проверяемый" is null -- место проведения проверки равно месту работы аудитора, если нет ни проверяемого ни допустившего
then 0      
    when "FOREMAN_OBJID"."OBJID_Цех"="FOREMAN_OBJID2"."OBJID_Цех" --если место работы аудитора равно месту работы допустившего
then 0
    else 1 end as "Внешние"
    
from "FULL_PROV"
    
/*_________ связь с Допустившим нарушение на момент нарушения ________________*/
left join "FOREMAN_OBJID" -- место работы Допустившего или проверяемого нарушение связь с рекурсией для вывода OBJID урвня цеха
    on "FOREMAN_OBJID".PERNR::numeric ="FULL_PROV"."TN_Допустивший_Проверяемый"::numeric
        and "FULL_PROV"."DATE" between  "FOREMAN_OBJID".BEGDA and "FOREMAN_OBJID".ENDDA

/*_________ связь с Аудитором на момент нарушения ________________*/
left join "FOREMAN_OBJID" as "FOREMAN_OBJID2" -- место работы Допустившего нарушение связь с рекурсией для вывода OBJID урвня цеха
    on "FOREMAN_OBJID2".PERNR::numeric ="FULL_PROV"."TN_Auditor"::numeric
        and "FULL_PROV"."DATE" between  "FOREMAN_OBJID2".BEGDA and "FOREMAN_OBJID2".ENDDA
    
)

select
*
from "EVENT_FALSE"
where 
"Внешние"=1 AND
"Подрядчик/Сотрудник_Допустивший" not in ('Подрядчик')
--AND "ИД_Проверки" = 1200633

