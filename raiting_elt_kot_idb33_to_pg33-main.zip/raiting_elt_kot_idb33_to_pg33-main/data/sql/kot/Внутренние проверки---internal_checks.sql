
WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" in (true)
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),

/*___ переводки основные и временные ____*/
FOREMAN AS (
SELECT distinct
"NHRS"."FIO_TN"||','||chr(10)||"PA0001".OBJID_A_NAME as "FIO_TN_PROF"
,"PA0001".STRUCT_ID
,"PA0001".BEGDA as BEGDA
,CASE 
	WHEN  "PA0001".ENDDA::date>now()::date 
		THEN now()::date
	ELSE "PA0001".ENDDA::date
		END as ENDDA
,"PA0001".ORGEH::numeric as OBJID_A
,"PA0001".OBJID_A_NAME
,"PA0001".HRSROOT_ID
,"PA0001".PERNR
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"

left join 
	(select distinct 
case 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
			||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
				||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
					||chr(10)||'('||HRSROOT_ID||')'
	else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||TN||')'
				end as"FIO_TN"
		,CASE 
			WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
		THEN HRSROOT_ID
			ELSE TN 
		END AS PERNR   
		FROM otpb.power_bi_nhrs_full_mv
		 where 
		(DATE_END::date>to_date('01012025','ddmmyyyy') or DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
		AND TYPE_WORKER NOT IN ('Ученичество','Практика')) "NHRS"
		on "NHRS".pernr="PA0001".PERNR

WHERE ("PA0001".MASSN_NAME NOT IN ('Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
	OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
	AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') 
	and ("PA0001".BEGDA::date<=now() and "PA0001".BEGDA::date>to_date('01012000','ddmmyyyy'))
	and "NHRS"."FIO_TN" is not null
		
UNION all--из НХРС начальники
select 
case 
	WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
then initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
		||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
			||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
				||chr(10)||'('||"FULL".HRSROOT_ID||'),'
					||chr(10)||PROF_P
else initcap(split_part(fio_all, ' ', 1))||' ' --фамилия с большой буквы, поиском значение до первого пробела
	||substring((split_part(fio_all, ' ', 2)) from 1 for 1)||'. ' --Имя_с_точкой
		||COALESCE(substring((split_part(fio_all, ' ', 3)) from 1 for 1)||'.','') --Отчество_с_точкой, а если отчетсва нет, тогда пусто
			||chr(10)||'('||TN||'),'
				||chr(10)||PROF_P
	
	end as "FIO_TN_PROF"
,"FULL".STRUCT_ID
,"FULL".DATE_BEG::date as BEGDA
, CASE 
	WHEN  "FULL".DATE_END::date>now()::date	
		THEN now()::date
	WHEN  "FULL".DATE_END::date IS NULL AND "FULL".DATE_OF_DISMISSAL::date IS NOT NULL
		THEN "FULL".DATE_OF_DISMISSAL::date
	WHEN  "FULL".DATE_END::date IS NULL	
		THEN now()::date 
	ELSE "FULL".DATE_END::date 
		END as ENDDA
,STRUCT_OBJID.OBJID::numeric  as OBJID_A
,PROF_P AS OBJID_A_NAME
	,"FULL".HRSROOT_ID
	,CASE 
		WHEN CHAR_LENGTH(tn::text)::numeric<7 --учет количества символов для Стальных решений
	THEN "FULL".HRSROOT_ID
		ELSE TN 
	END AS PERNR   
	FROM otpb.power_bi_nhrs_full_mv "FULL"
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
	on "FULL".STRUCT_ID=STRUCT_OBJID."struct_id"
		 
left join (
SELECT distinct
"PA0001".HRSROOT_ID
FROM otpb.idb33_power_bi_pa0001_mv  "PA0001"
WHERE ("PA0001".MASSN_NAME NOT IN ('Увольнение сотрудника','Увольнение (GN)','Мобилизация', 'Дистанционная работа','Увольнение ГПХ и Стаж (BF)','Увольнение работника (KZ)', 'Увольнение ГПХ', 'Увольнение (BF)','Практика без оплаты') 
	OR "PA0001".MASSN_NAME IS NULL OR "PA0001".MASSG_NAME in ('Возврат из мобилизации'))
	and ("PA0001".BEGDA::date<=now() and "PA0001".BEGDA::date>to_date('01012000','ddmmyyyy'))
	AND "PA0001".PERSK_NAME NOT IN ('Ученик','прочие') 
	
		) "PA001"
	on  "PA001".HRSROOT_ID="FULL".HRSROOT_ID
	where 
	("FULL".DATE_END::date>to_date('01012025','ddmmyyyy') or "FULL".DATE_END::date IS NULL)	-- ограничить дату окончания 2018 годом, старые переводы нам не нужны
	AND TYPE_WORKER NOT IN ('Ученичество','Практика') 
	and "PA001".HRSROOT_ID is null
	),

	/* _____ соединяем с перекодировочной struct_id и OBJID    _____  */
"FOREMAN_OBJID" as (
select FOREMAN.*
,case 
	when STRUCT_OBJID.OBJID is null
then STRUCT_OBJID.struct_id
	else  STRUCT_OBJID.OBJID
end as "OBJID"
,"REKURS"."L_REITING"::numeric  as "OBJID_Цех"
,"REKURS"."WORKSHOPS" as "Цех"
from FOREMAN
/*_________ перекодировочная на STRUCT_OBJID  ________________*/
left join (select  "struct_id", case when objid is null then struct_id else objid end as objid from otpb.idb33_struct_objid_mv STRUCT_OBJID) as STRUCT_OBJID
	on FOREMAN.STRUCT_ID=STRUCT_OBJID."struct_id"

/*_________ связь с рекурсией для вывода цеха Аудитора  ________________*/
left join "REKURS"  -- 
	on "REKURS"."OBJID"::numeric =STRUCT_OBJID.OBJID::numeric	
	where FOREMAN.PERNR>0
	--and FOREMAN.PERNR in (10608275) --тест
),

"FULL_PROV" as (
select distinct 
	"REV"."Id"
	,'https://kot.severstal.com/revisions_severstal/card/'||"REV"."Id" as "LINK"
	,case
		when "ViolationNature"=0 or "REV"."TalkWithEmployee"=0 
			then "EveI"."BeginDate"::date
		else "EveI"."ExecutionDate" 
		end as "DATE"
	,case 
		when "REV"."Grade"=0 then 'Уд.'
		when "REV"."Grade"=1 then 'Неуд.'
		else null
	end as "Оценка" -- Оценка 0-УД 1-НЕУД
	,case 
		when "REV"."TalkWithEmployee"=0 then 'ОД'
		when "REV"."TalkWithEmployee"=1 then 'БД'
		else null
	end as "Вид действия" --  провероки с типом "ПАБ" Значения: 0 - "Опасно", 1 - "Безопасно"
	,case 
		when"REV"."ObservationMethod"=0 then 'Наблюдение'
		when"REV"."ObservationMethod"=1 then 'Видеонаблюдение'
		when"REV"."ObservationMethod"=2 then 'Машинное зрение'
		else null
	end as "Метод наблюдения"
	,"REV"."RevisionTypeId" -- id Типа проверки (1-ПАБ, 4-Проверка)
	,"REV_TYP"."Name" as "Вид проверки"
	,"BUS"."Name" as "Предприятие"
	,"ExOrg"."Name"||' ('||"ExOrg"."EskCode"||')' as "Проверяемая Подр. орг."
	
/*_____________________________Направление Проверки_________________________________*/	
	
	,case when "REV"."GroupOfDirectionId" is null then "DirInsp"."Name"
		else "GrDir"."Name"  end  as "Направление проверки"
	,case when "GrDir"."Id" in (71) then "GrDir"."Name"
		else 'Внешние' end  as "Направ_ДпИ"
	
/*________________________Персонал__________________________________________________*/	
	,"E1"."LastName"||' '||
				substring("E1"."FirstName" from 1 for 1)||'. '||
					COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
						COALESCE("E1"."PersonalNumber","ExOrg_W"."Name")||')'||
							COALESCE(','||chr(10)||COALESCE("E1"."Position","PN1"."Name"),'') as "Проверяемый"
,case 
	when "E1"."PersonalNumber" like ('%:%') 
then  COALESCE(substring("E1"."PersonalNumber" from 3 for position (':' in "E1"."PersonalNumber")+10),"ExOrg_A"."Name")
	else "E1"."PersonalNumber"
end as "TN_Допустивший"							
,case  
	when "E1"."ExternalOrganizationId" is null then public."Departmen_name_full"("PT1"."DepartmentId",1)
else "ExOrg_W"."Name" end as "Место раб. проверяемого"
--,"EP2"."EventId"
,"REV"."CommissionId" -- id комисии
,case when "REV"."AuditorId" is not null    --Аудитор
		then
			"E3"."LastName"||' '||
				substring("E3"."FirstName" from 1 for 1)||'. '||
					COALESCE(substring("E3"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
						COALESCE("E3"."PersonalNumber","ExOrg_A"."Name")||')'||
							COALESCE(','||chr(10)||COALESCE("E3"."Position","PN3"."Name"),'') 
		else 'Комиссия' end as "Аудитор"
,case 
	when "E6"."PersonalNumber" is not null and "E6"."PersonalNumber" like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
then  COALESCE(substring("E6"."PersonalNumber" from 3 for position (':' in "E6"."PersonalNumber")+10),"ExOrg_A"."Name")
	when "E6"."PersonalNumber" is not null and "E6"."PersonalNumber" not like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
then  "E6"."PersonalNumber"
	when "E3"."PersonalNumber" is not null and "E3"."PersonalNumber" like ('%:%') 
then  COALESCE(substring("E3"."PersonalNumber" from 3 for position (':' in "E3"."PersonalNumber")+10),"ExOrg_A"."Name")
	else "E3"."PersonalNumber"
end as "TN_Auditor"	
,case 
		when "E3"."ExternalOrganizationId" is null 
	then 'Северсталь'
		else 'Подрядная организация'
	end as "Пров. Подрядной или Северсталь"
,case 
	when "E6"."PersonalNumber" is not null and "E6"."PersonalNumber" like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
then  COALESCE(substring("E6"."PersonalNumber" from 3 for position (':' in "E6"."PersonalNumber")+10),"ExOrg_A"."Name")
	when "E6"."PersonalNumber" is not null and "E6"."PersonalNumber" not like ('%:%') --если есть комиссия, тогда берем его, иначе из аудитора
then  "E6"."PersonalNumber"
	when "E3"."PersonalNumber" is not null and "E3"."PersonalNumber" like ('%:%') 
then  COALESCE(substring("E3"."PersonalNumber" from 3 for position (':' in "E3"."PersonalNumber")+10),"ExOrg_A"."Name")
	else "E3"."PersonalNumber"
end as "TN_A" --табельный номер аудитора
,"REV"."AuditorPkLevel" -- Уровень ПК
	
/*_______________________Место проведения проверки_________________________________*/	
,"RevDE"."DepartmentId"  --ID места проведения проверки
,"PT4"."DepartmentId" as "Depart_Проверяемый"
,"PT3"."DepartmentId" as "Depart_Аудитора"
,case 
		when"REV"."Framework" IN (true)
	then 1
		else 0
	end as "Рамка"
,CASE WHEN "REV"."IsContractor"	IN (true) 
THEN 'Проверка подрядчика' 
ELSE 'Не подрядчик'
END AS "Проверка подрядчика"
from "Revisions" as "REV"

join "BusinessUnits" "BUS" -- предприятия
on "REV"."BusinessUnitId"="BUS"."Id" and "BUS"."IsActual"  IN (true)

left join "ExternalOrganizations" as "ExOrg" -- Проверяемая организация
on "REV"."ExternalOrganizationId"= "ExOrg"."Id" and "ExOrg"."IsActual"  IN (true)

left join "RevisionTypes" as "REV_TYP" -- виды проверок
on "REV"."RevisionTypeId"="REV_TYP"."Id" and "REV_TYP"."IsActual"  IN (true)

left join "Events" as "EveI" -- события для проверки
on "REV"."EventId"="EveI"."Id" and "EveI"."IsActual"  IN (true)

/*_____________________________Направление Проверки_________________________________*/
left join "DirectionsOfInspectionsAndAudits" as "DirInsp"-- справочник направлений проверки уровня группы
on "REV"."RevisionDirectionId"="DirInsp"."Id" and "DirInsp"."IsActual" IN (true)

left join "GroupOfDirections" as "GrDir" -- справочник направлений проверки дочерних записей
on "REV"."GroupOfDirectionId"="GrDir"."Id" and "GrDir"."IsActual" IN (true)

/*________________________Персонал__________________________________________________*/
	/*___Проверяемый___*/
left join "EventParticipants" as "EP1" 
	on "REV"."SubjectId"="EP1"."Id" and "EP1"."IsActual" IN (true)
	
left join "Employees" as "E1" 
	on "EP1"."EmployeeId"="E1"."Id" and "E1"."IsActual" IN (true) --Проверяемый

left join "InternalEmployeePositionTypes" as "IEPT1" -- Назначение проверяемого
	on "E1"."Id"="IEPT1"."InternalEmployeeId" and "IEPT1"."IsActual" in (true)
	
left join "PositionTypes" as "PT1" -- место работы проверянмого
	on "IEPT1"."PositionTypeId"="PT1"."Id"-- and "PT1"."IsActual" in (true)
	
left join "PositionNames" as "PN1" -- должность проверяемого	
on "PT1"."PositionNameId" = "PN1"."Id" and  "PN1"."IsActual" in (true)

left join "ExternalOrganizations" as "ExOrg_W" -- Подрядная организация проверяемого
	on "E1"."ExternalOrganizationId"="ExOrg_W"."Id"and "ExOrg_W"."IsActual" IN (true)
																				/*___Проверяемый___*/

/*___Руководитель проверяемого___*/
--left join "EventParticipants" as "EP2" 
--	on "REV"."SubjectManagerId"="EP2"."Id"
--left join "Employees" as "E2" 
--	on "EP2"."EmployeeId"="E2"."Id" -- Руководитель проверяемого
	
-- ⚠ Правим удаление столбца SubjectManagerId.
-- ⚠ Оказалось, что "Руководитель проверяемого в проверке нигде не используется" 
--LEFT JOIN public."EventParticipants" AS ep_manag ON "REV"."EventId" = ep_manag."EventId" AND ep_manag."IsActual" AND ep_manag."ParticipantType" = 3 -- рук пров в Проверка
--LEFT JOIN public."Employees" AS e6 ON ep_manag."EmployeeId" = e6."Id"
	
/*__Аудитор__*/	
left join "EventParticipants" as "EP3" 
	on "REV"."AuditorId"="EP3"."Id"  and "EP3"."IsActual" IN (true)

	left join "Employees" as "E3" 
	on "EP3"."EmployeeId"="E3"."Id" and "E3"."IsActual" IN (true) -- Аудитор

left join "InternalEmployeePositionTypes" as "IEPT3" -- Назначение сотрудника
	on "E3"."Id"="IEPT3"."InternalEmployeeId" and "IEPT3"."IsActual" in (true)
	
left join "PositionTypes" as "PT3" -- место работы аудитора
	on "IEPT3"."PositionTypeId"="PT3"."Id" --and "PT3"."IsActual" in (true)
	
left join "PositionNames" as "PN3" -- должность аудитора	
	on "PT3"."PositionNameId" = "PN3"."Id" and  "PN3"."IsActual" in (true)

left join "ExternalOrganizations" as "ExOrg_A" -- Подрядная организация аудитора
	on "E3"."ExternalOrganizationId"="ExOrg_A"."Id"and "ExOrg_A"."IsActual" IN (true)

/*_______________________Место проведения проверки_________________________________*/	
left join "RevisionDepartments" as "RevDE" --Отдел проверки
	on "REV"."Id"="RevDE"."RevisionId" and "RevDE"."IsActual" IN (true)

left join "Departments" as "D1" 
	on "RevDE"."DepartmentId"= "D1"."Id" --and "D1"."IsActual" IN (true) -- Место проверки

left join "ImportDepartments" as "importd" 
	on "D1"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП

left join "Departments" as "D2" 
	on "RevDE"."InvestObjectId"= "D2"."Id" --Инвест объект

left join "RevisionDepartments_ViolationEvents" as "Rev_Viol" --Отдел нарушения в проверке
	on "RevDE"."Id"="Rev_Viol"."RevisionDepartmentId"  and "Rev_Viol"."IsActual" IN (true)

/*___________________ Несоответствия к проверке_____________________________________*/	

left join "ViolationEvents" as "ViEv" -- Нарушение
	on "Rev_Viol"."ViolationEventId" = "ViEv"."Id" and "ViEv"."IsActual" IN (true)

left join "Events" as "Eve_Vi" -- событие к Нарушению
	on "ViEv"."EventId"="Eve_Vi"."Id" and "Eve_Vi"."IsActual" IN (true)

left join public."ViolationKindSections" as "ViKS" --Раздел нарушения (Справочник направлений нарушений)
	on "ViEv"."ViolationKindSectionId"="ViKS"."Id"

left join public."Risk_Dangers" as "Ri_D" -- Смертельные рискм
	on "ViEv"."DangerId" = "Ri_D"."Id" and "Ri_D"."IsActual" IN (true) and "Ri_D"."Id" <>99

left join public."ViolationEventBasicRules" as "ViBaRU" --Связь нарушения с БПСЖ
	on "ViEv"."Id"= "ViBaRU"."ViolationEventId" and "ViBaRU"."IsActual" IN (true)

left join public."BasicRules" as "BPSJ" --БПСЖ
	on "ViBaRU"."BasicRuleId"="BPSJ"."Id" 
	--and "BPSJ"."IsActual"IN (true) 
	and "BPSJ"."Id"<>39

left join public."ExternalOrganizations" as "ExOrg2" -- Подрядная организация допустившая несоответствие
	on "ViEv"."ContractorExternalOrganizationId"= "ExOrg2"."Id" and "ExOrg2"."IsActual" IN (true)

/*___________________Принятые меры руководителем по ПАБ_____________________________________*/
left join (select 
		"VTM"."ViolationEventId" as "IdVTM"
		,string_agg("TM"."Name",';'||chr(10) ORDER by "TM"."Id") as "Дисциплин. меры"
		FROM public."ViolationEvent_TakenMeasures" as "VTM"
		left join public."TakenMeasures" as "TM"
			on "VTM"."TakenMeasureId"="TM"."Id"
		where "VTM"."IsActual" in (true) and "TakenMeasureId" not IN (4)
		group by "VTM"."ViolationEventId"
	) as "PM"
	on "ViEv"."Id"= "PM"."IdVTM"

/*___________________Допустивший несоответствие_____________________________________*/	
				
left join public."EventParticipants" as "EP4" --Участник события
	on "ViEv"."EventId"="EP4"."EventId" and "EP4"."IsActual" IN (true) and "EP4"."ParticipantType"=4 -- 4 - нарушитель

left join public."Employees" as "E4" 
	on "EP4"."EmployeeId"="E4"."Id" and "E4"."IsActual" IN (true)

left join public."InternalEmployeePositionTypes" as "IEPT4" -- Назначение сотрудника
	on "E4"."Id"="IEPT4"."InternalEmployeeId" and "IEPT4"."IsActual" in (true)
	
left join public."PositionTypes" as "PT4" -- место работы допустившего несоответствие
	on "IEPT4"."PositionTypeId"="PT4"."Id" --and "PT4"."IsActual" in (true)
	
left join public."PositionNames" as "PN4" -- должность допустившего несоответствие
on "PT4"."PositionNameId" = "PN4"."Id" and  "PN4"."IsActual" in (true)

left join public."ExternalOrganizations" as "ExOrg_WN" -- Подрядная допустившего несоответствие
	on "E4"."ExternalOrganizationId"="ExOrg_WN"."Id" and "ExOrg_WN"."IsActual" IN (true)

/*_____________________Мероприятия к несоответствиям________________________________________*/
left join public."Violation_EliminationCausesEvent" as "ViECE" --Связь события и нарушения
on "ViEv"."Id"="ViECE"."ViolationEventId" and "ViECE"."IsActual" IN (true)

left join public."Events" as "Eve_Act" -- Мероприятие 
on "ViECE"."EventId"="Eve_Act"."Id" and "Eve_Act"."IsActual" IN (true)

/*_____________________________Ответственный за мероприятие________________________________*/
left join public."EventParticipants" as "EvPr_Act"
	on "Eve_Act"."Id"="EvPr_Act"."EventId" and "EvPr_Act"."IsActual" IN (true) and "EvPr_Act"."ParticipantType"=2 -- Ответственный

left join public."Employees" as "E5" on "EvPr_Act"."EmployeeId"="E5"."Id"

left join public."ExternalOrganizations" as "ExOrg_Act"
on "E5"."ExternalOrganizationId"="ExOrg_Act"."Id" -- Подрядная ответственного за мероприятие

left join public."InternalEmployeePositionTypes" as "IEPT5" -- Назначение сотрудника
	on "E5"."Id"="IEPT5"."InternalEmployeeId" and "IEPT5"."IsActual" in (true)
	
left join public."PositionTypes" as "PT5" -- место работы оответственного за мероприятие
	on "IEPT5"."PositionTypeId"="PT5"."Id" --and "PT4"."IsActual" in (true)
	
left join public."PositionNames" as "PN5" -- должность ответственного за мероприятие
on "PT5"."PositionNameId" = "PN5"."Id" and  "PN5"."IsActual" in (true)

/*_______ Привязываем комиссию, будем выводить председателя комиссии ___________*/
left join "CommissionParticipants_Revision" 
	on "REV"."Id"="CommissionParticipants_Revision"."RevisionId" 
		and "CommissionParticipants_Revision"."IsActual" IN (true) and "CommissionParticipants_Revision"."IsTheChair" IN (true)
		
/*_______ Расшифровываем председателя ___________*/
left join "CommissionParticipants" 
	on "CommissionParticipants_Revision"."CommissionParticipantId"="CommissionParticipants"."Id" 
		and "CommissionParticipants"."IsActual" IN (true)

/*_______  для табельного номера председателя ___________*/
left join "Employees" as "E6" 
	on "CommissionParticipants"."EmployeeId"="E6"."Id" and "E6"."IsActual" IN (true) -- Аудитор

WHERE "REV"."IsActual" IN (true)
and "REV"."RevisionTypeId" in (4,1)
--and "CommissionId" is not null
--and "REV"."Id" IN (622191)
--and "ViEv"."EventId" =279376
and "EveI"."EndingDate">=to_date('01012025','ddmmyyyy')
and ("GrDir"."Id"not in (8) or "GrDir"."Id" is null) --ПК супервайзеры, Группа по развитию подрядных организаций
and concat("REV"."RevisionTypeId","ViolationNature")<>'40' -- убираем ОД из проверок.
--and "REV"."IsContractor" in (false)
),


/*___________________ Ответственные лица. МУПРы_____________________________________*/    

"MUPR" as (
select 
       "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                  as "ФИО МУПР" 
       ,"D1"."DepartmentName" as "Цех" -- Цех
       ,"ref_shop"."DepartmentId" as "ID_SHOP_MUPR" --идентификатор цеха
 	,"REKURS"."OBJID"::numeric as "OBJID"
	,("REKURS"."WORKS_OBJID"::numeric)::text as "MUPR_OBJID_Цех"
	,"REKURS"."WORKSHOPS" as "MUPR_Цех"
  ,case 
       when "E1"."PersonalNumber" like ('%:%')
then (substring("E1"."PersonalNumber" from 3 for position (':' in "E1"."PersonalNumber")+10))::numeric
       else "E1"."PersonalNumber"::numeric
end as "TN_MUPR"

from"EmployeeResponsibilityInDepartments" "ref_shop"

left join "Employees" as "E1" on "ref_shop"."EmployeeId"="E1"."Id" --ФИО начальника цеха
left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id" -- цех
left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" -- название ответственности 
left join "REKURS" on "ref_shop"."DepartmentId"="REKURS"."ID_KOT"  -- связь с рекурсией для вывода OBJID
where "ResponsibilityTypeId" in (106)
and "ref_shop"."IsActual" IN (true)
),

"FULL_PROVERKI" as (
select  distinct 
"FULL_PROV". "Оценка"
	,"FULL_PROV"."Id" as  "ИД_Проверки"
	,"FULL_PROV"."Вид проверки"
	,"FULL_PROV"."LINK"
	,"FULL_PROV"."DATE"
	,"FULL_PROV"."Аудитор"
	,"FULL_PROV"."TN_Auditor"
	,"Рамка"
	,"FOREMAN_OBJID"."FIO_TN_PROF" as "Допустивший_FIO_TN_PROF"
	,"FOREMAN_OBJID"."OBJID_Цех" as "Допустивший_OBJID_Цех"
	,"FOREMAN_OBJID"."Цех" as "Допустивший_Цех"
	,"FOREMAN_OBJID2"."FIO_TN_PROF" as "Аудитор_FIO_TN_PROF"
	,"FOREMAN_OBJID2"."OBJID_Цех" as "Аудитор_OBJID_Цех"
	,"FOREMAN_OBJID2"."Цех" as "Аудитор_Цех"
	,"MUPR"."MUPR_OBJID_Цех" 
	,"MUPR"."TN_MUPR" 
	,"MUPR"."MUPR_Цех" as  "Цех_МУПР"
		,case 
		when "REKURS3"."L_REITING" is not null --ЕСЛИ пусто уровень цеха, но есть уровень участка, тогда берем уровень участка за уровень цеха
	then "REKURS3"."L_REITING"::numeric 
		else "REKURS3"."OBJID" ::numeric  
	end as "OBJID_Места"
	,case 
		when "REKURS3"."L_REITING" is not null --ЕСЛИ пусто уровень цеха, но есть уровень участка, тогда берем уровень участка за уровень цеха
	then "REKURS3"."WORKSHOPS"
		else "REKURS3"."NAME" 
	end as "Цех_Места"
	,case 
		when "FULL_PROV"."TN_Auditor"::numeric="MUPR"."TN_MUPR"::numeric --если аудитором был свой мупр
	then 1
		when "FOREMAN_OBJID"."OBJID_Цех"="FOREMAN_OBJID2"."OBJID_Цех"
	then 1
		else 0 end as "Внутренние_БПСЖ"
	,case
		when "FULL_PROV"."TN_Auditor"::numeric="MUPR"."TN_MUPR"::numeric  --если аудитором был свой мупр
	then 0
		when "FOREMAN_OBJID"."OBJID_Цех"="FOREMAN_OBJID2"."OBJID_Цех"
	then 0
		else 1 end as "Внешние_БПСЖ"
	
		,case 
			when "FOREMAN_OBJID"."OBJID_Цех" is null and (("REKURS3"."L_REITING"::numeric="FOREMAN_OBJID2"."OBJID_Цех"::numeric) or ("REKURS3"."L_REITING"="MUPR"."MUPR_OBJID_Цех") )--если аудитором был свой и нет проверяемого
	then 1
		when "TN_Auditor"::numeric="TN_MUPR"::numeric --если аудитором был свой мупр
	then 1
		when "FOREMAN_OBJID2"."OBJID_Цех"="FOREMAN_OBJID"."OBJID_Цех"  --если место работы аудитора равно месту работы проверяемого
	then 1
		when "FULL_PROV"."TN_Auditor"::numeric="MUPR"."TN_MUPR"::numeric --если аудитором был свой мупр
	then 1		
	
	else 0	
	end as "Внутренние"
	,case 
			when "FOREMAN_OBJID"."OBJID_Цех" is null and (("REKURS3"."L_REITING"::numeric="FOREMAN_OBJID2"."OBJID_Цех"::numeric) or ("REKURS3"."L_REITING"="MUPR"."MUPR_OBJID_Цех") )--если аудитором был свой и нет проверяемого
	then 0
		when "TN_Auditor"::numeric="TN_MUPR"::numeric --если аудитором был свой мупр
	then 0
		when "FOREMAN_OBJID2"."OBJID_Цех"="FOREMAN_OBJID"."OBJID_Цех"   --если место работы аудитора равно месту работы проверяемого
	then 0
		when "FULL_PROV"."TN_Auditor"::numeric="MUPR"."TN_MUPR"::numeric --если аудитором был свой мупр
	then 0 	
		else 1	
	end as "Внешние"
	,case 
		when "FOREMAN_OBJID"."OBJID_Цех" is null and "REKURS3"."L_REITING" is not null--если нет допустившего нарушение, тогда берем цех проведения проверки
	then ((("REKURS3"."L_REITING")::numeric )::text||EXTRACT(year FROM "DATE"::date)||EXTRACT(Month FROM "DATE"::date))::numeric
		when "FOREMAN_OBJID"."OBJID_Цех" is null  and "REKURS3"."PLOTS_OBJID" is not null--если нет допустившего нарушение, тогда берем участок проведения проверки
	then ((("REKURS3"."PLOTS_OBJID")::numeric )::text||EXTRACT(year FROM "DATE"::date)||EXTRACT(Month FROM "DATE"::date))::numeric 
		when "FOREMAN_OBJID"."OBJID_Цех" is null  and "REKURS3"."OBJID" is not null--если нет допустившего нарушение, тогда берем место проведения проверки
	then ((("REKURS3"."OBJID")::numeric )::text||EXTRACT(year FROM "DATE"::date)||EXTRACT(Month FROM "DATE"::date))::numeric 		
			
	else ("FOREMAN_OBJID"."OBJID_Цех"::text||EXTRACT(year FROM "DATE"::date)||EXTRACT(Month FROM "DATE"::date))::numeric 
	end as "STRUCT_YEAR_MONTH"	
	
		
from "FULL_PROV"

/*_________ связь с рекурсией для места проведения проверки для проверок без проверяемого   ________________*/
left join "REKURS" as "REKURS3"  -- место проведения проверки с рекурсией для вывода OBJID уровня цеха
	on "REKURS3"."ID_KOT"="FULL_PROV"."DepartmentId"		
	
/*_________ связь с Допустившим нарушение на момент нарушения ________________*/
left join "FOREMAN_OBJID" -- место работы Допустившего нарушение связь с рекурсией для вывода OBJID урвня цеха
	on "FOREMAN_OBJID".PERNR::numeric ="FULL_PROV"."TN_Допустивший"::numeric
		and "FULL_PROV"."DATE" between  "FOREMAN_OBJID".BEGDA and "FOREMAN_OBJID".ENDDA

		/*_________ связь с Аудитором на момент нарушения ________________*/
left join "FOREMAN_OBJID" as "FOREMAN_OBJID2" -- место работы Допустившего нарушение связь с рекурсией для вывода OBJID урвня цеха
	on "FOREMAN_OBJID2".PERNR::numeric ="FULL_PROV"."TN_Auditor"::numeric
		and "FULL_PROV"."DATE" between  "FOREMAN_OBJID2".BEGDA and "FOREMAN_OBJID2".ENDDA
	/*_________ связь с МУПРами   ________________*/
left join "MUPR" -- выводим при совпадении цеха МУПРа и табельного номера МУПРа с цехом Проверяемого и табельного номера Аудитора
	on ("MUPR"."MUPR_OBJID_Цех"::numeric )::text||"TN_MUPR"=("FOREMAN_OBJID"."OBJID_Цех"::numeric )::text||"FULL_PROV"."TN_Auditor"		
		or ("MUPR"."MUPR_OBJID_Цех"::numeric )::text||"MUPR"."TN_MUPR"=("REKURS3"."L_REITING"::numeric )::text||"FULL_PROV"."TN_Auditor"
			
	
	WHERE 	"Проверка подрядчика" IN ('Не подрядчик')
			)

select  * from "FULL_PROVERKI"
