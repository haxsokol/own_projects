
WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" in (true)
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId" as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),

"CALENDAR" as (
SELECT 	
(EXTRACT(year  from r)::text||EXTRACT(month  from r)::text) as "year_month"

FROM generate_series('2024-02-01',now()::date, '1 month') as r
			),
/*справочник Ответственные лица.Рейтинг цехов. Максимальный балл Проверка локаций и КББ (ОРБ)*/
"MAX" as (
select 
"D1"."DepartmentName" as "Цех" -- Цех
,"Ref_OTV"."Name"
,"import"."ExternalId"::numeric  as "OBJID"
,"ResponsibilityTypeId"
       
from "EmployeeResponsibilityInDepartments" "ref_shop"

	left join "Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id" -- цех
	left join "ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" -- название ответственности
	left join "ImportDepartments" as "import" on "D1"."Id"="import"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
where "ResponsibilityTypeId" in (183) --183 - Рейтинг цехов. Максимальный балл Проверка локаций и КББ (ОРБ),184 - Рейтинг цехов. Максимальный балл ПК-1
and "ref_shop"."IsActual" IN (true)
),
			
maximum as (
select 
("MAX"."OBJID"::text||"CALENDAR"."year_month")::numeric as "STRUCT_YEAR_MONTH"
,1 as "PLAN",1 as "FACT",1 as "% устранения"
from "CALENDAR","MAX"		
),


EventEnd as (
SELECT 
DISTINCT 
 ve."EventId" "Id_несоответствие"
,vece."EventId" "Id_мероприятие"
,case 
	when count(vece."EventId") = count(e."ExecutionDate")
	then max(e."ExecutionDate")
	when e2."Description" is null and e2."Theme" is null and e2."ExecutionDate" is null and e."ExecutionDate" is not null 
	then e."ExecutionDate"
	else null
end "Дата устранения отк-я КББ (факт)"
FROM public."ViolationEvents" ve 
left join public."Events" e on ve."EventId"=e."Id" and e."IsActual"=true
left join public."Violation_EliminationCausesEvent" vece on ve."Id"=vece."ViolationEventId" and vece."IsActual"=true
left join public."Events" e2 on vece."EventId"=e2."Id" and e2."IsActual"=true
group by 
 ve."EventId"
,vece."EventId"
,e2."Description"
,e2."Theme"
,e2."ExecutionDate"
,e."ExecutionDate"
),


EventEndingDateChangeHistory as (
SELECT DISTINCT 
"EventId"
,"Id" 
,count("Id") q
FROM public."EventEndingDateChangeHistory"
WHERE "EndingDateOld"<"EndingDate"
group by "EventId","Id"),

BASA_PK_0 as (
SELECT 
DISTINCT 
 s."Id"  -- Id смены
,s."ShiftLogId" --Id журнала
,s."StartDateTime"  --Время приёма смены
,s."EndDateTime"  --Время сдачи смены
,case 
	when se."WatchingTime" is not null  then se."WatchingTime" else s."StartDateTime" end "WatchingTime"
,case 
	when se."WatchingTime" is not null and se."WatchingTime"::time<sl."TimeDay"-interval '1' hour --ночная смена отн-ся к пред.дню
	then se."WatchingTime"::date-1 
	when se."WatchingTime" is not null and se."WatchingTime"::time>sl."TimeDay"-interval '1' hour 
	then se."WatchingTime"::date
	when se."WatchingTime" is not null and sl."TimeDay" is null 
	then se."WatchingTime"::date
	when s."StartDateTime"::time<sl."TimeDay"-interval '1' hour --ночная смена отн-ся к пред.дню
	then s."StartDateTime"::date-1
	else s."StartDateTime"::date 
	end "Дата"
,case 
	when e4."ExternalOrganizationId" is null 
	then concat(e4."LastName",' ',substring(e4."FirstName" from 1 for 1),'.',substring(e4."SecondName" from 1 for 1),'. (',cast(replace(e4."PersonalNumber",':','') as numeric),')') 
	--else concat(e4."LastName",' ',substring(e4."FirstName" from 1 for 1),'.',substring(e4."SecondName" from 1 for 1),'. (ПО)') --подрядчики
	else concat(e4."LastName",' ',e4."FirstName",' ',e4."SecondName",' (ПО)') --подрядчики, полное ФИО
	end "FIO (TN)" --Сменщик
,s."CrewId" --Бригада
,s."ShiftNumber"  --Номер смены
,"REKURS"."L_REITING"::numeric as REVISIONDEPARTMENTID
,se."ShiftLogEquipmentId"
,rd."Id" id_deadly_risk
,case 
	when sle."CustomEquipment" is not null then sle."CustomEquipment" else e5."Name" end "КББ"
,se."Description" "Кoмментарии"
,sewr."WorkerReactionId"
,wr."Name" "Поведенческие барьеры"
,case 
	when e2."Description" is null and e2."Theme" is null and e2."ExecutionDate" is null and e."ExecutionDate" is not null then 'Без мероприятия - устранено в течение смены'
	when e2."Description" <>'' then e2."Description"	when e2."Description" =''	then e2."Theme" END "Мероприятия по устранению отк-я КББ"
,case 
	when e2."Description" is null and e2."Theme" is null and e2."ExecutionDate" is null and e."ExecutionDate" is not null then 'корр.'
  when e2."CorrectiveActions"=true then 'корр.' when e2."CorrectiveActions"=false then 'комп.'  end "Тип"
,e2."EndingDate" "Дата устранения отк-я КББ (план)"
,case 
	when e2."ExecutionDate" is null 
then e."ExecutionDate" 
	else e2."ExecutionDate" 
end as"Дата устранения отк-я КББ (факт)"

,case 
	when e3."Id">0 then concat(e3."LastName",' ',substring(e3."FirstName" from 1 for 1),'.',substring(e3."SecondName" from 1 for 1),'. (',cast(replace(e3."PersonalNumber",':','') as numeric),')')  END "Oтветственный ФИО"
,CONCAT('https://kot.severstal.com/audits_severstal/shift_log/', s."ShiftLogId") link_loc -- Ссылка на журнал
,case 
	when vece."EventId" is not null then CONCAT('https://kot.severstal.com/events/plannings/events/single/', vece."EventId") END link_ev -- Ссылка на мероприятие
,case 
	when ve."EventId" is not null then CONCAT('https://kot.severstal.com/revisions_severstal/violation_event/', ve."EventId") END link_viol -- Ссылка на несоответствие
,ve."EventId" "Id_несоответствие" 
,vece."EventId" "Id_мероприятие"
,ee.q "Кол-во переносов"
,eedchpc."EventProlongCauseId" 
,(EXTRACT(year from eee."Дата устранения отк-я КББ (факт)"))::text||(EXTRACT(months from eee."Дата устранения отк-я КББ (факт)"))::text as "Месяц устранения"
,case 
	when se."WatchingTime" is not null 
then (EXTRACT(year from se."WatchingTime"))::text||(EXTRACT(months from se."WatchingTime"))::text 
	else (EXTRACT(year from s."StartDateTime"))::text||(EXTRACT(months from s."StartDateTime"))::text 
end as "Месяц_проверки"
,case 
	when (EXTRACT(year from eee."Дата устранения отк-я КББ (факт)"))::text||(EXTRACT(months from eee."Дата устранения отк-я КББ (факт)"))::text=(EXTRACT(year from se."WatchingTime"))::text||(EXTRACT(months from se."WatchingTime"))::text 
	or (EXTRACT(year from eee."Дата устранения отк-я КББ (факт)"))::text||(EXTRACT(months from eee."Дата устранения отк-я КББ (факт)"))::text=(EXTRACT(year from s."StartDateTime"))::text||(EXTRACT(months from s."StartDateTime"))::text  
	then 1
	else 0
end as "Устранено_в_этом_месяце"

FROM 
public."Shifts" s 
join public."Employees" e4 on s."EmployeeId"=e4."Id" 
join public."ShiftLogs" sl on s."ShiftLogId"=sl."Id" and sl."IsActual"=true
join public."ShiftEquipment" se on s."Id"=se."ShiftId" and (se."IsOperational" = false or se."ViolationEventId" is not null)--по просьбе С.В. 20.05.25
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
left join public."Equipments" e5 on sle."EquipmentId"=e5."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
left join public."ShiftEquipment_WorkerReactions" sewr on se."Id"=sewr."ShiftEquipmentId" 
join public."ImportDepartments" id on sl."DepartmentId"=id."DepartmentId"
left join public."WorkerReactions" wr on sewr."WorkerReactionId"=wr."Id" 
left join public."ViolationEvents" ve on se."ViolationEventId"=ve."Id"
left join public."Events" e on ve."EventId"=e."Id" and e."IsActual"=true
left join public."Violation_EliminationCausesEvent" vece on ve."Id"=vece."ViolationEventId" and vece."IsActual"=true 
left join public."Events" e2 on vece."EventId"=e2."Id" and e2."IsActual"=true
left join public."EventParticipants" ep on vece."EventId"= ep."EventId"
left join public."Employees" e3 on ep."EmployeeId"=e3."Id" 
left join EventEndingDateChangeHistory ee on vece."EventId"=ee."EventId"
left join public."EventEndingDateChangeHistory_ProlongCause" eedchpc ON eedchpc."EventEndingDateChangeHistoryId" = ee."Id" and eedchpc."EventProlongCauseId" in(9,10,11,12,13)
left join EventEnd eee on ve."EventId"=eee."Id_несоответствие"
/*_________ связь с рекурсией для вывода журналов ниже цеха  ________________*/
left join "REKURS"  -- 
	on "REKURS"."OBJID"::numeric=id."ExternalId"::numeric 

	where ve."EventId" is not null


),


"PLAN" as (
select  
count (distinct"Id"||"КББ") as "PLAN"
,((revisiondepartmentid::integer)::text||EXTRACT(year from "Дата")||EXTRACT(months from "Дата"))::numeric   as "STRUCT_YEAR_MONTH"
from BASA_PK_0
group by "STRUCT_YEAR_MONTH"
),

"FACT" as (
select  
count (distinct"Id"||"КББ") as "FACT"
,((revisiondepartmentid::integer)::text||EXTRACT(year from "Дата")||EXTRACT(months from "Дата"))::numeric   as "STRUCT_YEAR_MONTH"
from BASA_PK_0
where "Дата устранения отк-я КББ (факт)" is not null
and "Тип" in ('корр.')
and "Устранено_в_этом_месяце"=1
group by "STRUCT_YEAR_MONTH"
),


"ITOG" as (
select 
"PLAN"."STRUCT_YEAR_MONTH"::numeric
,case when "PLAN"::numeric is null then 0 else "PLAN"::numeric end as "PLAN"
,case when "FACT"::numeric is null then 0 else "FACT"::numeric end as "FACT"
,case 
	when "PLAN"::numeric is null or "FACT"::numeric is null 
then 0 
	when "PLAN"::numeric=0 or "FACT"::numeric=0
then 0 
	else "FACT"::numeric/"PLAN"::numeric 
end as "% устранения"


from  "PLAN"
left join "FACT"
	on "FACT"."STRUCT_YEAR_MONTH"="PLAN"."STRUCT_YEAR_MONTH"
--where "PLAN"."STRUCT_YEAR_MONTH" in (400472420246,2003543320246,2000637220246) 
)


select * from "ITOG"
where "STRUCT_YEAR_MONTH" is not null

union
select * from maximum
--where "STRUCT_YEAR_MONTH" in (20055191202410) 