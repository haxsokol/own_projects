WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,COALESCE("DepartmentLevelId",1) as "ROOT_L"
                    ,"importd"."ExternalId"
                    
                                               
                    FROM public."Departments"
             			left join public."ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"    as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    
                           
             FROM public."Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,"L4"."ExternalId" as "WORKS_OBJID"
,COALESCE("L4"."ROOT_NAME",'Участки(Ур-нь цеха не задан)') as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"


FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок
),


"SHOP" as (select 
	"Documents"."Name"
	,"Documents"."DocStartDate"::date as "DS"
	,case 
		when "Documents"."DocEndDate" is null then now()::date
		else "Documents"."DocEndDate"::date
	end as "DE"
	,"Documents"."Number"
	,"D1"."DepartmentName"
	,"Documents"."Code" --идентификтор предка

from public."Documents" as "Documents" 
left join public."ImportDepartments" as "importd"  on "Documents"."Number"::integer="importd"."ExternalId"::integer -- цех OBJID цехов	
left join public."Departments" as "D1" on "D1"."Id"="importd"."DepartmentId"
left join "REKURS" on "REKURS"."OBJID"::integer="Documents"."Number"::integer
where 
	"Description" IN ('Рейтинг цеха')
	and "Documents"."IsActual" in (true)
--	and "Documents"."Number" in ('4004727') --тест на цехе
	) ,
	
/*___________________ генерация виртуального календаря_____________________________________*/		
CALENDAR as (SELECT * FROM generate_series('2023-01-01',
                               now()::date, '1 month') as r),
                               
STRUCT_SHOP as (select distinct
	CALENDAR."r"::date as "CALENDAR_DATE"
	,"DepartmentName" as "Цех"
	,"Number"||EXTRACT(year FROM CALENDAR."r"::date)||EXTRACT(Month FROM CALENDAR."r"::date) as "STRUCT_YEAR_MONTH"
	,"Number" as "OBJID"
from  CALENDAR,   "SHOP" 
/*___________________ объединени двух таблиц_____________________________________*/		          
where CALENDAR."r" between "SHOP"."DS" and "SHOP"."DE"
),

/*___________________ генерация виртуального календаря по одной на каждую неделю_____________________________________*/	
CALENDAR_week as (
	SELECT 	distinct 
		EXTRACT(week from r) as "№_недели"
		,EXTRACT(month from r) as "№_месяца"
		,EXTRACT(YEAR from r) as "YEAR"
		,date_trunc('week',r) ::date as "FIRST_DAY_week"
		,((date_trunc('week',r) + interval '1 week') - interval '1 day')::date as "LAST_DAY_week"
		,date_trunc('month',r) ::date as "FIRST_DAY_month"

	FROM generate_series('2024-01-01',now()::date, '1 day') as r
	group by r
	having not date_trunc('week',r)::date='2024-12-30'	--убираем неделю с 2024-12-30 по 2025-01-05 
		),
		
/*___________________ Определяем, назначен ли НЦ _____________________________________*/			
"41.Начальник цеха" as (
select        "E1"."LastName"||' '|| -- ФАМИЛИЯ
             substring("E1"."FirstName" from 1 for 1)||'. '|| --имя с точкой
                    COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')  --отчество с точкой
                           ||' ('|| "E1"."PersonalNumber"||')'--табльный номер
                                  as "ФИО начальника" 
  --     ,"D1"."DepartmentName" as "Цех" -- Цех
       ,"Ref_OTV"."Name" as "Вид ответственности"
       ,COALESCE("E1"."Position","PN3"."Name") as "Должность руководителя цеха"
       ,case 
       		when "E1"."PersonalNumber" like ('1:%')
       	then SUBSTRING("E1"."PersonalNumber",3)
       		else "E1"."PersonalNumber"
       end as "TN"
       ,"importd"."ExternalId" as "OBJID"
       ,case 
       		when "ref_shop"."IsMain" in (true) then 1 
       		else 0 end as "PLAN"
    --   	,"ref_shop".*
		
from public."EmployeeResponsibilityInDepartments" "ref_shop" --справочник ответственные лица

/*_____ связь для вывода ФИО начальников ____________________________*/  
	left join public."Employees" as "E1" on "ref_shop"."EmployeeId"="E1"."Id"
	
/*_____ связь для вывода названия цехов ____________________________*/  	
	left join public."Departments" as "D1" on "ref_shop"."DepartmentId"="D1"."Id"
	
/*_____ связь для вывода названия ответственности ____________________________*/  	
	left join public."ResponsibilityTypes" as "Ref_OTV" on "ref_shop"."ResponsibilityTypeId"="Ref_OTV"."Id" 

/*_____связь перекодировочной таблицы и единого справочника для получения "DepartmentId" по OBJID цехов____________________________*/  		
	left join public."ImportDepartments" as "importd" on "importd"."DepartmentId"="ref_shop"."DepartmentId" -- связываем со справочником цехов  	  
	
/*_____ Назначение сотрудника на должность. Связь с единой таблицей  Employees ____________________________*/
left join public."InternalEmployeePositionTypes" as "IEPT3" 
	on "E1"."Id"="IEPT3"."InternalEmployeeId" and "IEPT3"."IsActual" in (true)

	
/*_____ Связь с местом работы для дальнейшей связи с должностью ____________________________*/	
left join public."PositionTypes" as "PT3" -- место работы аудитора
	on "IEPT3"."PositionTypeId"="PT3"."Id" --and "PT3"."IsActual" in (true)
	
/*_____ Связь места работы с должностью ____________________________*/		
left join public."PositionNames" as "PN3" -- должность аудитора	
	on "PT3"."PositionNameId" = "PN3"."Id" and  "PN3"."IsActual" in (true)
		
	
	where "ref_shop"."ResponsibilityTypeId" in (61) --идентификатор 41. Начальник цеха
	--and "E1"."PersonalNumber" in ('1:1403204')
	
),
		
		
		
/*___________________ вычисление плана ПК-2 _____________________________________*/			

PLAN as (select * 

from STRUCT_SHOP, CALENDAR_week
where CALENDAR_week."FIRST_DAY_month"=STRUCT_SHOP."CALENDAR_DATE"
),


"41" as (
select distinct
	PLAN."CALENDAR_DATE"
	,PLAN."Цех"
	,PLAN."STRUCT_YEAR_MONTH"
	,PLAN."OBJID"
	,PLAN."№_недели"
	,PLAN."№_месяца"
	,PLAN."FIRST_DAY_week"
	,PLAN."LAST_DAY_week"
	,PLAN."FIRST_DAY_month"
	,case 
		when "41.Начальник цеха"."ФИО начальника" is null
	then 'Не заполнен справочник 41.Начальник цеха'
		else "41.Начальник цеха"."ФИО начальника"  end as "ФИО начальника"
	, "41.Начальник цеха"."Вид ответственности"
	, "41.Начальник цеха"."Должность руководителя цеха"
	, "41.Начальник цеха"."TN"
	, "41.Начальник цеха"."PLAN"
	, case 
		when "41.Начальник цеха"."PLAN"=1 
			then 'Начальник'
		else 'Заместитель' end as "Начальник/Заместитель"
,("41.Начальник цеха"."TN"::integer)::text||(EXTRACT(year from PLAN."CALENDAR_DATE"))::text||"№_недели"::text as "TN_YEAR_MONTHS"
from PLAN
left join "41.Начальник цеха" on PLAN."OBJID"::integer="41.Начальник цеха"."OBJID"::integer
),




"PLAN" as (
select 
"STRUCT_YEAR_MONTH","№_недели","№_месяца","YEAR"
,1 as PLAN
from PLAN
group by "STRUCT_YEAR_MONTH","№_недели","№_месяца","YEAR"
)


select * from "PLAN"


