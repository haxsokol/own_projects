WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)')
	else COALESCE("L4"."ROOT_NAME",'Участки(Ур-нь цеха не задан)') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId" as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"


FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок
),


"Event"  as (
/*___________________ группировка для вычисления одного иденификатора _____________________________________*/

select distinct
	"InjurySeverstalResponsibleDepartments"."InjurySeverstalId" -- не идентификатор карты происшествия
	,"InjurySeverstal"."InjuryId"-- идентификатор карты происшествия
	,"DeptResp2"."DepartmentName" AS "ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ"  --берем только для собственного для карты с одним пострадавшим
	,"importd"."ExternalId" AS "OBJID_ВНУТР_ПОСТРАДАВШИЙ"  --берем только для собственного для карты с одним пострадавшим
	,"DeptResp2"."Id" AS "ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"  --берем только для собственного для карты с одним пострадавшим
	,case 
		 when "InjuryKinds"."Id" in (8,9) 
	then 'Подрядчик'
		when "InjuryKinds"."Id" in (7) 
	then 'Собств.'
		when "InjuryKinds"."Id" in (10) 
	then '3 лицо (неучет.)'
		when "InjuryKinds"."Id" in (6) 
	then 'Собств.'   --изменил на Собвственный, т.к. Подрядчики уже корректно.
		else 'Устанваливается'
	 end AS "InjuryKindName" --(8 и 9 - Подрядчик Субподрядчик, 7 - собственный, 10 - 3 лицо, 6 - нет пострадавшего)
	 ,"InjuryHurt"."Id"
	 ,"InjuryHurt"."IsActual" as "Актуальность пострадавшего"
	 ,"InjuryHurtSeverstal"."InternalWorkPlaceId"
	 ,"InjuryHurtSeverstal"."CustomExternalWorkPlace"
	 ,"ContractorCulprits". "ContractorId"
	 ,"ContractorCulprits"."CustomContractor"
	 ,"ExternalOrganizations"."Name"
	,"ExOrg_WN"."Name" as "NAME_ORG_IN_PERSONAL_NUMBER"
		,"ExOrg_WN"."Inn" as "Inn_ORG_IN_PERSONAL_NUMBER"
	 ,"E0"."FirstName"
	 ,case 
	 	when "ExOrg_WN"."Name" is not null
	 then "ExOrg_WN"."Name"||' ('||"ExOrg_WN"."Inn"||')'
	 	else "ExternalOrganizations"."Name"||' ('||"ExternalOrganizations"."Inn"||')' 
	 end as "Название (ИНН)"
	,case 
	when "ExOrg_WN"."Name" is not null
		then "ExOrg_WN"."Name"||' ('||"ExOrg_WN"."Inn"||')'
	when "ExternalOrganizations"."Inn" is null and "ExternalOrganizations"."Name" is not null
		then "ExternalOrganizations"."Name"
	 when "ExternalOrganizations"."Inn" is not null
		then "ExternalOrganizations"."Name"||' ('||"ExternalOrganizations"."Inn"||')'
	when "InjuryHurt"."ExternalContractorOrganization" is not null
		then "InjuryHurt"."ExternalContractorOrganization"
	 when "ExternalOrganizations"."Inn" is null and "ContractorCulprits"."CustomContractor" is null
		then "InjuryHurtSeverstal"."CustomExternalWorkPlace"
	 when "ExternalOrganizations"."Inn" is null 
	 		then "ContractorCulprits"."CustomContractor" 
	else "InjuryHurt"."ExternalContractorOrganization"
	 end as "Подрядная организация"
	 ,"InjuryDate"::date	
	 ,"InjuryClasses"."Name" as "Область"
	 ,"Injurys"."Id"
	 ,case 
	 	when "Injurys"."OnProduction" in (true)
	 then 'Связано с производством'
		 else 'Не связано'
	 end as "Свявзано с производством"
	 ,"import"."ExternalId" as "OBJID_ответственный_цех_без_травм"
	 ,"InjurySeverstalResponsibleDepartments"."IsActual"
	 ,"InjuryHurt"."ExternalEmployeeId"
	 
from "InjurySeverstal"


LEFT JOIN "InjurySeverstalResponsibleDepartments" 
	ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId" 
		and "InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null 

LEFT JOIN "Departments" AS "DeptResp" ON "InjurySeverstalResponsibleDepartments"."DepartmentId" = "DeptResp"."Id"
left join "ImportDepartments" as "import"  on "DeptResp"."Id"::integer="import"."DepartmentId"::integer -- цех OBJID цехов	
LEFT join "Injurys" on "InjurySeverstal"."InjuryId" = "Injurys"."Id"
LEFT JOIN "InjuryKinds" ON "Injurys"."InjuryKindId" = "InjuryKinds"."Id"
LEFT JOIN "InjuryHurt" ON "InjuryHurt"."SingleInjuryId" = "InjurySeverstal"."InjuryId" -- для единичного травматизма
LEFT join "InjuryHurtSeverstal" on "InjuryHurtSeverstal"."InjuryHurtId"="InjuryHurt"."Id"
LEFT JOIN "Departments" AS "DeptResp2" ON "InjuryHurtSeverstal"."InternalWorkPlaceId" = "DeptResp2"."Id"
left join "ImportDepartments" as "importd"  on "DeptResp2"."Id"::integer="importd"."DepartmentId"::integer -- цех OBJID цехов	
left join "ContractorCulprits" on "ContractorCulprits"."InjurySeverstalId"="InjurySeverstal"."Id"
left join "ExternalOrganizations" on "ExternalOrganizations"."Id"="ContractorCulprits"."ContractorId"

left join "InjurySeverstal_InjuryClasses" on "InjurySeverstal"."Id" = "InjurySeverstal_InjuryClasses"."InjurySeverstalId"
left join "InjuryClasses" on "InjurySeverstal_InjuryClasses"."InjuryClassId" = "InjuryClasses"."Id"

/*_____- еще нужно связать название организации через идентификатор работника ____*/
left join "Employees" as "E0" 
	on "InjuryHurt"."ExternalEmployeeId"="E0"."Id" and "E0"."IsActual" IN (true)

/*_____ название организации через идентификатор работника ____*/
left join "ExternalOrganizations" as "ExOrg_WN" -- Подрядная допустившего несоответствие
	on "E0"."ExternalOrganizationId"="ExOrg_WN"."Id" and "ExOrg_WN"."IsActual" IN (true)	
	
where 

--"InjurySeverstal"."InjuryId" in (4420) and --тест на конкртеной карте происшествия 
	 ("InjuryHurt"."IsActual" is null or "InjuryHurt"."IsActual" in (true))
	and "Injurys"."IsActual" in (true)
and "InjurySeverstal_InjuryClasses"."IsActual" in (true)
			
),

/*___________________ группировка для вычисления одного иденификатора тип0 _____________________________________*/
"Ответственность0"  as
(
select 
	"InjurySeverstalResponsibleDepartments"."InjurySeverstalId" --не идентификатор карты происшествия
	,"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" as "TIP_0" --тип (0 – травматизм (подрядчики), 1 – виновники (собств. персонал), 2 – виновники (подрядчики))
	,"InjurySeverstalResponsibleDepartments"."DepartmentId" as "DepartmentId_0" -- идентификатор структуры
	,"DeptResp"."DepartmentName" AS "ResponsibleDepartmentName_0"  --берем только для подрядчиков
	,"importd"."ExternalId" AS "OBJID_ЦЕХ_0"  
	,"InjurySeverstalResponsibleDepartments"."IsActual"

		from "InjurySeverstal"

LEFT JOIN "InjurySeverstalResponsibleDepartments" ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId"
 and (("InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null )
	and	"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" in (0)
	)

LEFT JOIN "Departments" AS "DeptResp" ON "InjurySeverstalResponsibleDepartments"."DepartmentId" = "DeptResp"."Id"
left join "ImportDepartments" as "importd"  on "DeptResp"."Id"::integer="importd"."DepartmentId"::integer -- цех OBJID цехов	
where "InjurySeverstalResponsibleDepartments"."InjurySeverstalId" is not null
--and "InjurySeverstal"."InjuryId" in (4474)  --тест на конкртеной карте происшествия 

),

/*___________________ группировка для вычисления одного иденификатора тип1 _____________________________________*/
"Ответственность1"  as
(
select 
	"InjurySeverstalResponsibleDepartments"."InjurySeverstalId" --не идентификатор карты происшествия
	,"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" as "TIP_1" --тип (0 – травматизм (подрядчики), 1 – виновники (собств. персонал), 2 – виновники (подрядчики))
	,"InjurySeverstalResponsibleDepartments"."DepartmentId" as "DepartmentId_1" -- идентификатор структуры
	,"DeptResp"."DepartmentName" AS "ResponsibleDepartmentName_1"  --берем только для подрядчиков
	,"importd"."ExternalId" AS "OBJID_ЦЕХ_1" 
--	,"InjurySeverstalResponsibleDepartments".*
from "InjurySeverstal"

LEFT JOIN "InjurySeverstalResponsibleDepartments" ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId"
 and (("InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null )
	and	"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" in (1))

LEFT JOIN "Departments" AS "DeptResp" ON "InjurySeverstalResponsibleDepartments"."DepartmentId" = "DeptResp"."Id"
left join "ImportDepartments" as "importd"  on "DeptResp"."Id"::integer="importd"."DepartmentId"::integer -- цех OBJID цехов	
where "InjurySeverstalResponsibleDepartments"."InjurySeverstalId" is not null
--and "InjurySeverstal"."InjuryId" in (4531)  --тест на конкртеной карте происшествия 
),

/*___________________ группировка для вычисления одного иденификатора тип2 _____________________________________*/
"Ответственность2"  as
(
select 
	"InjurySeverstalResponsibleDepartments"."InjurySeverstalId" --не идентификатор карты происшествия
	,"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" as "TIP_2" --тип (0 – травматизм (подрядчики), 1 – виновники (собств. персонал), 2 – виновники (подрядчики))
	,"InjurySeverstalResponsibleDepartments"."DepartmentId" as "DepartmentId_2" -- идентификатор структуры
	,"DeptResp"."DepartmentName" AS "ResponsibleDepartmentName_2"  --берем только для подрядчиков
	,"importd"."ExternalId" AS "OBJID_ЦЕХ_2" 
--	,"InjurySeverstalResponsibleDepartments".*
from "InjurySeverstal"

LEFT JOIN "InjurySeverstalResponsibleDepartments" ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId"
 and (("InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null )
	and	"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" in (2))

LEFT JOIN "Departments" AS "DeptResp" 
	ON "InjurySeverstalResponsibleDepartments"."DepartmentId" = "DeptResp"."Id"

LEFT JOIN "ImportDepartments" as "importd"  
	on "DeptResp"."Id"::integer="importd"."DepartmentId"::integer -- цех OBJID цехов
	
where "InjurySeverstalResponsibleDepartments"."InjurySeverstalId" is not null
	and "InjurySeverstal"."InjuryId" not in (4501, 4525, 4515, 4511, 4415, 4545, 4509, 4437, 4433, 4429, 4221, 4192, 4110, 188, 252, 3036, 3050, 3057, 3092,
3128, 3183, 3199, 3204, 321, 3240, 3268, 3390, 3391, 3459, 3464, 3535, 3576, 3630, 3743, 3755, 3773, 3870, 3930, 3946, 3950, 3954, 3981)  -- убираю сам эту карту, там нет виновников подрядчиков - ошибка КОТов
--and "InjurySeverstal"."InjuryId" in (4501)  --тест на конкртеной карте происшествия 
),

/*___________________ сбор в одну строчку раздела Ответственность (внутреннее расследование)_____________________________________*/	
"OTV" as (
select 
	"Event"."InjuryId" as "EventID" -- идентификатор карты происшествия
/*____ Если подрядная организация не пусто, то всегда Подрядчики  (InjuryKindName)
	(но далее будет еще один запрос для ситуации, когда Порядчики есть, но ответственные Собственный персонал,
	тогда Персонал будет Собственный и Подразделение равно Подразделению виновника)____________________________________*/	
	,case 
		when "Event"."Подрядная организация" is not null 
	then 'Подрядчик'
		else 	"Event"."InjuryKindName"
	end as "InjuryKindName"
	,'https://kot.severstal.com/injuries/injuries-severstal/'||"Event"."InjuryId" as "LinkCard"
	,"Event"."ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ"  --берем только для собственного для карты с одним пострадавшим
	,"Event"."ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"	  --берем только для собственного для карты с одним пострадавшим
	,"Event"."OBJID_ВНУТР_ПОСТРАДАВШИЙ"	  --берем только для собственного для карты с одним пострадавшим
	,"Event"."CustomExternalWorkPlace"
	,"Event"."Подрядная организация"
	,"Event". "ContractorId"
	,"Event"."InjuryDate"
	,"Event"."Актуальность пострадавшего"
	,"Event"."Область"
	,"Event"."Свявзано с производством"
--	,"Ответственность0"."TIP_0" --тип (0 – травматизм (подрядчики), 1 – виновники (собств. персонал), 2 – виновники (подрядчики))
	,"Ответственность0"."OBJID_ЦЕХ_0"  -- идентификатор структуры
	,"Ответственность0"."ResponsibleDepartmentName_0"

/*______________ Вставляю условия для конкртеных происшествий. там отмечено, что есть трвма подрядчика, но должно быть только одно. (ошибка в данных кота) ____________________________*/	
	,case 
		when "Event"."InjuryId" in (4474, 4531, 4501) -- убираю конкретные порисшествия
	then null
		else "Ответственность0"."DepartmentId_0" 
	end as "DepartmentId_0" 
	--,"Ответственность1"."TIP_1" --тип (0 – травматизм (подрядчики), 1 – виновники (собств. персонал), 2 – виновники (подрядчики))
	,"Ответственность1"."OBJID_ЦЕХ_1" -- идентификатор структуры
	,"Ответственность1"."ResponsibleDepartmentName_1"
	,"Ответственность1"."DepartmentId_1" 
	--,"Ответственность2"."TIP_2" --тип (0 – травматизм (подрядчики), 1 – виновники (собств. персонал), 2 – виновники (подрядчики))
	,"Ответственность2"."OBJID_ЦЕХ_2" -- идентификатор структуры
	,"Ответственность2"."ResponsibleDepartmentName_2"
	,"Ответственность2"."DepartmentId_2" 
	,case
		when "Ответственность1"."DepartmentId_1" is not null
	then 'Собств.'
		when "Ответственность2"."DepartmentId_2" is not null
	then 'Подрядчик'
		else 'Не определен'
	end as "Виновник"
from "Event" 
/*___________________ связь сам с собой по типу 0_____________________________________*/	
left join "Ответственность0" on "Ответственность0"."InjurySeverstalId"="Event"."InjurySeverstalId"

/*___________________ связь сам с собой по типу 1_____________________________________*/
left join "Ответственность1"  on "Ответственность1"."InjurySeverstalId"="Event"."InjurySeverstalId"

/*___________________ связь сам с собой по типу 2_____________________________________*/
left join "Ответственность2"  on "Ответственность2"."InjurySeverstalId"="Event"."InjurySeverstalId"
)

,

"Travm" as (
select 
"Injurys"."Id" as "CardID"
,"EmployeeFio"
,"InternalEmployeeId"
,"PersonalNumber"
,"ThirdPersonFio"
,case 
	when "ThirdPersonFio" is not null 
then "ThirdPersonFio"
	when "EmployeeFio" is not null and "PersonalNumber" is null
then "EmployeeFio"
	else "EmployeeFio"||'('||"PersonalNumber"||')'
end as "Пострадавший"
,case 
	when "PersonalNumber" is null
then 1
	else 0
end as "Пострадавший подрядчик"
,case 
	when "PersonalNumber" is null
then 'Подрядчик'
	else 'Собств.'
end as "Пострадавший Подрядчик/Собств."

from public."InjuryHurt"  as "TRAVM" 

left join public."Employees" as "E1" on "TRAVM"."InternalEmployeeId"="E1"."Id" -- травма
left join public."Injurys" on "TRAVM"."SingleInjuryId"="Injurys"."Id" or "TRAVM"."SingleInjuryId"="Injurys"."Id" -- реестр или групповое или единичное
left join public."InjuryHurtSeverstal" on "TRAVM"."SingleInjuryId"="InjuryHurtSeverstal"."Id" 

where 
("EmployeeFio" is not null or "ThirdPersonFio"is not null) 
and ("TRAVM"."IsActual" is null or "TRAVM"."IsActual" in (true))
)
,



/*___________________ итоговое определение ответственности _____________________________________*/		         

"OTV2" as (
select 
	"OTV"."EventID"
	,"OTV"."InjuryKindName"
	,"OTV"."LinkCard"
	,"OTV"."Подрядная организация"
	,"OTV"."Область"
	,"OTV"."Актуальность пострадавшего"
	--,"OTV"."ResponsibleDepartmentName"
	,"ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ"
	,"ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"	
	,"OBJID_ВНУТР_ПОСТРАДАВШИЙ"
	,"OTV"."Свявзано с производством"
	,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ" --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then null --пусто
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "ResponsibleDepartmentName_1" --тянем, как есть в виновнике	
		else null end as "Цех/участок"
	,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "OBJID_ВНУТР_ПОСТРАДАВШИЙ" --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then null --пусто
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "OBJID_ЦЕХ_1"	 --тянем, как есть в виновнике	
		else null end as "Цех/участок_OBJID"		
	,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ" --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then "OTV"."Подрядная организация" --название организации, как есть
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "ResponsibleDepartmentName_1" --тянем, как есть в виновнике	
		else null end as "Подразделение"
	,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "OBJID_ВНУТР_ПОСТРАДАВШИЙ"	 --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then null --пусто
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "OBJID_ЦЕХ_1"	 --тянем, как есть в виновнике	
		else null end as "Подразделение_OBJID"		

,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ" --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then "ResponsibleDepartmentName_0" --название цеха, как есть
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "ResponsibleDepartmentName_1" --тянем, как есть в виновнике	
		else "ResponsibleDepartmentName_2" end as "Ответственный цех/участок"		
,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "OBJID_ВНУТР_ПОСТРАДАВШИЙ"	 --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then "OBJID_ЦЕХ_0" --название цеха, как есть
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "OBJID_ЦЕХ_1" --тянем, как есть в виновнике	
		else "OBJID_ЦЕХ_2" end as "Ответственный цех/участок_OBJID"		
				
,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "ЦЕХ_ВНУТРЕННЙ_ПОСТРАДАВШИЙ" --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then "ResponsibleDepartmentName_0" --название цеха, как есть
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "ResponsibleDepartmentName_1" --тянем, как есть в виновнике	
		else "ResponsibleDepartmentName_2" end as "Ответственное подразделение"		
,case 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Собств.') --есть травмированный и он собственный
			then "OBJID_ВНУТР_ПОСТРАДАВШИЙ" --виновник собственный персонал, как есть 
		when "Travm"."CardID" is not null and "InjuryKindName" in ('Подрядчик') --есть травмированный и он подрядчик (без учета 3-х лиц)
			then "OBJID_ЦЕХ_0" --название цеха, как есть
		when "Travm"."CardID" is null and "ResponsibleDepartmentName_1" is not null -- нет трам, виновник собственный
			then "OBJID_ЦЕХ_1" --тянем, как есть в виновнике	
		else "OBJID_ЦЕХ_2" end as "Ответственное подразделение_OBJID"		
		,"OTV"."InjuryDate"	as "Дата"				
,case 
		when "OTV"."OBJID_ЦЕХ_1" is not null --ответственный собственный не пусто
			then "OTV"."OBJID_ЦЕХ_1" --виновник собственный персонал
		else 
			"OBJID_ВНУТР_ПОСТРАДАВШИЙ"   --если нет ответственных, то берем из места работы травмировавшегося
		end as "РЕЙТИНГ"	
		,"OTV"."DepartmentId_0"
		
		, case 
			when "OTV"."DepartmentId_0" is null and "OTV"."DepartmentId_1"is null and "OTV"."DepartmentId_2" is null -- если все пусто, то берем цех пострадавшего
		then "OTV"."ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"  -- тогда  цех пострадавшего
			when "OTV"."DepartmentId_0" is not null -- виновник подрядчик
		then "OTV"."DepartmentId_0"  -- тогда подрядчик
			when "OTV"."DepartmentId_1" is null -- виновник не собственный персонал
		then "OTV"."DepartmentId_2"  -- тогда подрядчик

			else  "OTV"."DepartmentId_1" 
		end as "DepartmentId_1" -- это для реестра и столбца цех, ответственный (не для рейтинга)
		,"OTV"."DepartmentId_2"
		,"Travm"."Пострадавший"
		,"Travm"."Пострадавший подрядчик"
		,"Travm"."Пострадавший Подрядчик/Собств."
		,"OTV"."Виновник"
		
from "OTV"
/*______________ определяем наличие травмировавшегося, любого, хоть 3 лица, хоть персонал есть_______________________*/		 
left join "Travm" on "Travm"."CardID"="OTV"."EventID"


)
--select * from "OTV2"
,


"КАРТА" as (
select distinct
    --"Events"."Id" AS "EventID"  --идентификатор события
    "Injurys"."Id" AS "CardID" --идентификатор карты
     ,'https://kot.severstal.com/injuries/events/event/'||"Events"."Id" as "LinkEvent"
	,"Events"."IsActual"
	,"Events"."Theme" AS "Theme"
    ,"Events"."Description" AS "Description"
    ,"Injurys"."PlaceOfIncidentDescription" AS "PlaceOfIncidentDescription"
    ,"Risk_Dangers"."Name" AS "Risk"
    ,"InjuryLevels"."Name" AS "InjurysName"
    ,"Locations"."Name" AS "LocationName"
    , "BusinessUnits"."Name" as "BusinessName"
    , "InjuryAftermathPeople"."Aftermath" as "Травматизм"
        , case 
        when "class"."Name" in ('1.1. Несчастный случай со смертельным исходом', '1.1. Острое профессиональное заболевание (отравление) со смертельным исходом'
	,'1.2. Происшествия в электроустановках, которые привели к смертельному, групповому (хотя бы один работник получил тяжелую травму) или тяжелому несчастному случаю (электротравма)'
	,'Несчастный случай групповой (хотя бы один из работников получил тяжелую или смертельную травму)')
        then 1
        else 0
        end as "Смертельный"
	,"InjurySeverstal"."AftermathPeopleId"
   , case
       when "class"."Name" in ('1.1. Несчастный случай со смертельным исходом', '1.1. Острое профессиональное заболевание (отравление) со смертельным исходом'
	,'1.2. Происшествия в электроустановках, которые привели к смертельному, групповому (хотя бы один работник получил тяжелую травму) или тяжелому несчастному случаю (электротравма)'
	,'Несчастный случай групповой (хотя бы один из работников получил тяжелую или смертельную травму)')
        then 'Нет'
       WHEN "InjurySeverstal"."AftermathPeopleId" IN (5, 4) THEN 'ПСП'
        ELSE 'Нет'
    END AS "IsPotentiallyFatal"
	,"class"."Name"
	,CASE 
	when "class"."Name" in ('1.1. Несчастный случай со смертельным исходом', '1.1. Острое профессиональное заболевание (отравление) со смертельным исходом'
	,'1.2. Происшествия в электроустановках, которые привели к смертельному, групповому (хотя бы один работник получил тяжелую травму) или тяжелому несчастному случаю (электротравма)'
	,'Несчастный случай групповой (хотя бы один из работников получил тяжелую или смертельную травму)') then -100 
	when ("class"."Name" not like '%легк%' and "class"."Name" not like '%тяж%') and "InjurySeverstal"."AftermathPeopleId" IN (5, 4) then -30
	else 0 end as "Penalty"
	,"InjurySeverstal"."ApplicationDesc" as "Описание приложения к справке"
	,"InjurySeverstal"."FactProbabilityPeopleId"

FROM
    "Events"
LEFT JOIN "Injurys" ON "Events"."Id" = "Injurys"."EventId"
LEFT JOIN "Departments" ON "Injurys"."PlaceOfIncidentId" = "Departments"."Id"
LEFT JOIN "InjuryLevels" ON "Injurys"."InjuryLevelId" = "InjuryLevels"."Id"
LEFT JOIN "InjurySections" ON "InjuryLevels"."Id" = "InjurySections"."LevelId"
LEFT JOIN "InjurySeverstal" ON "Injurys"."Id" = "InjurySeverstal"."InjuryId"
left join "InjuryAftermathPeople" on "InjurySeverstal"."AftermathPeopleId" = "InjuryAftermathPeople"."Id"
left join "BusinessUnits" on "Events"."BusinessUnitId" = "BusinessUnits"."Id"
LEFT JOIN "Risk_Dangers" ON "InjurySeverstal"."DangerId" = "Risk_Dangers"."Id"
LEFT JOIN "Locations" ON "BusinessUnits"."LocationId" = "Locations"."Id"
LEFT JOIN "InjuryKinds" ON "Injurys"."InjuryKindId" = "InjuryKinds"."Id"
LEFT JOIN "InjurySeverstal_InjurySections" ON "InjurySeverstal"."Id" = "InjurySeverstal_InjurySections"."InjurySeverstalId" 
left join "InjurySections" as "class" on "InjurySeverstal_InjurySections"."InjurySectionId" = "class"."Id" 
left join "InjuryHurt" as "TRAVM" on "TRAVM"."SingleInjuryId"="Injurys"."Id" -- реестр 

/*______далле ограничиваем входны данные______________*/	
where

/*______берем события происшествия, их идентификатор 2______________*/	 
    "Events"."EventTypeId" = 2
    
/*______берем актуальность самого происшествия______________*/	   
    and "Events"."IsActual" IN (true) 
    
    /*______убираем не актуальную классификацию______________*/ 	 
    and "InjurySeverstal_InjurySections"."IsActual" in (true) 	 
 
   
    ),
 
"REESTR" as (
select distinct
    "OTV2"."EventID"
    ,"OTV2"."Свявзано с производством"
    ,"OTV2"."Виновник"
    ,"OTV2"."InjuryKindName"
	,"OTV2"."LinkCard"
	,"OTV2"."Подрядная организация"
	,"OTV2"."Актуальность пострадавшего"
	,"OTV2"."Пострадавший"
	,"OTV2"."Пострадавший подрядчик"
	,"OTV2"."Пострадавший Подрядчик/Собств."
	,case 
		when "OTV2"."Подрядная организация" is not null --если есть травмированный подрядчик
	then null --тогда цеех пустой
		when "REKURS"."WORKS_ID" is null --если нет уровня цеха, то выводить название, которое указано
	then "REKURS"."NAME" --как указано в реестре
		else "REKURS"."NAME" 
	end as "Цех/участок"
	,"OTV2"."Цех/участок_OBJID"
	,"OTV2"."ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"
	,case 
		--when "OTV2"."InjuryKindName" in ('Подрядчик') --ранее было так, убрал по наличию подорядчиков в принципе
		when "OTV2"."Подрядная организация" is not null
	then "OTV2"."Подрядная организация" 
		else "REKURS"."MANUFACTURE" 
	end as "Подразделение"
	,"REKURS"."WORKS_OBJID" as "Подразделение_OBJID"
	,case 
		when "REKURS"."WORKS_ID" is null --если нет уровня цеха, то выводить название, которое указано
	then "REKURS"."NAME" --как указано в реестре
		else "REKURS"."NAME" 
	 end as "Ответственный цех/участок" --если нет травматизма, то берем из ответственного цеха
	,"OTV2"."Ответственный цех/участок_OBJID"
	,"REKURS"."MANUFACTURE"  as "Ответственное подразделение"
	,"REKURS"."WORKS_OBJID"  as "Ответственное подразделение_OBJID"
	 ,"OTV2"."Дата"
	,"OTV2"."Область"      	
    ,"КАРТА".*
    ,"STREAM_SIGN"."YCHA_GR01" AS "UpDownStream"
         ,"OTV2"."РЕЙТИНГ"::integer	
         
         ,"OTV2"."DepartmentId_0"
		,"OTV2"."DepartmentId_1"
		,"OTV2"."DepartmentId_2"
		
    from "OTV2" 
 left join "КАРТА" on "OTV2"."EventID"="КАРТА"."CardID" -- реестр   
LEFT JOIN "STREAM_SIGN" ON "OTV2"."Ответственный цех/участок_OBJID"::integer = "STREAM_SIGN"."Departmentid"::integer

left join "REKURS" on "REKURS"."ID_KOT"="OTV2"."DepartmentId_1"

/*______убираем не актуальных постродавших в событиях где они есть______________*/
where 
"OTV2"."Актуальность пострадавшего" is null or  "OTV2"."Актуальность пострадавшего" in (true)
),

"UNION_REESTR" as (
select  
"EventID"
,"Свявзано с производством"
,"Виновник"
,'Собств.' as "InjuryKindName" --согласно постановке меняем на собственный персонал
,"LinkCard"
,"Подрядная организация"
,"Актуальность пострадавшего"
,"Пострадавший"
,"Пострадавший подрядчик"
,"Пострадавший Подрядчик/Собств."
,"Ответственный цех/участок" as  "Цех/участок" --согласно постановке меняем на ответсвенный цех участок
,"Ответственный цех/участок_OBJID" as "Цех/участок_OBJID"
,"ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"
,"Ответственное подразделение" as "Подразделение"--согласно постановке меняем на ответсвенныое подразделение 
,"Ответственное подразделение_OBJID" as "Подразделение_OBJID"
,"Ответственный цех/участок"
,"Ответственный цех/участок_OBJID"
,"Ответственное подразделение"
,"Ответственное подразделение_OBJID"
,"Дата"
,"Область"
,"CardID"
,"LinkEvent"
,"IsActual"
,"Theme"
,"Description"
,"PlaceOfIncidentDescription"
,"Risk"
,"InjurysName"
,"LocationName"
,"BusinessName"
,"Травматизм"
,"Смертельный"
,"AftermathPeopleId"
,"IsPotentiallyFatal"
,"Name"
,"Penalty"
,"Описание приложения к справке"
,"FactProbabilityPeopleId"
,"UpDownStream"
,"РЕЙТИНГ"
,"DepartmentId_0"
,"DepartmentId_1"
,"DepartmentId_2"

from "REESTR"
/*______ для юниона событий с подрядчиками, без травм и виновниками собственным персоналом 
          здесь будет изменен столбец "InjuryKindName" на собственный и  "Подразделение" и "Цех/участок" взять из блока Виновник (собственный персонал)________*/
where 
"Пострадавший подрядчик" is null --берем только без пострадавших
and "Виновник" in ('Собств.') --есть виновник собственный персонал
and "Подрядная организация" is not null--есть подрядчики*/

union 

select 
"EventID"
,"Свявзано с производством"
,"Виновник"
,"InjuryKindName" --согласно постановке меняем на собственный персонал
,"LinkCard"
,"Подрядная организация"
,"Актуальность пострадавшего"
,"Пострадавший"
,"Пострадавший подрядчик"
,"Пострадавший Подрядчик/Собств."
,"Цех/участок" --согласно постановке меняем на ответсвенный цех участок
,"Цех/участок_OBJID"
,"ID_ЦЕХ_ВНУТР_ПОСТРАДАВШИЙ"
,"Подразделение"--согласно постановке меняем на ответсвенныое подразделение 
,"Подразделение_OBJID"
,"Ответственный цех/участок"
,"Ответственный цех/участок_OBJID"
,"Ответственное подразделение"
,"Ответственное подразделение_OBJID"
,"Дата"
,"Область"
,"CardID"
,"LinkEvent"
,"IsActual"
,"Theme"
,"Description"
,"PlaceOfIncidentDescription"
,"Risk"
,"InjurysName"
,"LocationName"
,"BusinessName"
,"Травматизм"
,"Смертельный"
,"AftermathPeopleId"
,"IsPotentiallyFatal"
,"Name"
,"Penalty"
,"Описание приложения к справке"
,"FactProbabilityPeopleId"
,"UpDownStream"
,"РЕЙТИНГ"
,"DepartmentId_0"
,"DepartmentId_1"
,"DepartmentId_2"

from "REESTR"
),

"REITING" as (
select 
	"UNION_REESTR".* 
	,case 
     when "Penalty"=-100 
     	then (date_trunc('month', "Дата")::date+interval '11 month')::date
     else date_trunc('month', "Дата")::date 
     	end as "Date_End"
     
from "UNION_REESTR"),

/*___________________ генерация виртуального календаря_____________________________________*/		
"CALENDAR" as (SELECT * FROM generate_series('2025-01-01',
                               now()::date, '1 month') as r
                               ),
                               
"REITING_2" as (select distinct 
	"EventID"
	,"LinkCard"
	,"Name"
	,"Penalty"
	,"Дата"
	,"РЕЙТИНГ"
	,date_trunc('month', "Дата")::date as "Date_Start"
	, date_trunc('month', "Date_End")::date as "Date_End"
	, "Смертельный"

from "REITING"
where
"Penalty"<>0 and "РЕЙТИНГ" is not null
),


"ITOG_REITING" as (
select 
	"EventID"
 	 ,"LinkCard"
	,"Name"
	,"Penalty"
	,"Дата"
     ,"РЕЙТИНГ"::TEXT||EXTRACT(year FROM "r"::date)||EXTRACT(Month FROM "r"::date) as "STRUCT_YEAR_MONTH"
       ,case 
			when "РЕЙТИНГ"::TEXT||EXTRACT(year FROM "r"::date)||EXTRACT(Month FROM "r"::date)="РЕЙТИНГ"::TEXT||EXTRACT(year FROM "Дата"::date)||EXTRACT(Month FROM "Дата"::date)
        then 1
      		 else 0
       end as "STRUCT_YEAR_MONTH_FAKT"   
	,"Date_Start"
	, "Date_End"
	, "Смертельный"
,'PSP' as "IST"
from "REITING_2", "CALENDAR" 
/*___________________ объединени двух таблиц_____________________________________*/		          
where "CALENDAR"."r" between "Date_Start" and "Date_End"
and "Дата">=to_date('01012025','ddmmyyyy')
order by "Дата"
),

/*___________________ генерация виртуального календаря по одной на каждую неделю_____________________________________*/	
"CALENDAR_monts" as (
	SELECT 	distinct 
	r::date as "DATE"
		,EXTRACT(month from r) as "№_месяца"

	FROM generate_series('2025-01-01',now()::date, '1 day') as r
		
		),
		
/*___________________ ищем травмы с периодом нетрудоспособности _____________________________________*/	
"TRAVM_RATING" as (
select 
"Injurys"."Id" as "CardID"
,"InjuryDate"::date
,"TRAVM"."EmployeeFio"
,"TRAVM"."InternalEmployeeId"
,"E1"."PersonalNumber"
,'https://kot.severstal.com/injuries/injuries-severstal/'||"Injurys"."Id" as link
,"ThirdPersonFio"
,"InjuryHurtSeverstal"."SickDaysBegin"::date as "DATE_START"
,case 
	when "TRAVM"."SickFinishDate" is null
then now()::date
	else "TRAVM"."SickFinishDate"::date 
end as "DATE_END"

,"REKURS"."WORKS_OBJID" as "WORKS_OBJID"
,"InjurySeverstalResponsibleDepartments"."DepartmentId"
,"REKURS"."ID_KOT"

from "InjuryHurt"  as "TRAVM" 


left join "Employees" as "E1" 
	on "TRAVM"."InternalEmployeeId"="E1"."Id"  -- фио травмировавшегося в единой базе кота с учетом уволенных
left join "Injurys" 
	on "TRAVM"."SingleInjuryId"="Injurys"."Id" or "TRAVM"."SingleInjuryId"="Injurys"."Id" -- реестр или групповое или единичное

left join "InjuryHurtSeverstal" 
	on "TRAVM"."Id"="InjuryHurtSeverstal"."InjuryHurtId" 

LEFT JOIN "InjurySeverstal"  
	ON "TRAVM"."SingleInjuryId" = "InjurySeverstal"."InjuryId" -- для единичного травматизма

/*_____ связываем с таблицей "Ответствееность (Внутреннее расследование)" Виновник (собственный персонал)   ________*/	
LEFT JOIN "InjurySeverstalResponsibleDepartments" 
	ON "InjurySeverstal"."Id" = "InjurySeverstalResponsibleDepartments"."InjurySeverstalId"
 and (("InjurySeverstalResponsibleDepartments"."IsActual" IN (true) or "InjurySeverstalResponsibleDepartments"."IsActual" is null )
	and	"InjurySeverstalResponsibleDepartments"."ResponsibleDepartmentType" in (1))	
	
	/*___________________ связываем с рекурсией для получения цеха виновника _____________________________________*/		
left join	"REKURS" 
	on "REKURS"."ID_KOT"="InjurySeverstalResponsibleDepartments"."DepartmentId"
	
	
where 
("TRAVM"."EmployeeFio" is not null or "TRAVM"."ThirdPersonFio"is not null) 
and ("TRAVM"."IsActual" is null or "TRAVM"."IsActual" in (true))
--and "Injurys"."Id" in (4707) --тест на карте

),



"ITOG_TRAVM" as (
select "TRAVM_RATING"."CardID" as "EventID"
,"TRAVM_RATING"."link" as "LinkCard"
,'Допущен травматизм с потерей трудоспособности' as "Name"

,"TRAVM_RATING"."EmployeeFio"
,"TRAVM_RATING"."InternalEmployeeId"
,"TRAVM_RATING"."PersonalNumber"

,"TRAVM_RATING"."ThirdPersonFio"
,"№_месяца"
,count("DATE")*-3 as "Penalty"
,"TRAVM_RATING"."InjuryDate" as "Дата"
,count("DATE") as "Дней больничного"
,"WORKS_OBJID"
,"WORKS_OBJID"::text||EXTRACT(year FROM max("DATE")::date)||EXTRACT(Month FROM max("DATE")::date) as "STRUCT_YEAR_MONTH"

,case 
			when "WORKS_OBJID"::TEXT||EXTRACT(year FROM "TRAVM_RATING"."InjuryDate"::date)||EXTRACT(Month FROM "TRAVM_RATING"."InjuryDate"::date)
="WORKS_OBJID"::TEXT||EXTRACT(year FROM max("DATE")::date)||EXTRACT(Month FROM max("DATE")::date)
        then 1
      		 else 0
       end as "STRUCT_YEAR_MONTH_FAKT"
,"TRAVM_RATING"."DATE_START" as "Date_Start"
,"TRAVM_RATING"."DATE_END" as "Date_End"
,0 as "Смертельный"
,'TRAVM' as "IST"
from "TRAVM_RATING","CALENDAR_monts"

/*___________________ объединение с каледарем_____________________________________*/	
where "CALENDAR_monts"."DATE" between "TRAVM_RATING"."DATE_START" and "TRAVM_RATING"."DATE_END"

group by "TRAVM_RATING"."CardID"
,"TRAVM_RATING"."InjuryDate"
,"TRAVM_RATING"."EmployeeFio"
,"TRAVM_RATING"."InternalEmployeeId"
,"TRAVM_RATING"."PersonalNumber"
,"TRAVM_RATING"."link"
,"TRAVM_RATING"."ThirdPersonFio"
,"TRAVM_RATING"."DATE_START"
,"TRAVM_RATING"."DATE_END"
,"№_месяца"
,"WORKS_OBJID"
)

select * from "ITOG_TRAVM"
--union
--select * from "ITOG_REITING"
