with EventEndingDateChangeHistory as (SELECT DISTINCT 
 "EventId"
,"Id" 
,count("Id") q
FROM public."EventEndingDateChangeHistory"
WHERE "EndingDateOld"<"EndingDate"
group by "EventId","Id")

, EventEnd as (
SELECT 
DISTINCT 
 ve."EventId" "Id_несоответствие"
,vece."EventId" "Id_мероприятие"
,case 
	when count(vece."EventId") = count(e."ExecutionDate")
	then max(e."ExecutionDate")
	when e2."Description" is null and e2."Theme" is null and e2."ExecutionDate" is null and e."ExecutionDate" is not null 
	then e."ExecutionDate"
	else null
end "Дата устранения отк-я КББ (факт)"
FROM public."ViolationEvents" ve 
left join public."Events" e on ve."EventId"=e."Id" and e."IsActual"=true
left join public."Violation_EliminationCausesEvent" vece on ve."Id"=vece."ViolationEventId" and vece."IsActual"=true
left join public."Events" e2 on vece."EventId"=e2."Id" and e2."IsActual"=true
group by 
 ve."EventId"
,vece."EventId"
,e2."Description"
,e2."Theme"
,e2."ExecutionDate"
,e."ExecutionDate")

SELECT 
DISTINCT 
 s."Id"  -- Id смены
,s."ShiftLogId" --Id журнала
,s."StartDateTime"  --Время приёма смены
,s."EndDateTime"  --Время сдачи смены
,case 
	when se."WatchingTime" is not null  then se."WatchingTime" else s."StartDateTime" end "WatchingTime"
,case 
	when se."WatchingTime" is not null and se."WatchingTime"::time<sl."TimeDay"-interval '1' hour --ночная смена отн-ся к пред.дню
	then se."WatchingTime"::date-1 
	when se."WatchingTime" is not null and se."WatchingTime"::time>sl."TimeDay"-interval '1' hour 
	then se."WatchingTime"::date
	when se."WatchingTime" is not null and sl."TimeDay" is null 
	then se."WatchingTime"::date
	when s."StartDateTime"::time<sl."TimeDay"-interval '1' hour --ночная смена отн-ся к пред.дню
	then s."StartDateTime"::date-1
	else s."StartDateTime"::date 
	end "Дата"
,case 
	when e4."ExternalOrganizationId" is null 
	then concat(e4."LastName",' ',substring(e4."FirstName" from 1 for 1),'.',substring(e4."SecondName" from 1 for 1),'. (',cast(replace(e4."PersonalNumber",':','') as numeric),')') 
	--else concat(e4."LastName",' ',substring(e4."FirstName" from 1 for 1),'.',substring(e4."SecondName" from 1 for 1),'. (ПО)') --подрядчики
	else concat(e4."LastName",' ',e4."FirstName",' ',e4."SecondName",' (ПО)') --подрядчики, полное ФИО
	end "FIO (TN)" --Сменщик
,s."CrewId" --Бригада
,s."ShiftNumber"  --Номер смены
,id."ExternalId"::numeric  REVISIONDEPARTMENTID
,se."ShiftLogEquipmentId"
,rd."Id" id_deadly_risk
,case 
	when sle."CustomEquipment" is not null then sle."CustomEquipment" else e5."Name" end "КББ"
,se."Description" "Кoмментарии"
,sewr."WorkerReactionId"
,wr."Name" "Поведенческие барьеры"
,case 
	when e2."Description" is null and e2."Theme" is null and e2."ExecutionDate" is null and e."ExecutionDate" is not null then 'Без мероприятия - устранено в течение смены'
	when e2."Description" <>'' then e2."Description"	when e2."Description" =''	then e2."Theme" END "Мероприятия по устранению отк-я КББ"
,case 
	when e2."Description" is null and e2."Theme" is null and e2."ExecutionDate" is null and e."ExecutionDate" is not null then 'корр.'
  when e2."CorrectiveActions"=true then 'корр.' when e2."CorrectiveActions"=false then 'комп.'  end "Тип"
,e2."EndingDate" "Дата устранения отк-я КББ (план)"
,case 
	when e2."ExecutionDate" is null then e."ExecutionDate" else e2."ExecutionDate" end "Дата вып мероп. КББ (факт)"--"Дата устранения отк-я КББ (факт)"
,eee."Дата устранения отк-я КББ (факт)" --последняя дата выполнения мероприятия в отклонении
,case 
	when e3."Id">0 then concat(e3."LastName",' ',substring(e3."FirstName" from 1 for 1),'.',substring(e3."SecondName" from 1 for 1),'. (',cast(replace(e3."PersonalNumber",':','') as numeric),')')  END "Oтветственный ФИО"
,CONCAT('https://kot.severstal.com/audits_severstal/shift_log/', s."ShiftLogId") link_loc -- Ссылка на журнал
,case 
	when vece."EventId" is not null then CONCAT('https://kot.severstal.com/events/plannings/events/single/', vece."EventId") END link_ev -- Ссылка на мероприятие
,case 
	when ve."EventId" is not null then CONCAT('https://kot.severstal.com/revisions_severstal/violation_event/', ve."EventId") END link_viol -- Ссылка на несоответствие
,ve."EventId" "Id_несоответствие" 
,vece."EventId" "Id_мероприятие"
,ee.q "Кол-во переносов"
,eedchpc."EventProlongCauseId" 
	--,vebr."BasicRuleId"
FROM 
public."Shifts" s 
join public."Employees" e4 on s."EmployeeId"=e4."Id" 
join public."ShiftLogs" sl on s."ShiftLogId"=sl."Id" and sl."IsActual"=true
-- join public."ShiftEquipment" se on s."Id"=se."ShiftId" and se."IsOperational" = false 
join public."ShiftEquipment" se on s."Id"=se."ShiftId" and (se."IsOperational" = false or se."ViolationEventId" is not null)--по просьбе С.В. 20.05.25 --and (se."WatchingTime" >= '01.01.2025' or se."CreationDateTime" >= '01.01.2025')
join public."ShiftLogEquipment" sle  on se."ShiftLogEquipmentId"=sle."Id" 
left join public."Equipments" e5 on sle."EquipmentId"=e5."Id" 
join public."Risk_Dangers" rd on sle."RiskDangerId"=rd."Id" and rd."IsDeadlyRisk"=true 
left join public."ShiftEquipment_WorkerReactions" sewr on se."Id"=sewr."ShiftEquipmentId" 
join public."ImportDepartments" id on sl."DepartmentId"=id."DepartmentId"
left join public."WorkerReactions" wr on sewr."WorkerReactionId"=wr."Id" 
left join public."ViolationEvents" ve on se."ViolationEventId"=ve."Id"
left join public."Events" e on ve."EventId"=e."Id" and e."IsActual"=true
left join public."Violation_EliminationCausesEvent" vece on ve."Id"=vece."ViolationEventId" and vece."IsActual"=true 
left join public."Events" e2 on vece."EventId"=e2."Id" and e2."IsActual"=true
left join public."EventParticipants" ep on vece."EventId"= ep."EventId"
left join public."Employees" e3 on ep."EmployeeId"=e3."Id" 
left join EventEndingDateChangeHistory ee on vece."EventId"=ee."EventId"
left join EventEnd eee on ve."EventId"=eee."Id_несоответствие"--vece."EventId"=eee."Id_несоответствие"
left join public."EventEndingDateChangeHistory_ProlongCause" eedchpc ON eedchpc."EventEndingDateChangeHistoryId" = ee."Id" and eedchpc."EventProlongCauseId" in(9,10,11,12,13)
	--left join public."ViolationEventBasicRules" vebr on ve."Id" = vebr."ViolationEventId" and vebr."IsActual"=true
	--left join public."BasicRules" br on vebr."ViolationEventId" = br."Id" and br."IsActual"=true and br."Id" not in (39,43)