WITH recursive 

       "LV_SUBD" as (
             SELECT 
                    "Departments"."Id" 
                    ,"Departments"."BusinessUnitId"
                    ,"Departments"."ParentDepartmentId" as "ParentId"
                    ,COALESCE("DepartmentLevelId",1) as "LevelId" 
                    ,"DepartmentName" as "D_Name"
                    ,"Departments"."Id" as "ROOT_ID"
                    ,"DepartmentName" as "ROOT_NAME"
                    ,case 
                  	 	 when "Departments"."Id" in ('29970') --присваиваем признак цеха для Стальных решений вручную
                    then 4
                  		  else COALESCE("DepartmentLevelId",1) 
                    end as "ROOT_L"
                    ,"importd"."ExternalId"
                    ,"Documents"."Number"::numeric
                                               
                    FROM "Departments"
             			left join "ImportDepartments" as "importd" 
      						 on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
                    left join "Documents" 
						on "importd"."ExternalId"::numeric ="Documents"."Number"::numeric 
							and"Description" IN ('Рейтинг цеха')
								and "Documents"."IsActual" in (true)
					      						 
      						 
       union all 
             
             select 
                    "DEP"."Id" as "Id"
                    ,"DEP"."BusinessUnitId"
                    ,"DEP"."ParentDepartmentId" as "ParentId"
                    ,"DEP"."DepartmentLevelId" as "LevelId"
                    ,"DEP"."DepartmentName" as "D_Name"
                    ,"LV_SUBD"."ROOT_ID" as "ROOT_ID"
                    ,"LV_SUBD"."ROOT_NAME"  as "ROOT_NAME"
                    ,"LV_SUBD"."ROOT_L" as "ROOT_L"
                    ,"LV_SUBD"."ExternalId"
                    ,"LV_SUBD"."Number"
                           
             FROM "Departments" as "DEP"
            join "LV_SUBD"
             ON  "DEP"."ParentDepartmentId"= "LV_SUBD"."Id"

             
       ),
       
"REKURS" as (SELECT 
"D"."IsActual"
,case 
       when "D"."IsActual" = true then COALESCE("Locations"."Name",'Другие')
       else 'Неактуальная структура'
end as "DIVISION"

,"D"."BusinessUnitId"
,"BU"."Name" as "COMPANY"

,"L3"."ROOT_ID" as "MANUF_ID"
,COALESCE("L3"."ROOT_NAME",'Цеха(Ур-нь прои-ва не задан)') as "MANUFACTURE"

,"L4"."ROOT_ID" as "WORKS_ID"
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null --добавляем вывод OBJID уровня участка для ситуации, когда есть участок, но нет цеха выше
then "L5"."ExternalId"
	else "L4"."ExternalId" 
end as "WORKS_OBJID" 
,case 
	when "L5"."ExternalId" is not null and "L4"."ExternalId" is null  --добавляем вывод OBJID уровня участка дял корректной работы рейтинга (если участок в САПе присвоен)
then COALESCE("L5"."ROOT_NAME",'Уровень участка не задан')
	else COALESCE("L4"."ROOT_NAME",'Уровень цеха не задан') 
end as "WORKSHOPS"

,"L5"."ROOT_ID" as "PLOTS_ID"
,"L5"."ExternalId" as "PLOTS_OBJID"
,COALESCE("L5"."ROOT_NAME",'Отделы/службы(Ур-нь участка не задан)') as "PLOTS"

,"D"."Id" as "ID_KOT"
,"importd"."ExternalId"::numeric as "OBJID"
,"D"."DepartmentName" as "NAME"
,"DL"."Name" as "LEV"
,"Departmen_name_full"("D"."Id") as "Path_NAME"
,"D"."IsRealDepartment"
,"D"."StartDate"
,"D"."EndDate"
,"L_REITING"."ExternalId"::numeric as  "L_REITING"

FROM "Departments" as "D"

left join "BusinessUnits" as "BU" -- Предприятия
       on "D"."BusinessUnitId"="BU"."Id"
       
left join    "Locations" -- Бизнес единици
       on "BU"."LocationId"="Locations"."Id"
       
left join "DepartmentLevels" as "DL"
       on "D"."DepartmentLevelId"="DL"."Id" and "DL"."IsActual" -- Название уровней структуры
       
left join "ImportDepartments" as "importd" 
       on "D"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
       
left join "LV_SUBD" as "L3"
       on "D"."Id"= "L3"."Id" and  "L3"."ROOT_L"=3 -- Управление / Производство

left join "LV_SUBD" as "L4"
       on "D"."Id"= "L4"."Id" and  "L4"."ROOT_L"=4 --Цех / Участок
       
left join "LV_SUBD" as "L5"
       on "D"."Id"= "L5"."Id" and  "L5"."ROOT_L"=5 --Отдел / Участок

       /*для вытягивания признака цеха или участка, смотря, что выбрано*/
left join "LV_SUBD" as "L_REITING"
       on "D"."Id"= "L_REITING"."Id" 
       	and  ("L_REITING"."ROOT_L"=5  or  "L_REITING"."ROOT_L"=4)
       		and "L_REITING"."Number" is not null
      
 where "L_REITING"."ExternalId" is not null
 and "importd"."ExternalId"  is not null 
 --and "L5"."ExternalId" in ('34101') 
--and "D"."Id" in ('29970','29997','30026')
       
       ),
/*___ оценка рисков ___*/
"first" as (
select   
"Risk_Assessment"."CardNumber" as "Карта оценки"
,'https://kot.severstal.com/risk_assessment/cards/'||"Risk_Assessment"."CardNumber" as "Link_Card"
,"Events"."Theme" as "Название карты"
,"Events"."BeginDate"::date as "Дата создания"
,date_trunc('month',"Events"."BeginDate"::date) ::date as "FIRST_DAY_RR"
,"Events"."EndingDate"::date as "Дата план"
,"Events"."ExecutionDate"::date as "Дата факт"
,"EventWorkStatuses"."Name" AS "Статус"
,"Risk_Assessment"."DepartmentId" as "ИД_Подразделения_КОТ"
,"importd"."ExternalId"::numeric as "OBJID"
,"ProfessionTypes"."Name"  as "Prof"
,"E1"."LastName"||' '||
			substring("E1"."FirstName" from 1 for 1)||'. '||
				COALESCE(substring("E1"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
					COALESCE("E1"."PersonalNumber",'')||')' as "Отв.Верификация"
,"REKURS"."L_REITING"
,"EventEndingDateChangeHistory"."EndingDateOld"::DATE as "Дата окончания старая"
,"EventEndingDateChangeHistory"."SettlementDate"::DATE as "Дата корректировки"

/*переносил срок*/
,"E2"."LastName"||' '||
			substring("E2"."FirstName" from 1 for 1)||'. '||
				COALESCE(substring("E2"."SecondName" from 1 for 1)||'.','')||chr(10)||'('||
					COALESCE("E2"."PersonalNumber",'')||')' as "ФИО Переносил сроки"

from "Risk_Assessment"

	/*____ Величина на всю карту _____*/	
left join "Risk_Assessment_CalculatedFields"
on "Risk_Assessment"."Id"="Risk_Assessment_CalculatedFields"."Id" 
		/*____ Риски на всю карту _____*/	
left join "Risk_Risks"	
		on "Risk_Risks"."Id"="Risk_Assessment_CalculatedFields"."RiskId"

/*____ привязываем таблицу с событием  _____*/
left join "Events" 
	on "Risk_Assessment"."EventId"="Events"."Id" 
		and "Events"."IsActual" IN (true)
	/*для вычисления ответственного з верификацию*/	
left join "EventParticipants"
		on "Events"."Id"="EventParticipants"."EventId" 
		and "EventParticipants"."IsActual" IN (true)

	/*для вычисления ответственного з верификацию*/	
left join "Employees" as "E1"
		on "EventParticipants"."EmployeeId"="E1"."Id"
		and "E1"."IsActual" IN (true)		
		
	/*____ статус оценки _____*/
left join "EventWorkStatuses"  
	on "Events"."EventWorkStatusId"="EventWorkStatuses"."Id"

	/*____ структура _____*/
left join "Departments"
	on "Risk_Assessment"."DepartmentId"= "Departments"."Id" --and "D1"."IsActual" IN (true) -- Место оценки риска

	/*____ перекодировочная структуры _____*/	
left join "ImportDepartments" as "importd" 
	on "Departments"."Id"="importd"."DepartmentId" --and "importd"."IsActual" IN (true) -- ID из САП
		
	
left join "RiskAssessment_ProfessionTypes"
	on "RiskAssessment_ProfessionTypes"."RiskAssessmentId"="Risk_Assessment"."Id" 
		and "RiskAssessment_ProfessionTypes"."IsActual" IN (true)

	/*_ связь с профессией и ППИ___*/	
left join "ProfessionTypes"
on "RiskAssessment_ProfessionTypes"."ProfessionTypeId" ="ProfessionTypes"."Id"

left join "REKURS" 
	on "importd"."ExternalId"::numeric="REKURS"."OBJID"

/*смена даты*/		
left join "EventEndingDateChangeHistory"
	on "EventEndingDateChangeHistory"."EventId"="Events"."Id"	

/*кто менял даты*/	
left join "Users" 
	on "EventEndingDateChangeHistory"."UserId"="Users"."Id"	

left join "Employees" as "E2"
	on "E2"."Id"="Users"."EmployeeId" 
		and "E2"."IsActual" in (true)
 	
	
	where "Risk_Assessment"."IsActual" IN (true)
	--and "Risk_Dangers"."Name" is not null --не брать пустые строки
--and "Risk_Assessment"."CardNumber" in ('76') --пример на конкретной карте
--order by "Risk_Assessment"."CardNumber" desc
group by 
"Risk_Assessment"."CardNumber"
,"Events"."Theme"
,"Events"."BeginDate"
,"Events"."EndingDate"
,"Events"."ExecutionDate"
,"EventWorkStatuses"."Name"
,"Risk_Assessment"."DepartmentId"
,"importd"."ExternalId"
,"ProfessionTypes"."Name"
,"ProfessionTypes"."ProgramType"

,"E1"."LastName"
,"E1"."FirstName"
,"E1"."SecondName"
,"E1"."PersonalNumber"
,"REKURS"."L_REITING"

,"EventEndingDateChangeHistory"."EndingDateOld"::DATE
,"EventEndingDateChangeHistory"."SettlementDate"::DATE
,"E2"."LastName"
,"E2"."FirstName"
,"E2"."SecondName"
,"E2"."PersonalNumber"
),

/*___________________ генерация виртуального календаря_____________________________________*/		
"CALENDAR" as (SELECT 	
date_trunc('month',r) ::date as "FIRST_DAY"
,(to_char(r,'YYYY')::numeric)::text||(to_char(r,'MM')::numeric)::text as "YEAR_MONTHS"
		FROM generate_series('2010-01-01',now()::date, '1 day') as r
			),
			
"SHOP" as (select 
	"Documents"."Name"
	,'2010-01-01'::date as "DS"
	,case 
		when "Documents"."DocEndDate" is null then now()::date
		else "Documents"."DocEndDate"::date
	end as "DE"
	,"Documents"."Number"
	,"D1"."DepartmentName"
	,"Documents"."Code" --идентификтор предка
from "Documents" as "Documents" 
left join "ImportDepartments" as "importd"  on "Documents"."Number"::integer="importd"."ExternalId"::integer -- цех OBJID цехов	
left join "Departments" as "D1" on "D1"."Id"="importd"."DepartmentId"

where 
	"Description" IN ('Рейтинг цеха')
	and "Documents"."IsActual" in (true)
	--and "Documents"."Number" in ('20052525') --тест на цехе
	) ,
                               
"STRUCT_SHOP" as (
select distinct
	"CALENDAR"."FIRST_DAY" as "CALENDAR_DATE"
	,"DepartmentName" as "Цех"
	,("Number"||EXTRACT(year FROM "CALENDAR"."FIRST_DAY")||EXTRACT(Month FROM "CALENDAR"."FIRST_DAY"))::numeric  as "STRUCT_YEAR_MONTH"
	,"Number"::numeric as "OBJID"
	,1 as "PLAN"
from  "CALENDAR",   "SHOP" 
/*___________________ объединени двух таблиц_____________________________________*/		          
where "CALENDAR"."FIRST_DAY" between "SHOP"."DS" and "SHOP"."DE"
),


data AS (
    SELECT 
        "STRUCT_SHOP"."Цех",
        "STRUCT_SHOP"."STRUCT_YEAR_MONTH",
        "STRUCT_SHOP"."OBJID",
        "STRUCT_SHOP"."PLAN",
        "first"."Карта оценки",
        "Link_Card",
        "Название карты",
        "Дата создания",
        "FIRST_DAY_RR",
        "Дата план",
        "Дата факт",

        -- Заполняем "Статус", если он NULL, предыдущее значение используется
COALESCE(
    "Статус",
    --  Сначала берём последнее известное значение (из прошлого)
    MAX("Статус") OVER (
        PARTITION BY "STRUCT_SHOP"."OBJID"
        ORDER BY "STRUCT_SHOP"."STRUCT_YEAR_MONTH"
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ),
    --  Если его нет, берём ближайшее будущее значение
    MAX("Статус") OVER (
        PARTITION BY "STRUCT_SHOP"."OBJID"
        ORDER BY "STRUCT_SHOP"."STRUCT_YEAR_MONTH"
        ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
    )
) AS "Заполненный_Статус",

        "ИД_Подразделения_КОТ",
        "Prof",
        "Отв.Верификация",
        "L_REITING",
        "Дата окончания старая",
        "Дата корректировки",
        "ФИО Переносил сроки",

        -- Просрочка: проверяем даты
        CASE 
            WHEN "Дата факт" > "Дата план" THEN TRUE
            WHEN "Дата факт" IS NULL AND "Дата план" < NOW()::DATE THEN TRUE
            --WHEN "Дата корректировки" > "Дата окончания старая" AND "Дата факт" IS NULL THEN TRUE
            --WHEN "Дата корректировки" > "Дата план" 
            WHEN "Дата факт" > "Дата корректировки" THEN true
            ELSE FALSE
        END AS "Просрочка"
        
    FROM "STRUCT_SHOP"
    LEFT JOIN "first" 
        ON "STRUCT_SHOP"."OBJID" = "first"."L_REITING"
        AND "CALENDAR_DATE" = "FIRST_DAY_RR"
	
)
SELECT 
    *,
    
    -- ✅ Ball теперь зависит от комбинации "Заполненный_Статус" и дат
    CASE 
        -- 1️⃣ Когда статус есть и даты заполнены → Ball определяется по правилам дат
        WHEN "Заполненный_Статус" IS NOT NULL 
            AND ("Дата план" IS NOT NULL OR "Дата факт" IS NOT NULL OR "Дата корректировки" IS NOT NULL) 
        THEN 
            CASE 
                WHEN "Дата факт" > "Дата план" THEN 0
                WHEN "Дата факт" IS NULL AND "Дата план" < NOW()::DATE THEN 0
                WHEN "Дата корректировки" > "Дата окончания старая" AND "Дата факт" IS NULL THEN 0
                WHEN "Дата корректировки" > "Дата план" AND "Дата факт" > "Дата корректировки" THEN 0
                ELSE 5  -- Если проблем нет → 5
            END
        
        -- 2️⃣ Когда статус есть, но ВСЕ даты пустые → Ball = 5 (по статусу)
        WHEN "Заполненный_Статус" IS NOT NULL THEN 5

        -- 3️⃣ Когда статус пуст → Ball = 0 
        ELSE 0
    END AS "Ball"

FROM data
ORDER BY "OBJID", "STRUCT_YEAR_MONTH"
