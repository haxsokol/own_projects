select distinct  
 cast(replace(e."PersonalNumber",':','') as numeric) "PersonalNumber"
,_id."ExternalId" 
,d."DepartmentName" 
,concat(e."LastName",' ',substring(e."FirstName" from 1 for 1),'.',substring(e."SecondName" from 1 for 1),'. (',cast(replace(e."PersonalNumber",':','') as numeric),')') "FIO (TN)"  
from public."EventParticipants" ep 
join public."Employees" e on ep."EmployeeId"=e."Id" and e."PersonalNumber" is not null and e."EndDate" is null --and ep."ParticipantType"=1
join public."Revisions" r on eP."Id"=r."AuditorId" and r."RevisionTypeId" in (1,4) --and r."AuditorPkLevel"=1
join public."InternalEmployeePositionTypes" iept on e."Id"=iept."InternalEmployeeId" and iept."EndDate" is null
join public."PositionTypes" pt on iept."PositionTypeId"=pt."Id" 
join public."ImportDepartments" _id on pt."DepartmentId"=_id."DepartmentId"
join public."Departments" d on pt."DepartmentId"=d."Id"