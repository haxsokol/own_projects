from pydantic_settings import BaseSettings
import os
from pathlib import Path
from pydantic_settings import BaseSettings
from cryptography.fernet import Fernet

BASE_DIR = Path(__file__).parents[1]


def load_encrypted_env_vars():
    try:
        p = BASE_DIR / "src/.bin"
        env_path = BASE_DIR / ".env"

        with open(p, "rb") as f:
            key = f.read()
        cipher = Fernet(key)

        with open(env_path, "rb") as f:
            encrypted_data = f.read()
        decrypted_data = cipher.decrypt(encrypted_data).decode("utf-8")

        for line in decrypted_data.splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                value = value.strip().strip("'\"")
                os.environ[key.strip()] = value
    except Exception as e:
        print(f"Критическая ошибка при загрузке конфигурации: {e}")
        exit(1)


# ВЫЗЫВАЕМ ФУНКЦИЮ СРАЗУ ПРИ ЗАГРУЗКЕ МОДУЛЯ
load_encrypted_env_vars()


class DBSettings(BaseSettings):
    db_host: str
    db_port: int
    db_user: str
    db_password: str
    db_database: str | None
    db_dbms: str
    db_driver: str | None

    # Теперь 'env_file' не обязателен, т.к. мы читаем из переменных окружения,
    # но его можно оставить, он не помешает.
    # Для чистоты кода его лучше убрать.
    model_config = {"extra": "ignore"}

    @classmethod
    def from_prefix(cls, prefix: str) -> "DBSettings":
        class PrefixedSettings(cls):
            model_config = {
                **cls.model_config,
                "env_prefix": prefix,
            }

        return PrefixedSettings()

    @property
    def dsn(self):
        return f"{self.db_dbms}{self.db_driver}://{self.db_user}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_database}"


class DBSettingsSAP(BaseSettings):
    db_host: str
    db_port: int
    db_user: str
    db_password: str
    db_database: str | None
    db_dbms: str | None
    db_driver: str | None

    model_config = {"extra": "ignore"}

    @classmethod
    def from_prefix(cls, prefix: str) -> "DBSettingsSAP":
        class PrefixedSettings(cls):
            model_config = {
                **cls.model_config,
                "env_prefix": prefix,
            }

        return PrefixedSettings()

    @property
    def dsnSAP(self):
        return dict(
            address=self.db_host,
            port=self.db_port,
            user=self.db_user,
            password=self.db_password,
            locale=self.db_database,
        )
