import streamlit as st
import polars as pl
from datetime import date, datetime
import xlsxwriter
from io import BytesIO
from pathlib import Path
import os
from config.settings import BASE_DIR
from src.connectors.conn_db import ConnDB
from datetime import datetime, timedelta
from src.utils.ui_components import login_form


DIR_THIS_FILE = Path(__file__).parent

# настройка вкладки
st.set_page_config(page_title="Генератор карточек РР", page_icon="📚", layout="wide")
st.title("📚 Карточки РР — генератор")

# # 🔐 аутентификация
# if not login_form():
#     st.stop()

# ===================================================================================
# ОСНОВНОЙ КОД
# ===================================================================================

pl.Config(fmt_float="full")
PARQUET_PATH = DIR_THIS_FILE / "data_cards/ВсеКартыРРГруппа.parquet"
# Пути
# PARQUET_PATH = BASE_DIR / "data/output/parquet/ВсеКартыРРГруппа.parquet"
SQL_PATH = DIR_THIS_FILE / "data/input/sql/kot/КартыБезГруппировки.sql"

# --- ИЗМЕНЕНИЕ 4: Создаем две колонки для основного контента и инструкции ---
main_col, info_col = st.columns([3, 1])

with info_col:
    st.header("💡 Инструкция")
    st.markdown(
        """
    1.  **Обновите данные (по необходимости):**
        *   Нажмите кнопку **"Обновить базу данных Карт РР"**, чтобы загрузить самые свежие данные из базы данных.

    2.  **Введите номера карт:**
        *   В текстовое поле введите один или несколько номеров карт (например: `24633, 23578, ...`). Пробелы не важны.

    3.  **Сформируйте файлы:**
        *   Нажмите **"Сформировать Excel"**. Программа обработает каждый номер и подготовит для него отдельный файл.

    4.  **Скачайте готовые карты:**
        *   Столбец "Должности" - для 👷‍♂️ИТР
        *   Столбец "Профессии" - для 👨‍🏭Рабочих
    """
    )


# Весь основной интерфейс приложения теперь находится в левой, главной колонке
with main_col:

    def get_parquet_mtime_str(path: Path) -> str:
        """Возвращает отформатированную строку с датой и временем изменения файла с поправкой на временную зону."""
        if path.exists():
            # Получаем время изменения файла как timestamp
            mtime_timestamp = os.path.getmtime(path)
            # Конвертируем timestamp в объект datetime (это будет время сервера)
            server_datetime = datetime.fromtimestamp(mtime_timestamp)
            # Создаем объект смещения (3 часа и 2 минуты)
            time_offset = timedelta(hours=3, minutes=2)
            # Прибавляем смещение к времени сервера, чтобы получить корректное время
            correct_datetime = server_datetime + time_offset
            # Форматируем и возвращаем уже исправленное время
            return correct_datetime.strftime("%H:%M:%S %d.%m.%Y")

        return "Файл данных еще не создан."

    # -----------------------------------------------------

    # ---------------------------------------------------------------------------------

    # ===================================================================================
    # 1. КНОПКА ДЛЯ ОБНОВЛЕНИЯ ПАРКЕТНИКА
    # ===================================================================================
    if st.button("Обновить базу данных Карт РР"):
        with st.spinner("Обновляем данные из БД..."):

            df_raw = pl.from_pandas(ConnDB.get_df_from_sql(path_sql=SQL_PATH, prefix_db="KOT_"))

            (
                df_raw.group_by(
                    ["Карта оценки", "Рабочая зона", "Источник опасности", "Опасность", "Характер влияния воздействия", "Существующие меры управления", "Категория риска опасности"]
                )
                .agg(Должности=pl.col("Должности"), Профессии=pl.col("Профессии"))
                .with_columns(Должности=pl.col("Должности").list.unique().list.sort().list.join(", "), Профессии=pl.col("Профессии").list.unique().list.sort().list.join(", "))
                .select(
                    [
                        "Карта оценки",
                        "Должности",
                        "Профессии",
                        "Рабочая зона",
                        "Источник опасности",
                        "Опасность",
                        "Характер влияния воздействия",
                        "Существующие меры управления",
                        "Категория риска опасности",
                    ]
                )
                .write_parquet(PARQUET_PATH)
            )

            st.success("Данные успешно обновлены ✅")

    # --- ИЗМЕНЕНИЕ 1: Выводим дату и время последнего изменения файла ---
    st.caption(f"**Данные актуальны на:** {get_parquet_mtime_str(PARQUET_PATH)}")
    st.markdown("---")
    # -----------------------------------------------------------------------

    # ===================================================================================
    # 2. ВВОД НОМЕРА КАРТЫ + ГЕНЕРАЦИЯ EXCEL
    # ===================================================================================
    if PARQUET_PATH.exists():
        df = pl.read_parquet(PARQUET_PATH)

        if "generated_files" not in st.session_state:
            st.session_state.generated_files = []

        inmp = st.text_input("Введите номера карт (через запятую)", "")

        if st.button("Сформировать Excel"):
            st.session_state.generated_files = []
            numbers = inmp.replace(" ", "").split(",")

            with st.spinner("Идет формирование карт..."):
                for number_card in numbers:
                    if not number_card:
                        continue

                    # Фильтруем данные только для нужной карты
                    df_card_filtered = df.filter(pl.col("Карта оценки") == number_card)

                    if df_card_filtered.is_empty():
                        st.warning(f"Нет данных для карты {number_card}")
                        continue

                    # --- ИЗМЕНЕНИЕ 2: Логика удаления столбца "Должности" или "Профессии" ---
                    column_to_drop = None
                    kept_column_name = "Не определено"  # На случай, если оба столбца пустые

                    # Проверяем, пуст ли столбец "Профессии"
                    is_professii_all_null = df_card_filtered.select((pl.col("Профессии") == "").all()).item()

                    if is_professii_all_null:
                        column_to_drop = "Профессии"
                        kept_column_name = "Должности"
                    else:
                        # Если "Профессии" не пуст, проверяем "Должности"
                        is_dolzhnosti_all_null = df_card_filtered.select((pl.col("Должности") == "").all()).item()
                        if is_dolzhnosti_all_null:
                            column_to_drop = "Должности"
                            kept_column_name = "Профессии"

                    # Если оба столбца содержат данные, по умолчанию удаляем "Профессии" (как в старой логике)
                    if column_to_drop is None:
                        column_to_drop = "Профессии"
                        kept_column_name = "Должности"

                    # Применяем удаление и сортировку
                    df_for_write = df_card_filtered.drop(["Карта оценки", column_to_drop]).sort(["Рабочая зона", "Источник опасности", "Опасность"])
                    # ---------------------------------------------------------------------------------

                    output = BytesIO()
                    with xlsxwriter.Workbook(output, {"in_memory": True}) as workbook:
                        worksheet = workbook.add_worksheet(f"{number_card}")
                        header_format = workbook.add_format({"bold": True, "align": "center", "valign": "vcenter"})
                        worksheet.merge_range("A2:G2", f"Карта оценки профессиональных рисков № {number_card}", header_format)
                        start_row, start_col = 3, 0
                        worksheet.add_table(
                            start_row,
                            start_col,
                            start_row + df_for_write.height,
                            start_col + df_for_write.width - 1,
                            {
                                "data": df_for_write.rows(),
                                "columns": [{"header": c, "header_format": header_format} for c in df_for_write.columns],
                                "style": "Table Style Medium 15",
                                "autofilter": False,
                            },
                        )
                        wrap_center = workbook.add_format({"text_wrap": True, "valign": "top", "align": "left"})
                        worksheet.set_column(start_col, start_col + df_for_write.width - 1, 32.5, wrap_center)
                        worksheet.merge_range(
                            start_row + df_for_write.height + 3,
                            start_col + 2,
                            start_row + df_for_write.height + 3,
                            start_col + 3,
                            "Карту составил: руководитель рабочей группы",
                            workbook.add_format({"align": "left"}),
                        )
                        worksheet.write(start_row + df_for_write.height + 3, start_col + 5, date.today().strftime("%d.%m.%Y"), workbook.add_format({"align": "center"}))
                        worksheet.write_row(
                            start_row + df_for_write.height + 4,
                            start_col + 4,
                            ["(подпись)", "(дата)", "(расшифровка подписи)"],
                            workbook.add_format({"italic": True, "align": "center", "top": 1}),
                        )
                        worksheet.set_zoom(70)

                    output.seek(0)

                    # Добавляем в session_state информацию о сохраненном столбце
                    st.session_state.generated_files.append(
                        {
                            "label": f"📥 Скачать Excel для карты {number_card}",
                            "data": output,
                            "file_name": f"{number_card}.xlsx",
                            "key": f"download_btn_{number_card}",
                            "kept_column": kept_column_name,  # --- ИЗМЕНЕНИЕ 2: Сохраняем имя столбца
                        }
                    )
            st.success("Все файлы успешно сформированы!")

    # Блок для отображения всех кнопок из session_state
    if st.session_state.get("generated_files"):
        st.markdown("---")
        st.subheader("Готовые файлы для скачивания:")

        for file_info in st.session_state.generated_files:
            # --- ИЗМЕНЕНИЕ 2: Используем колонки для вывода кнопки и информации о столбце ---
            btn_col, info_col_dl = st.columns([3, 2])
            with btn_col:
                st.download_button(
                    label=file_info["label"],
                    data=file_info["data"],
                    file_name=file_info["file_name"],
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key=file_info["key"],
                )
            with info_col_dl:
                st.info(f"В карте используется столбец: **{file_info['kept_column']}**")
            # ---------------------------------------------------------------------------------

