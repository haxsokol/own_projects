/*___ Оценка рисков ___*/
SELECT "Карта оценки"
	,"Должности"
	,"Профессии"
	,"Рабочая зона"
	,"Источник опасности"
	,"Опасность"
	,"Характер влияния воздействия"
	,"Изм_Характер влияния воздействия"
	,"Существующие меры управления"
	,"Изм_Существующие меры управления"
	,"Категория риска опасности"
FROM (
	SELECT 
		"Risk_Assessment"."CardNumber" AS "Карта оценки"
		,STRING_AGG(pn."Name", ', ') AS "Должности"
		,
		-- <-- Объединяем должности
		STRING_AGG(pt."Name", ', ') AS "Профессии"
		,
		-- <-- Объединяем профессии
		CASE 
			WHEN "Risk_WorkAreas"."Name" IS NULL
				THEN 'Рабочая зона не выбрана'
			ELSE "Risk_WorkAreas"."Name"
			END AS "Рабочая зона"
		,"Risk_DangerSources"."Name" AS "Источник опасности"
		,"Risk_Dangers"."Name" AS "Опасность"
		,"Risk_Dangers"."ImpactDescription" AS "Характер влияния воздействия"
		,"Risk_Dangers"."ExistingControls" AS "Существующие меры управления"
		,"RiskWorkAreaDangerSource_RiskDangers"."Description" AS "Изм_Характер влияния воздействия"
		,"RiskWorkAreaDangerSource_RiskDangers"."ExistingControls" AS "Изм_Существующие меры управления"
		,"Risk_Risks2"."Name" AS "Категория риска опасности"

	FROM "Risk_Assessment"
	-- Событие
	LEFT JOIN "Events" ON "Risk_Assessment"."EventId" = "Events"."Id"
		AND "Events"."IsActual" = TRUE
	-- Рабочие зоны
	LEFT JOIN "RiskAssessment_RiskWorkArea" ON "Risk_Assessment"."CardNumber"::NUMERIC = "RiskAssessment_RiskWorkArea"."RiskAssessmentId"
		AND "RiskAssessment_RiskWorkArea"."IsActual" = TRUE
	LEFT JOIN "Risk_WorkAreas" ON "RiskAssessment_RiskWorkArea"."WorkAreaId" = "Risk_WorkAreas"."Id"
		AND "Risk_WorkAreas"."IsActual" = TRUE
	-- Источники опасности
	LEFT JOIN "RiskAssessmentWorkArea_RiskDangerSources" AS rawar ON "RiskAssessment_RiskWorkArea"."Id" = rawar."AssessmentWorkAreaId"
		AND rawar."IsActual" = TRUE
	LEFT JOIN "Risk_DangerSources" ON rawar."DangerSourceId" = "Risk_DangerSources"."Id"
	--and "Risk_DangerSources"."IsActual" = true 
	-- Опасности
	LEFT JOIN "RiskWorkAreaDangerSource_RiskDangers" ON rawar."Id" = "RiskWorkAreaDangerSource_RiskDangers"."WorkAreaDangerSourceId"
		AND "RiskWorkAreaDangerSource_RiskDangers"."IsActual" IS TRUE
	LEFT JOIN "Risk_Dangers" ON "RiskWorkAreaDangerSource_RiskDangers"."DangerId" = "Risk_Dangers"."Id"
		AND "Risk_Dangers"."IsActual" = TRUE
	-- Должности
	LEFT JOIN "RiskAssessment_PositionNames" rapn ON "Risk_Assessment"."Id" = rapn."RiskAssessmentId"
		AND rapn."IsActual" = TRUE
	LEFT JOIN "PositionNames" pn ON rapn."PositionNameId" = pn."Id"
		AND pn."IsActual" = TRUE
	-- Профессия
	LEFT JOIN "RiskAssessment_ProfessionTypes" rapt ON "Risk_Assessment"."Id" = rapt."RiskAssessmentId"
		AND rapt."IsActual" = TRUE
	LEFT JOIN "ProfessionTypes" pt ON rapt."ProfessionTypeId" = pt."Id"
		AND pt."IsActual" = TRUE
	-- Категория риска
	LEFT JOIN "RiskWorkAreaDangerSource_RiskDangers_CalculatedFields" ON "RiskWorkAreaDangerSource_RiskDangers"."Id" = "RiskWorkAreaDangerSource_RiskDangers_CalculatedFields"."Id"
	LEFT JOIN "Risk_Risks" AS "Risk_Risks2" ON "Risk_Risks2"."Id" = "RiskWorkAreaDangerSource_RiskDangers_CalculatedFields"."RiskId"
		AND "Risk_Risks2"."IsActual" = TRUE
	WHERE "Risk_Assessment"."IsActual" = TRUE
		--and "Risk_Assessment"."Relevance" = true
		AND "Risk_Dangers"."Name" IS NOT NULL
	--and "Risk_Dangers"."IsNo" is not true
	GROUP BY 
		,"Risk_Assessment"."CardNumber"
		, "Risk_WorkAreas"."Name"
		,"Risk_DangerSources"."Name"
		,"Risk_Dangers"."Name"
		,"Risk_Dangers"."ImpactDescription"
		,"RiskWorkAreaDangerSource_RiskDangers"."Description"
		,"Risk_Dangers"."ExistingControls"
		,"RiskWorkAreaDangerSource_RiskDangers"."ExistingControls"
		,"Risk_Risks2"."Name"
		--ORDER BY "Risk_Assessment"."CardNumber" DESC
	) AS foo
	--    WHERE ("Должности" IS NOT NULL) AND ("Профессии" IS NOT NULL)
