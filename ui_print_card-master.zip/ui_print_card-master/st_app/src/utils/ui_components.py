import streamlit as st
import time

# --- Функция проверки пароля ---
def login_form():
    """Создает форму входа и проверяет пароли из secrets.toml"""
    if st.session_state.get("authenticated"):
        return True

    # Форма для ввода данных
    with st.form("login_form"):
        st.header("🔐 Вход в систему")
        username = st.text_input("Логин")
        password = st.text_input("Пароль", type="password")
        submit_button = st.form_submit_button("Войти")

        if submit_button:
            if username in st.secrets["passwords"] and st.secrets["passwords"][username] == password:
                st.session_state["authenticated"] = True
                st.session_state["username"] = username
                st.success("Успешный вход!")
                time.sleep(0.5)
                st.rerun() 
            else:
                st.error("Неверный логин или пароль")
    
    return False
