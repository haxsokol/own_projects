from pathlib import Path
from sqlalchemy import text


def read_sqlalch(path: str | Path):
    file_path = Path(path) if isinstance(path, str) else path
    with open(file_path, "r", encoding="utf-8") as file:
        return text(file.read())


def read_sql_sap(path: str):
    return Path(path).read_text(encoding="UTF-8")
