from pathlib import Path
from sqlalchemy import create_engine, Engine
from sqlalchemy import text
from config.settings import BASE_DIR, DBSettings
import pandas as pd
import polars as pl


class ConnDB:
    def get_engine_db(prefix_db: str) -> Engine:
        dsn_for_engine = DBSettings.from_prefix(prefix_db).dsn
        return create_engine(dsn_for_engine)

    @classmethod
    def get_df_from_sql(cls, path_sql: Path, prefix_db: str) -> pd.DataFrame:
        # Читаем SQL-запрос из файла
        with open(path_sql, "r", encoding="utf-8") as file:
            query = text(file.read())

        # Создаем движок из метода выше
        engine = cls.get_engine_db(prefix_db)

        # Выполняем запрос через pandas и созданный движок
        return pd.read_sql(query, engine)

    @classmethod
    def get_pl_from_sql(cls, path_sql: Path, prefix_db: str) -> pl.DataFrame:
        # Читаем SQL-запрос из файла
        query = path_sql.read_text()

        # Создаем движок из метода выше
        engine = cls.get_engine_db(prefix_db)

        # Выполняем запрос через pandas и созданный движок
        return pl.read_database(query, engine)
