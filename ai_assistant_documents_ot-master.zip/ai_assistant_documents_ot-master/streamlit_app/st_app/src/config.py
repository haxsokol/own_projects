import os

# --- КОНФИГУРАЦИЯ ---
OPENROUTER_API_KEY = os.environ["API_TOKEN_MY"]
OPENROUTER_API_KEY_HAKATON = os.environ["API_TOKEN_H"]

LIGHTRAG_HOST = "http://lightrag-st:9621"
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
