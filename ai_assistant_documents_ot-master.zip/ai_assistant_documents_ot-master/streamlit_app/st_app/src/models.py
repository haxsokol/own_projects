from pydantic import BaseModel, Field, field_validator


# ====================================================================================================
# ВХОДНЫЕ/ВЫХОДНЫЕ ДАННЫЕ ИЗ ЗАПОЛНЕНИЯ ПОЛЬЗОВАТЕЛЕМ + РАСПОЗНАВАНИЕ АУДИО И ФОТО:
# 1. Ввод описания разовой работы


# Описание от пользователя для ТКР ⬇
class UserPromtResault(BaseModel):
    text: str | None = Field(
        description="Текстовое описание разовой работы для создания ТКР"
    )
    audiofile: str | None = Field(
        default=None,
        description="Текстовая расшифровка аудиофайла с описанием разовой работы для создания ТКР",
    )
    audiovoice: str | None = Field(
        default=None,
        description="Текстовая расшифровка голосового сообщения с описанием разовой работы для создания ТКР",
    )
    img: str | None = Field(
        default=None,
        description=(
            "Текстовое описание изображений, загруженных пользователем."
            "На изображениях подрузомевается изображение локаций, предметов, связанных с разовой работой"
        ),
    )
    dangers: str = Field(
        description="Список опасностей, которые пользователь указал сам"
    )
    siz: str = Field(
        description="СИЗ, указанные пользователем при выполнении разовой работы"
    )
    prof: str = Field(
        description="Профессии, указанные пользователем при выполнении разовой работы"
    )
    workshop: str = Field(
        description="Цех/Локация, где будет производится разова работа"
    )

    @field_validator("prof", "dangers", "siz", "workshop", mode="before")
    @classmethod
    def convert_list_to_string(cls, v: str) -> str:
        # Если пришел список — склеиваем его через запятую
        if isinstance(v, list):
            return ", ".join(map(str, v))
        return str(v) if v is not None else ""

    def get_pretty_repr(self) -> str:
        # Словарь перевода ключей на русский
        labels = {
            "text": "📝 Текстовое описание",
            "audiofile": "📼 Аудиофайл",
            "audiovoice": "🎙️ Голосовой ввод",
            "img": "🚧📷 Описание фото с места работ",
            "dangers": "⚡ Опасности",
            "siz": "⛑ СИЗ",
            "prof": "👷‍♂️ Профессии",
            "workshop": "🏭 Цех",
        }

        lines = []
        data = self.model_dump()

        for key, value in data.items():
            label = labels.get(key, key)
            display_value = value if value else "—"
            lines.append(f"{label}: {display_value}")
        return "\n".join(lines)

    def get_table_data(self) -> list[dict]:
        labels = {
            "text": "📝 Текстовое описание",
            "audiofile": "📼 Аудиофайл",
            "audiovoice": "🎙️ Голосовой ввод",
            "img": "🚧📷 Описание фото",
            "dangers": "⚡ Опасности",
            "siz": "⛑ СИЗ",
            "prof": "👷‍♂️ Профессии",
            "workshop": "🏭 Цех",
        }
        rows = []
        data = self.model_dump()
        for key, value in data.items():
            rows.append(
                {"Параметр": labels.get(key, key), "Значение": value if value else ""}
            )
        return rows


# ----------------------------------------------------------------------------------------------------


# Описание разовой работы от ИИ для ТКР ⬇
class AiPromtResault(BaseModel):
    """структура выходных данных для агента HSE (Охрана труда).
    Агент должен проанализировать вводные данные и ОБЯЗАТЕЛЬНО дополнить их, если их не достаточно,
    используя свои знания о технике безопасности."""

    context: str = Field(
        description=(
            "Сформируй техническое резюме (Context) разовой работы "
            "Объедини информацию из `text`, `audiovoice`,`audiofile` и `img` "
        ),
        max_length=4000,
    )
    dangers: str = Field(
        description=(
            "1 Проанализируй опасности из входного параметра `dangers` "
            "2 Выяви СКРЫТЫЕ риски на основе описания работы (высота, огневые работы, замкнутое пространство и тд) "
            "3 Верни итоговый расширенный список опасностей через запятую в одну строку без нумерации"
        ),
        max_length=1000,
    )
    siz: str = Field(
        description=(
            "1 Проверь СИЗ из параметра `siz` "
            "2 Добавь недостающие СИЗ согласно нормам для данного вида работ"
            "3 Верни полный список через запятую в одну строку без нумерации"
        ),
        max_length=1000,
    )
    prof: str = Field(
        description=(
            "1 Проверь профессии из параметра `prof` "
            "2 Если нужны дополнительные специалисты (наблюдающий, ответственный руководитель, стропальщик), добавь их "
            "3 Верни полный состав профессий, которые должны выполнять эту разовую работу ччерез запятую в одну строку без нумерации"
        ),
        max_length=1000,
    )
    workshop: str = Field(
        description=(
            "Верни название цеха из входного параметра `workshop` "
            "Если в контексте работы явно указано другое местоположение, уточни его"
        ),
        max_length=500,
    )

    def get_pretty_repr(self) -> str:
        # Словарь перевода ключей на русский
        labels = {
            "context": "📝 Итоговое описание разовой работы",
            "dangers": "⚡ Опасности",
            "siz": "⛑ СИЗ",
            "prof": "👷‍♂️ Профессии",
            "workshop": "🏭 Цех",
        }

        lines = []
        data = self.model_dump()

        for key, value in data.items():
            label = labels.get(key, key)
            display_value = value if value else "—"
            lines.append(f"{label}: {display_value}")
        return "\n".join(lines)


# ====================================================================================================
# ВЫХОДНЫЕ ДАННЫЕ ДЛЯ ИИ АГЕНТОВ
# 2. Титульный лист:
class TitleInstrumentRow(BaseModel):
    number: str = Field(description="номер пункта в таблице")
    name_instrument: str = Field(
        max_length=70,
        description="наименование инструмента для выполнения разовой работы",
    )
    count_instrument: str = Field(
        description="количество необходимого наименования инструмента числом и сокращенно в чем измеряется"
        "всегда начинается с числа, затем сокращенное название единицы измеерния, например: '1 шт'"
    )


class Title(BaseModel):
    title_name: str = Field(default="")
    title_post: str | None
    title_fio: str | None
    table_instrument: list[TitleInstrumentRow] | None = Field(max_length=12)


# ----------------------------------------------------------------------------------------------------
# 3. Технология выполнения работ
# без картинок:
class ExecutionTechnologyRow(BaseModel):
    number_action: str = Field(
        description=(
            "Номер операции в последовательности действий технологии выполнении работ,"
            "должен быть цифрой, но типом данных str"
        ),
        max_length=2,
    )
    action_describe: str = Field(
        description="Описание действия операции, отражающую последовательность технологии работ",
        min_length=10,
        max_length=2000,
    )


class ExecutionTechnology(BaseModel):
    exec_techn_list: list[ExecutionTechnologyRow] = Field(min_length=5, max_length=30)


# -----------------------------------------------------------------
# с маркером для картинки:
class ExecutionTechnologyRowWithPrepImages(ExecutionTechnologyRow):
    is_complex_operation: str | None = Field(
        description="Маркет сложной операции, для"
        "которой нужно создать картинку. Если сложная то проставляем 1, если простая то 0",
    )


class ExecutionTechnologyWithPrepImages(ExecutionTechnology):
    exec_techn_list: list[ExecutionTechnologyRowWithPrepImages] = Field(
        min_length=5, max_length=30
    )


# -----------------------------------------------------------------
# с картинками:
class ExecutionTechnologyRowWithImages(ExecutionTechnologyRow):
    image_base64_raw: bytes | None = Field(default=None)


class ExecutionTechnologyWithImages(ExecutionTechnology):
    exec_techn_list: list[ExecutionTechnologyRowWithImages] = Field(
        min_length=5, max_length=30
    )


# ----------------------------------------------------------------------------------------------------
# 4. Ведомость ОПФ, ВПФ и меры защиты


class HarmfulDangerousFactorRow(BaseModel):
    number_factor: str = Field(
        description=(
            "Номер опасного или вредного фактора при выполнении работ в ТКР,"
            "должен быть цифрой, но типом данных str"
        ),
        max_length=2,
    )
    factor: str = Field(description=("Название вредного или опасного фактора"))
    measures_to_regulate_factor: str | None = Field(
        description=(
            "Описания мероприятия, которое будет регулировать опасный или вредный фактор"
            "и делать опасные или вредный фактор безопасным"
        ),
        max_length=1000,
    )


class HarmfulDangerousFactor(BaseModel):
    fact_list: list[HarmfulDangerousFactorRow] = Field(min_length=3, max_length=30)


# ----------------------------------------------------------------------------------------------------
# 5. Смертельные опасности


class DeadlyDangerRow(BaseModel):
    number_danger: str = Field(
        description=(
            "Номер смертельного риска при выполнении работ в ТКР,"
            "должен быть цифрой, но типом данных str"
        ),
        max_length=2,
    )
    danger: str = Field(
        description=(
            "Название смертельного риска, который есть или может быть при выполнении описанных операций"
            "описанных в технологии выполнения работ"
        )
    )
    is_present_danger: str | None = Field(
        description=("Есть ли эта опасность, нужно проставлять 'Да' или 'Нет'"),
        max_length=3,
    )


class DeadlyDanger(BaseModel):
    danger_risks: list[DeadlyDangerRow] = Field(
        description="В выходных данных всегда должны быть следующие смертельные риски:"
        "[Работы на высоте,Перемещение грузов,Обрушение металлоконструкций,Падение предметов с высоты,Электрический ток,"
        "Огневые работы. Открытое пламя,Обрушение, осыпь материала,Движущийся транспорт,Работа с кислородом]"
        "но если есть ещё какие то смертельные риски, то их тоже нужно внести в выходные данные и указать в `is_present_danger` 'Да'",
        min_length=8,
        max_length=15,
    )


# ====================================================================================================
