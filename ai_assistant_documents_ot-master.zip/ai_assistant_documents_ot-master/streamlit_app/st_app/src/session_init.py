import streamlit as st


def init_session_storage():
    if "tcr_audio_voice" not in st.session_state:
        st.session_state.tcr_audio_voice = ""
    if "tcr_audio_file" not in st.session_state:
        st.session_state.tcr_audio_file = ""
    if "text_input_context_area" not in st.session_state:
        st.session_state.text_input_context_area = ""

    if "all_text" not in st.session_state:
        st.session_state.all_text = "(Текстовое описание): "

    if "prev_text_input" not in st.session_state:
        st.session_state.prev_text_input = ""
    if "prev_audio_voice" not in st.session_state:
        st.session_state.prev_audio_voice = ""
    if "prev_audio_file" not in st.session_state:
        st.session_state.prev_audio_file = ""

    if "recognize_imgs" not in st.session_state:
        st.session_state.recognize_imgs = ""

    if "total_text_job_description" not in st.session_state:
        st.session_state.total_text_job_description = ""
    if "final_promt" not in st.session_state:
        st.session_state.final_promt = ""
    if "final_promt_ai" not in st.session_state:
        st.session_state.final_promt_ai = ""
    if "title_fill_obj" not in st.session_state:
        st.session_state.title_fill_obj = ""
    if "final_promt_ai_stage" not in st.session_state:
        st.session_state.final_promt_ai_stage = ""
    if "filled_exec_tech" not in st.session_state:
        st.session_state.filled_exec_tech = ""
    if "filled_hamf_danger_factor" not in st.session_state:
        st.session_state.filled_hamf_danger_factor = ""
    if "filled_letal_danger" not in st.session_state:
        st.session_state.filled_letal_danger = ""
    if "filled_exec_tech_img" not in st.session_state:
        st.session_state.filled_exec_tech_img = ""
    if "filled_exec_tech_prep_img" not in st.session_state:
        st.session_state.filled_exec_tech_prep_img = ""
