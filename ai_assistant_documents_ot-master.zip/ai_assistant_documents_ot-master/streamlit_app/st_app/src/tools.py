import httpx
import requests
from agents import function_tool
from .config import LIGHTRAG_HOST, OPENROUTER_API_KEY, OPENROUTER_API_KEY_HAKATON
from .utills import return_lists_items
import json
import base64
import io

default_mode = "local"


# тестовый
@function_tool
async def lightrag_query_test(question: str, mode: str = default_mode) -> str:
    """
    Поиск информации в базе знаний LightRAG.
    Используй этот инструмент, когда нужно найти техническую информацию,
    регламенты или данные из документов.

    Args:
        question: Вопрос для поиска.
    """
    url = f"{LIGHTRAG_HOST}/query"

    payload = {
        "query": question,
        "mode": mode,
    }

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()

            if isinstance(data, dict):
                return data.get("response", str(data))
            return str(data)
    except Exception as e:
        return f"Ошибка при подключении к LightRAG: {e}"


# выбирает документы из LightRAG сам
@function_tool
async def get_answer_from_docum_lightrag(
    question: str, file_names: list[str], mode: str = default_mode
) -> str:
    """
    Поиск информации в базе знаний LightRAG по КОНКРЕТНЫМ ДОКУМЕНТАМ,
    названия документов указываются в `file_names`
    Args:
        question: Вопрос пользователя.
        file_names: СПИСОК точных названий файлов, в которых нужно искать.
                    Пример: ["report_2024.pdf", "salary_data.xlsx"]
    """
    url = f"{LIGHTRAG_HOST}/query"

    # payload со списком документов:
    payload = {"query": question, "mode": mode, "doc_ids": file_names}

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=payload)
            data = resp.json()

            if isinstance(data, dict):
                return data.get("response", str(data))
            return str(data)

    except httpx.HTTPStatusError as e:
        return f"Ошибка API LightRAG ({e.response.status_code}): {e.response.text}"
    except Exception as e:
        return f"Ошибка при подключении к LightRAG: {e}"


# Технологические операции
@function_tool
async def search_tech_safety(query: str, mode: str = default_mode) -> str:
    """
    Поиск в LightRAG наименований смертельных, вредных факторов.
    Мер регулирования смертельных, вредных факторов.
    Какие нужно использовать средства индивидуальной защиты.
    Всегда ищет в нужном документе.
    """
    url = f"{LIGHTRAG_HOST}/query"
    payload = {
        "query": query,
        "mode": mode,
        "doc_ids": ["Безопасное проведение работ ОТ.pdf"],
    }

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=payload)
            data = resp.json()
            return data.get("response", str(data))
    except Exception as e:
        return f"Ошибка: {e}"


# ОПФ, ВПФ
# @function_tool
# async def search_opf_vpf_siz(query: str, mode: str = default_mode) -> str:
#     """
#     Поиск в LightRAG наименований смертельных, вредных факторов.
#     Мер регулирования смертельных, вредных факторов.
#     Какие нужно использовать средства индивидуальной защиты.
#     Всегда ищет в нужном документе.
#     """
#     url = f"{LIGHTRAG_HOST}/query"
#     payload = {
#         "query": query,
#         "mode": mode,
#         "doc_ids": [
#             "Средства индивидуальной защиты.xlsx",
#             "Опасные факторы, отношение к работе на высоте, маркер смертельного риска.xlsx",
#             "Вредные факторы.xlsx",
#         ],
#     }

#     try:
#         async with httpx.AsyncClient(timeout=120.0) as client:
#             resp = await client.post(url, json=payload)
#             data = resp.json()
#             return data.get("response", str(data))
#     except Exception as e:
#         return f"Ошибка: {e}"


# БОЛЬШЕ ЗАДЕРЖКИ НА ВЫПОЛНЕНИЕ Т.К. LightRAG не справляется с большим количеством запросов
@function_tool
async def search_opf_vpf_siz(query: str, mode: str = default_mode) -> str:
    url = f"{LIGHTRAG_HOST}/query"
    payload = {
        "query": query,
        "mode": mode,
        "doc_ids": [
            "Средства индивидуальной защиты.xlsx",
            "Опасные факторы, отношение к работе на высоте, маркер смертельного риска.xlsx",
            "Вредные факторы.xlsx",
        ],
    }

    try:
        timeout = httpx.Timeout(connect=10.0, read=120.0, write=30.0, pool=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, json=payload)
            # ВАЖНО: сначала статус
            resp.raise_for_status()

            # Пытаемся распарсить JSON, иначе вернём сырой текст
            try:
                data = resp.json()
            except Exception:
                return (
                    f"Non-JSON response (status={resp.status_code}): {resp.text[:2000]}"
                )

            return data.get("response", str(data))

    except httpx.HTTPStatusError as e:
        # Тут будет видно 429/500 и тело ответа
        body = (e.response.text or "")[:2000]
        return f"HTTPStatusError: status={e.response.status_code}, body={body}"
    except Exception as e:
        return f"{type(e).__name__}: {repr(e)}"


# Смертельные риски
@function_tool
async def search_letal_factors(query: str, mode: str = default_mode) -> str:
    """
    Поиск смертельных факторов в специальной базе.
    Всегда ищет в нужном документе.
    """
    url = f"{LIGHTRAG_HOST}/query"
    payload = {
        "query": query,
        "mode": mode,
        "doc_ids": [
            "Опасные факторы, отношение к работе на высоте, маркер смертельного риска.xlsx"
        ],
    }

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=payload)
            data = resp.json()
            return data.get("response", str(data))
    except Exception as e:
        return f"Ошибка: {e}"


# =================================================================================================================================================
# создание картинок
@function_tool
def generate_vector_instruction_image(
    action_describe: str, api_key: str = OPENROUTER_API_KEY
) -> bytes:
    """
    Генерирует векторную инструкцию (триптих) на основе описания шагов.
    Возвращает декодированные байты изображения.
    """
    url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    style_rules = """
    VISUAL STYLE GUIDE:
    Create a high-quality realistic vector illustration.
    Art Style: "Adobe Illustrator" style with Gradient Mesh. Clean, sharp lines and precise geometry. High fidelity and realistic proportions, but maintaining a clear "digital drawing" aesthetic. NOT a photograph, NOT a grainy 3D render. Smooth vector gradients.
    Crucial Requirement: TEXTLESS. There must be NO text, NO numbers, NO letters, and NO labels on the image. Visual storytelling only.
    Lighting: Bright, professional, even lighting. No harsh shadows.
    Colors: Vibrant but professional. Industrial Blues, Safety Orange, Clean Greys.
    """

    collage_prompt = (
        f"{style_rules}\n\n"
        f"IMAGE LAYOUT: A wide horizontal instructional image split into 3 distinct vertical panels (triptych), reading from left to right.\n"
        f"STRICTLY NO TEXT OR WATERMARKS IN ANY PANEL.\n"
        f"CONTEXT OF OPERATION: {action_describe}\n"
        f"Generate 3 logical steps (Start -> Action -> Result) based on the context above.\n"
        f"Make sure the character and environment are consistent across all panels."
    )

    payload = {
        "model": "google/gemini-2.5-flash-image",
        "temperature": 0.0,
        "messages": [{"role": "user", "content": collage_prompt}],
        "modalities": ["image", "text"],
        "image_config": {"aspect_ratio": "21:9"},
    }
    response = requests.post(url, headers=headers, json=payload)
    result = response.json()

    img_data = result["choices"][0]["message"]["images"][0]
    base64_string = img_data["image_url"]["url"].split(",")[1]
    # возвращаем поток байт, т.к. docxtpl умеет писать картинки в Word из потока байт
    return io.BytesIO(base64.b64decode(base64_string))


# =================================================================================================================================================
# легаси тулзы, не используются
@function_tool
def get_siz_list() -> list[str]:
    data = return_lists_items("ProtMat_Name")
    return json.dumps(data=data, ensure_ascii=False)


@function_tool
def get_dangers_list() -> list[str]:
    data = return_lists_items("Risk_Dangers")
    return json.dumps(data=data, ensure_ascii=False)


@function_tool
def get_profs_list() -> list[str]:
    data = return_lists_items("JobsWorker", "Job")
    return json.dumps(data=data, ensure_ascii=False)
