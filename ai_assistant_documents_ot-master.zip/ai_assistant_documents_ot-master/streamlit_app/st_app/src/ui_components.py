import streamlit as st
import requests
from .config import OPENROUTER_API_KEY, OPENROUTER_API_KEY_HAKATON


# проверка баланса с UI:
@st.fragment
def check_money():
    with st.form("my_form"):
        select_api_key = {
            "Мой": OPENROUTER_API_KEY,
            "Хакатон": OPENROUTER_API_KEY_HAKATON,
        }
        select_key = st.pills(
            label="Баланс какого ключа проверяем?",
            options=select_api_key.keys(),
            key="selected_key",
            default="Мой",
        )
        headers = {"Authorization": f"Bearer {select_api_key[select_key]}"}
        if st.form_submit_button(label="Проверить баланс"):
            money = requests.get(
                "https://openrouter.ai/api/v1/credits", headers=headers
            ).json()["data"]
            st.write(f"{round(money["total_usage"],2)} / {money["total_credits"]}")
