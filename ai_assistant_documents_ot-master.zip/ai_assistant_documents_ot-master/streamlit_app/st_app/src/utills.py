import streamlit as st
from .config import OPENROUTER_API_KEY_HAKATON, OPENROUTER_URL
import base64
import requests
from sqlalchemy import create_engine
import polars as pl
from docxtpl import DocxTemplate, InlineImage
from docx.shared import Mm
from pathlib import Path
from pydantic import BaseModel

# from openai import AsyncOpenAI
from langfuse.openai import AsyncOpenAI
from .models import *
from dotenv import load_dotenv
import os
from io import BytesIO
from docx import Document as Document_compose
from docxcompose.composer import Composer
from concurrent.futures import ThreadPoolExecutor

load_dotenv()


DIR_TEMPLATE = Path(__file__).parents[1] / "template_word"
clientOpenRouter = AsyncOpenAI(
    api_key=OPENROUTER_API_KEY_HAKATON,
    base_url="https://openrouter.ai/api/v1",
)


# --- ТРАНСКРИБАЦИЯ АУДИО ---
async def transcribe_user_audio(audio_bytes: bytes, file_name: str) -> str:
    """
    Принимает байты аудио и возвращает текст, используя мультимодальную модель Gemini через OpenRouter.
    """
    try:
        # 1. Определяем MIME-тип
        mime_type = "audio/wav"
        if file_name.lower().endswith(".mp3"):
            mime_type = "audio/mpeg"
        elif file_name.lower().endswith(".ogg"):
            mime_type = "audio/ogg"
        elif file_name.lower().endswith(".m4a"):
            mime_type = "audio/mp4"

        # 2. Кодируем в Base64
        base64_audio = base64.b64encode(audio_bytes).decode("utf-8")
        data_url = f"data:{mime_type};base64,{base64_audio}"

        # 3. Отправляем запрос в Chat Completions (мультимодальный)
        model_id = "google/gemini-2.5-flash"
        response = await clientOpenRouter.chat.completions.create(
            model=model_id,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": (
                                "На вход подается голосовая аудиозапись, где говорится, на какую разовую работу нужно будет составить техкарту"
                                "Прослушай аудиозапись и транскрибируй её на русский язык, оставь только описание работы, с помощью чего и кто будет выполнять эту работу"
                                "Пиши дословно только текст расшифровки на технически грамотном языке, без вступлений."
                            ),
                        },
                        {
                            "type": "image_url",
                            "image_url": {"url": data_url},
                        },
                    ],
                }
            ],
            temperature=0.0,
        )
        content = response.choices[0].message.content
        return content

    except Exception as e:
        error_msg = f"[Ошибка API]: {str(e)}"
        print(f"ERROR: {error_msg}")
        if "401" in str(e):
            error_msg += " (Проверьте API ключ)"
        if "404" in str(e):
            error_msg += " (Возможно, модель недоступна или переименована)"
        return error_msg


async def process_audio_file(audio_bytes, source_name):
    status_container = st.empty()
    with status_container.container():
        with st.spinner(f"Расшифровываем аудио ..."):
            text = await transcribe_user_audio(audio_bytes, file_name=source_name)
            st.session_state.tcr_audio_file = f"{text}"


async def process_audio_voice(audio_bytes, source_name):
    status_container = st.empty()
    with status_container.container():
        with st.spinner(f"Расшифровываем аудио ..."):
            text = await transcribe_user_audio(audio_bytes, file_name=source_name)
            st.session_state.tcr_audio_voice = f"{text}"


def recognize_images(list_image_from_file_upload: list) -> str:
    list_res_str = []
    url = OPENROUTER_URL
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY_HAKATON}",
        "Content-Type": "application/json",
    }
    for img in list_image_from_file_upload:
        mime = img.name.split(".")[-1]
        base64_image = base64.b64encode(img.getvalue()).decode("utf-8")
        data_url = f"data:image/{mime};base64,{base64_image}"
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Опиши кратко обстановку, предметы, оборудование, опасности на изображении",
                    },
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            }
        ]
        payload = {
            "model": "google/gemini-2.0-flash-001",
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": 450,
        }
        response = requests.post(url, headers=headers, json=payload)
        list_res_str.append(response.json()["choices"][0]["message"]["content"])
    return ";".join(list_res_str)


# =============================================================================================================
# СПИСКИ ДЛЯ ВЫПАДАЮЩИХ МЕНЮ:

pg_user = os.environ["POSTGRES_USER"]
pg_pass = os.environ["POSTGRES_PASSWORD"]
pg_db = os.environ["POSTGRES_DB"]
engine = create_engine(f"postgresql+psycopg://{pg_user}:{pg_pass}@pg17:5432/{pg_db}")


def return_lists_items(tab_name: str, col_name: str = "Name") -> list[str]:
    list_items = (
        pl.read_database(
            query=f'SELECT DISTINCT "{col_name}" FROM public."{tab_name}"',
            connection=engine,
        )
        .select(col_name)
        .sort(by=col_name)
        .to_series()
        .to_list()
    )
    return list_items


# =============================================================================================================
# ФУНКЦИЯ ДЛЯ ФОРМИРОВАНИЯ WORD ДОКУМЕНТОВ:
def create_word_docx_template(template_name: str, content_fill: BaseModel) -> BytesIO:
    template_path = DIR_TEMPLATE / f"{template_name}.docx"
    tpl = DocxTemplate(template_path)
    tpl.render(content_fill.model_dump())
    buffer = BytesIO()
    tpl.save(buffer)
    buffer.seek(0)
    return buffer


# Вспомогательная функция для конвертации приходящей строки изображения
def convert_base64_to_inline_image(tpl, base64_string: str):
    """
    Принимает строку base64 (с заголовком или без),
    возвращает объект InlineImage.
    """
    # 1. Убираем заголовок data:image/..., если он есть
    if "base64," in base64_string:
        _, data = base64_string.split("base64,")
    else:
        data = base64_string
    image_bytes = base64.b64decode(data)
    image_stream = BytesIO(image_bytes)
    return InlineImage(tpl, image_stream)


def create_word_docx_template_img(
    template_name: str, content_fill: BaseModel
) -> BytesIO:
    template_path = DIR_TEMPLATE / f"{template_name}.docx"
    tpl = DocxTemplate(template_path)

    context = content_fill.model_dump()
    if context.get("exec_techn_list"):
        for item in context["exec_techn_list"]:
            raw_b64 = item.get("image_base64_raw")
            if raw_b64 and isinstance(raw_b64, str):
                try:
                    if "base64," in raw_b64:
                        raw_b64 = raw_b64.split(",")[1]
                    image_bytes = base64.b64decode(raw_b64)
                    image_stream = BytesIO(image_bytes)
                    img_obj = InlineImage(tpl, image_stream, height=Mm(40))
                    # перезаписываем строковое поле объектом картинки
                    item["image_base64_raw"] = img_obj

                except Exception as e:
                    print(f"Не удалось создать картинку: {e}")
                    item["image_base64_raw"] = ""
            else:
                item["image_base64_raw"] = ""
    tpl.render(context)

    buffer = BytesIO()
    tpl.save(buffer)
    buffer.seek(0)
    return buffer


# ----------------------------------------------------------------------------------
def merge_docx_buffers(buffers_list: list[BytesIO]) -> BytesIO:
    """
    Принимает список BytesIO (результаты create_word_docx_template)
    и возвращает один объединенный BytesIO.
    """
    if not buffers_list:
        return None

    # 1. Берем первый файл как основу (Master)
    # Важно: создаем новый Document из байтов
    master_doc = Document_compose(buffers_list[0])
    composer = Composer(master_doc)

    # 2. Добавляем остальные файлы по очереди
    for buffer in buffers_list[1:]:
        doc_to_append = Document_compose(buffer)
        # разрыв для новой страницы следующей части
        master_doc.add_page_break()
        # append добавляет содержимое с разрывом страницы (обычно)
        composer.append(doc_to_append)

    # 3. Сохраняем результат в новый поток
    merged_output = BytesIO()
    composer.save(merged_output)
    merged_output.seek(0)
    return merged_output


# --------------------------------------------------------------
# "google/gemini-2.5-flash-image"
# "google/gemini-3-pro-image-preview"
def generate_vector_instruction_image(
    action_describe: str,
    api_key: str = OPENROUTER_API_KEY_HAKATON,
    model: str = "google/gemini-2.5-flash-image",
) -> bytes:
    """
    Генерирует векторную инструкцию (триптих) на основе описания шагов.
    Возвращает декодированные байты изображения.
    """
    url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    style_rules = """
    VISUAL STYLE GUIDE:
    Create a high-quality realistic vector illustration.
    Art Style: "Adobe Illustrator" style with Gradient Mesh. Clean, sharp lines and precise geometry. High fidelity and realistic proportions,
    but maintaining a clear "digital drawing" aesthetic. NOT a photograph, NOT a grainy 3D render. Smooth vector gradients.
    Crucial Requirement: TEXTLESS. There must be NO text, NO numbers, NO letters, and NO labels on the image. Visual storytelling only.
    Lighting: Bright, professional, even lighting. No harsh shadows.
    Colors: Vibrant but professional. Industrial Blues, Safety Orange, Clean Greys.
    """

    collage_prompt = (
        f"{style_rules}\n\n"
        f"IMAGE LAYOUT: A wide horizontal instructional image split into 3 distinct vertical panels (triptych), reading from left to right.\n"
        f"STRICTLY NO TEXT OR WATERMARKS IN ANY PANEL.\n"
        f"CONTEXT OF OPERATION: {action_describe}\n"
        f"Generate 3 logical steps (Start -> Action -> Result) based on the context above.\n"
        f"Make sure the character and environment are consistent across all panels."
        "Не надо делать надписи на triptych текст 'Start','Action','Result'"
        "Нужно, чтобы на картинках показывалось именно безопасное выполнение операции человеком"
        "Можно отметить опасности при выполнении данной операции"
        "Обязательно изображай людей в средствах индивидуальной защиты, которые нужно применять при этой операции"
        "Обводи красным опасности, отмечай риски"
        "Изображай только реальные предметы. НЕ ПРИДУМЫВАЙ нереальные механизмы, предметы"
        "Если при рисовании схемы строповки ты не знаешь как выглядит какой то предмет, который надо изобразить - рисуй вместо него цилиндр или куб и подпиши текстом название предмета"
        "НИ В КОЕМ СЛУЧАЕ НЕ ПОДМЕНЯЙ ПРЕДМЕТЫ НА КАРТИНКЕ ПО ОПИСАНИЮ, ЕСЛИ НЕ ЗНАЕШЬ КАК ВЫГЛЯДИТ КАКОЙ ТО ПРЕДМЕТ"
    )

    payload = {
        "model": model,
        "temperature": 0.0,
        "messages": [{"role": "user", "content": collage_prompt}],
        "modalities": ["image", "text"],
        "image_config": {"aspect_ratio": "21:9"},
    }
    response = requests.post(url, headers=headers, json=payload)
    result = response.json()

    img_data = result["choices"][0]["message"]["images"][0]
    base64_string = img_data["image_url"]["url"].split(",")[1]
    # возвращаем поток байт, т.к. docxtpl умеет писать картинки в Word из потока байт
    return BytesIO(base64.b64decode(base64_string))


# ----------------------------------------------------------------------------------------------------


# функция генерации картинок
def convert_technology_to_images_model(
    source_data: ExecutionTechnologyWithPrepImages,
    api_key: str = OPENROUTER_API_KEY_HAKATON,
) -> ExecutionTechnologyWithImages:
    """
    Принимает модель с маркерами, генерирует картинки для отмеченных шагов
    и возвращает итоговую модель с байтами изображений.
    """
    result_rows = []

    for row in source_data.exec_techn_list:
        image_bytes = None

        # Проверяем маркер. Если "1", вызываем генерацию
        if row.is_complex_operation == "1":
            try:
                # Получаем BytesIO от вашей функции
                image_io = generate_vector_instruction_image(
                    action_describe=row.action_describe, api_key=api_key
                )
                # Важно: Pydantic модель ждет bytes, а не BytesIO.
                # Вызываем .getvalue() для получения сырых байт
                image_bytes = image_io.getvalue()
            except Exception as e:
                print(f"Ошибка генерации для шага {row.number_action}: {e}")
                image_bytes = None

        # Создаем экземпляр целевой строки (без поля is_complex_operation)
        new_row = ExecutionTechnologyRowWithImages(
            number_action=row.number_action,
            action_describe=row.action_describe,
            image_base64_raw=image_bytes,
        )
        result_rows.append(new_row)

    # Собираем итоговую модель
    return ExecutionTechnologyWithImages(exec_techn_list=result_rows)


def convert_technology_to_images_model_parallel(
    source_data: ExecutionTechnologyWithPrepImages,
    api_key: str = OPENROUTER_API_KEY_HAKATON,
) -> ExecutionTechnologyWithImages:

    # Внутренняя функция для обработки одной строки
    def process_single_row(
        row: ExecutionTechnologyRowWithPrepImages,
    ) -> ExecutionTechnologyRowWithImages:
        image_bytes = None

        if row.is_complex_operation == "1":
            try:
                # Вызов вашей функции
                image_io = generate_vector_instruction_image(
                    action_describe=row.action_describe, api_key=api_key
                )
                image_bytes = image_io.getvalue()
            except Exception as e:
                print(f"Error processing step {row.number_action}: {e}")

        return ExecutionTechnologyRowWithImages(
            number_action=row.number_action,
            action_describe=row.action_describe,
            image_base64_raw=image_bytes,
        )

    # Используем ThreadPoolExecutor для параллельного запуска
    # max_workers=5 означает, что одновременно будет генерироваться до 5 картинок
    with ThreadPoolExecutor(max_workers=5) as executor:
        # map сохраняет порядок элементов, что важно для exec_techn_list
        result_rows = list(
            executor.map(process_single_row, source_data.exec_techn_list)
        )

    return ExecutionTechnologyWithImages(exec_techn_list=result_rows)


# ----------------------------------------------------------------------------------------------------
# генерация дока с картинками:
def create_word_docx_template_img(
    template_name: str, content_fill: BaseModel
) -> BytesIO:
    """
    Заполняет Word-шаблон данными и картинками.
    Принимает Pydantic-модель (например, ExecutionTechnologyWithImages).
    Картинки ожидаются в поле 'image_base64_raw' (bytes или base64 string).
    """

    template_path = DIR_TEMPLATE / f"{template_name}.docx"

    # Загружаем шаблон
    try:
        tpl = DocxTemplate(template_path)
    except FileNotFoundError:
        raise FileNotFoundError(
            f"Шаблон {template_name}.docx не найден по пути {template_path}"
        )

    # Превращаем Pydantic модель в словарь
    context = content_fill.model_dump()

    # Проходимся по списку операций, если он есть
    techn_list = context.get("exec_techn_list")

    if techn_list:
        for item in techn_list:
            raw_data = item.get("image_base64_raw")
            image_stream = None

            # 1. Если данные - это уже байты (наш случай с Pydantic моделью из Python)
            if isinstance(raw_data, bytes):
                image_stream = BytesIO(raw_data)

            # 2. Если данные - это строка (например, пришло из JSON/Frontend)
            elif isinstance(raw_data, str) and raw_data:
                try:
                    # Очищаем от префикса, если он есть (data:image/png;base64,...)
                    if "base64," in raw_data:
                        raw_data = raw_data.split("base64,")[1]

                    decoded_bytes = base64.b64decode(raw_data)
                    image_stream = BytesIO(decoded_bytes)
                except Exception as e:
                    print(
                        f"Ошибка декодирования Base64 для шага {item.get('number_action')}: {e}"
                    )

            # 3. Если поток картинки успешно создан -> Создаем InlineImage
            if image_stream:
                try:
                    img_obj = InlineImage(tpl, image_stream, height=Mm(70))
                    item["image_base64_raw"] = img_obj
                except Exception as e:
                    print(f"Ошибка вставки картинки в Word: {e}")
                    item["image_base64_raw"] = ""
            else:
                item["image_base64_raw"] = ""

    # Рендерим контекст в документ
    tpl.render(context)

    # Сохраняем результат в буфер памяти
    buffer = BytesIO()
    tpl.save(buffer)
    buffer.seek(0)

    return buffer
