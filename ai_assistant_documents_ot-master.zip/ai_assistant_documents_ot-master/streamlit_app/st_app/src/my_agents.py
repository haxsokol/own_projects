# from openai import AsyncOpenAI
from langfuse.openai import AsyncOpenAI
from agents import (
    Agent,
    Runner,
    OpenAIChatCompletionsModel,
    ModelSettings,
)
from .models import *
from .tools import (
    lightrag_query_test,
    search_tech_safety,
    search_opf_vpf_siz,
    search_letal_factors,
)
from .utills import convert_technology_to_images_model_parallel
from src.config import OPENROUTER_API_KEY, OPENROUTER_API_KEY_HAKATON
import asyncio
from datetime import datetime, timedelta
from pathlib import Path

DIR_THIS_FILE = Path(__file__).parent

clientOpenRouter = AsyncOpenAI(
    api_key=OPENROUTER_API_KEY_HAKATON,
    base_url="https://openrouter.ai/api/v1",
)
model_main = "google/gemini-2.5-flash"
# "x-ai/grok-4.1-fast:free"
# "openai/gpt-5-mini"
# "google/gemini-2.5-flash"
# "openai/gpt-5.1"
# "deepseek/deepseek-chat-v3-0324"
# "openai/gpt-5.2-chat"
# "openai/gpt-5.2"


# ========================================================================================================================
# АГЕНТ ПРЕОБРАЗОВАНИЯ ПОЛЬЗОВАТЕЛЬСКОГО ПРОМТА В ИТОГОВЫЙ ПРОМТ ДЛЯ ДРУГИХ АГЕНТОВ:
async def run_ai_promt_resault_agent(
    user_query: UserPromtResault,
    client=clientOpenRouter,
    model_name: str = model_main,
) -> AiPromtResault:
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )
    input = user_query.model_dump_json()
    system_instructions = (DIR_THIS_FILE / "prompts/AIPromtResaultAgent.md").read_text(
        encoding="utf-8"
    )
    agent = Agent(
        name="AIPromtResaultAgent",
        model=model,
        model_settings=ModelSettings(
            temperature=0.1,
        ),
        instructions=system_instructions,
        output_type=AiPromtResault,
    )
    result = await Runner.run(starting_agent=agent, input=input, max_turns=1)
    return result.final_output


# -------------------------------------------------------------------------------------------------------------
# АГЕНТ ФОРМИРОВАНИЯ "ВЕДОМОСТЬ МЕХАНИЗМОВ, ИНСТРУМЕНТА, ПРИСПОСОБЛЕНИЙ И ТМЦ"
async def run_ai_instruments_agent(
    title_name: str,
    title_post: str | None,
    title_fio: str | None,
    context: str,
    client=clientOpenRouter,
    model_name: str = model_main,
) -> Title:
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )
    system_instructions = f"""
    Нужно вернуть МЕХАНИЗМОВ, ИНСТРУМЕНТА, ПРИСПОСОБЛЕНИЙ И ТМЦ на основании описания
    разовой работы.
    1. Вернуть `title_name`={title_name},`title_post`={title_post},`title_fio`={title_fio}, ЕСЛИ НЕТ ЗНАЧЕНИЯ ТО ПРОСТАВИТЬ -
    2. Нужно определить какие ВЕДОМОСТЬ МЕХАНИЗМОВ, ИНСТРУМЕНТА, ПРИСПОСОБЛЕНИЙ ИЛИ ТОВАРНО-МАТЕРИАЛЬНЫХ ЦЕННОСТЕЙ
    нужно для выполнения разовой работы, описанной во входных данных `context`
    и вернуть эти механизмы в `table_instrument`. НЕ ПИШИ СРЕДСТВА ИНДИВИДУАЛЬНОЙ ЗАЩИТЫ.
    """

    agent = Agent(
        name="AIInstruments",
        model=model,
        model_settings=ModelSettings(
            temperature=0.1,
        ),
        instructions=system_instructions,
        output_type=Title,
    )
    result = await Runner.run(starting_agent=agent, input=f"context:{context}")
    return result.final_output


# -------------------------------------------------------------------------------------------------------------
# АГЕНТ ЗАПОЛНЕНИЯ ТЕХНОЛОГИИ ВЫПОЛНЕНИЯ РАБОТ:
async def run_execution_technology_agent(
    user_query: AiPromtResault,
    client=clientOpenRouter,
    model_name: str = model_main,
) -> ExecutionTechnology:
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )
    input = user_query.model_dump_json()
    system_instructions = (
        DIR_THIS_FILE / "prompts/ExecutionTechnologyAgent.md"
    ).read_text(encoding="utf-8")
    agent = Agent(
        name="ExecutionTechnologyAgent",
        model=model,
        model_settings=ModelSettings(
            temperature=0.2,
        ),
        instructions=system_instructions,
        output_type=ExecutionTechnology,
        tools=[search_tech_safety],
    )
    result = await Runner.run(starting_agent=agent, input=input, max_turns=20)
    return result.final_output


# АГЕНТ ЗАПОЛНЕНИЯ ТЕХНОЛОГИИ ВЫПОЛНЕНИЯ РАБОТ С МАРКЕРОМ ДЛЯ КАРТИНОК:
async def run_execution_technology_prep_img_agent(
    user_query: AiPromtResault,
    client=clientOpenRouter,
    model_name: str = model_main,
) -> ExecutionTechnologyWithPrepImages:
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )
    input = user_query.model_dump_json()

    system_instructions = (
        DIR_THIS_FILE / "prompts/ExecutionTechnologyPrepImgAgent.md"
    ).read_text(encoding="utf-8")

    agent = Agent(
        name="ExecutionTechnologyPrepImgAgent",
        model=model,
        model_settings=ModelSettings(
            temperature=0.2,
        ),
        instructions=system_instructions,
        output_type=ExecutionTechnologyWithPrepImages,
        tools=[search_tech_safety],
    )
    result = await Runner.run(starting_agent=agent, input=input, max_turns=3)
    return result.final_output


# АГЕНТ С МАРКЕРОМ СЛОЖНЫХ РАБОТ + ГЕНЕРАЦИЯ САМИХ КАРТИНОК
async def run_execution_technology_img_agent(
    user_query,
) -> ExecutionTechnologyWithImages:
    """
    Создает картинки сложных, комплексных операций, где is_complex_operation=1
    """
    prep_data = await run_execution_technology_prep_img_agent(user_query=user_query)
    final_images = await asyncio.to_thread(
        convert_technology_to_images_model_parallel, prep_data
    )
    return final_images


# -------------------------------------------------------------------------------------------------------------
# АГЕНТ ЗАПОЛНЕНИЯ Ведомость ОПФ, ВПФ и меры защиты:
async def run_harmful_danger_factor_agent(
    user_query: AiPromtResault,
    client=clientOpenRouter,
    model_name: str = model_main,
) -> HarmfulDangerousFactor:
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )
    input = user_query.model_dump_json()
    system_instructions = (
        DIR_THIS_FILE / "prompts/HarmfulDangerousFactorAgent.md"
    ).read_text(encoding="utf-8")

    agent = Agent(
        name="HarmfulDangerousFactorAgent",
        model=model,
        model_settings=ModelSettings(
            temperature=0.1,
        ),
        instructions=system_instructions,
        output_type=HarmfulDangerousFactor,
        tools=[search_opf_vpf_siz],
    )
    result = await Runner.run(starting_agent=agent, input=input, max_turns=6)
    return result.final_output


# -------------------------------------------------------------------------------------------------------------
# АГЕНТ ЗАПОЛНЕНИЯ Смертельные опасности:
async def run_letal_danger_agent(
    user_query: AiPromtResault,
    client=clientOpenRouter,
    model_name: str = model_main,
) -> DeadlyDanger:
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )
    input = user_query.model_dump_json()
    system_instructions = (DIR_THIS_FILE / "prompts/LetalDangerAgent.md").read_text(
        encoding="utf-8"
    )

    agent = Agent(
        name="DeadlyDangerAgent",
        model=model,
        model_settings=ModelSettings(
            temperature=0.1,
        ),
        instructions=system_instructions,
        output_type=DeadlyDanger,
        tools=[search_letal_factors],
    )
    result = await Runner.run(starting_agent=agent, input=input, max_turns=6)
    return result.final_output


# ========================================================================================================================
# ========================================================================================================================
# --- ТЕСТОВЫЙ АГЕНТ С TOOL И LIGHTRAG ---
async def run_otd_agent(
    user_query: str,
    client=clientOpenRouter,
    model_name: str = model_main,
):
    model = OpenAIChatCompletionsModel(
        model=model_name,
        openai_client=client,
    )

    system_instructions = (
        "Ты помощник по охране труда. Твоя цель — помогать составлять документы. "
        "Если пользователь спрашивает что-то специфичное или требует данных из документов — "
        "ОБЯЗАТЕЛЬНО используй инструмент `lightrag_query_test` для поиска ответа.\n"
        "В конце ответа в скобках обязательно напиши, какие данные тебе вернулись из инструмента `lightrag_query`"
    )

    agent = Agent(
        name="OTD_Assistant",
        model=model,
        instructions=system_instructions,
        tools=[lightrag_query_test],
    )
    result = await Runner.run(agent, user_query)
    return result.final_output


# ========================================================================================================================
# ФУНКЦИИ ЗАПУСКА ВСЕХ АГЕНТОВ ===
async def run_agent_with_logging(coro, name, status_container):
    """
    Обертка: запускает корутину, пишет лог при успехе и возвращает результат.
    """
    try:
        status_container.write(
            f"⏳{(datetime.now() + timedelta(hours=3, minutes=6)).strftime("%H:%M:%S")} {name}: в работе..."
        )
        result = await coro
        status_container.write(
            f"✅ {(datetime.now() + timedelta(hours=3, minutes=6)).strftime("%H:%M:%S")} **{name}**: готово!"
        )
        return result
    except Exception as e:
        status_container.error(
            f"❌ {(datetime.now() + timedelta(hours=3, minutes=6)).strftime("%H:%M:%S")} **{name}**: ошибка ({e})"
        )
        raise e


async def run_all_agents_parallel(
    title_name,
    title_fio,
    title_post,
    prompt_obj,
    status_container,
    with_img: bool = False,
):
    """
    Запускает агентов параллельно, но логирует завершение каждого по отдельности.
    """
    # 1. Создаем корутины (сами задачи), но еще не "await-им" их
    coro_title = run_ai_instruments_agent(
        title_name=title_name,
        title_fio=title_fio,
        title_post=title_post,
        context=prompt_obj.context,
    )
    if with_img == 0:
        coro_tech = run_execution_technology_agent(user_query=prompt_obj)
    else:
        coro_tech = run_execution_technology_img_agent(user_query=prompt_obj)

    coro_opf = run_harmful_danger_factor_agent(user_query=prompt_obj)
    coro_risk = run_letal_danger_agent(user_query=prompt_obj)

    task_title = run_agent_with_logging(
        coro_title, "Титульный лист и ТМЦ, инструменты", status_container
    )
    task_tech = run_agent_with_logging(
        coro_tech, "Технология выполнения работ", status_container
    )
    task_opf = run_agent_with_logging(
        coro_opf, "Ведомость ОПФ, ВПФ и меры защиты", status_container
    )
    task_risk = run_agent_with_logging(coro_risk, "Смертельные риски", status_container)

    return await asyncio.gather(task_title, task_tech, task_opf, task_risk)


# ========================================================================================================================

if __name__ == "__main__":
    pass
