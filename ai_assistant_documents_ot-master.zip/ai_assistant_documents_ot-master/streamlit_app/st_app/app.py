import streamlit as st
import asyncio
from src.config import OPENROUTER_API_KEY, OPENROUTER_API_KEY_HAKATON, LIGHTRAG_HOST
from agents import set_tracing_disabled
from src.models import UserPromtResault, Title
from pathlib import Path
from src.session_init import init_session_storage
from src.my_agents import (
    run_ai_promt_resault_agent,
    run_otd_agent,
    run_ai_instruments_agent,
    run_execution_technology_agent,
    run_harmful_danger_factor_agent,
    run_letal_danger_agent,
    run_all_agents_parallel,
    run_execution_technology_img_agent,
)
from src.ui_components import check_money
from src.utills import (
    process_audio_file,
    process_audio_voice,
    recognize_images,
    return_lists_items,
    create_word_docx_template,
    create_word_docx_template_img,
    merge_docx_buffers,
)
from src.test_obj import *
from langfuse import get_client


DIR_THIS_FILE = Path(__file__).parent

set_tracing_disabled(disabled=True)
init_session_storage()
st.set_page_config(page_title="ИИ-помощник создания ОТД", page_icon="🤖", layout="wide")


def update_text_part(current_key, prev_key):
    new_val = st.session_state[current_key]
    old_val = st.session_state[prev_key]
    current_full_text = st.session_state.all_text

    if old_val in current_full_text and old_val != "":
        st.session_state.all_text = current_full_text.replace(old_val, new_val, 1)
    else:
        if new_val:
            st.session_state.all_text += f" {new_val}"

    st.session_state[prev_key] = new_val


st.markdown('# 📃💼 ИИ помощник для создания **"Техкарт на разовые работы"**')

with st.container(border=True, key="container_context"):
    st.markdown("## 1. Ввод описания разовой работы")

    col_input, col_media_voice, col_media_file = st.columns([6, 3, 3])
    with col_input:
        st.markdown(
            "##### ☝ Обязательно введите какое то описание (текст или голосовой/аудио ввод)"
        )
        text_area_val = st.text_area(
            label="### Текстовое описание",
            placeholder="Введите описание разовой работы для составления техкарты сюда",
            height=160,
            key="text_input_context_area",
            help="Вы можете редактировать этот текст. Результаты распознавания голоса будут добавляться сюда.",
            on_change=update_text_part,
            args=("text_input_context_area", "prev_text_input"),
            label_visibility="collapsed",
        )
    with col_media_voice:
        st.markdown("### 🎙️ Голосовой ввод")
        audio_mic = st.audio_input(label="Запись с микрофона")

        if audio_mic:
            if st.button(
                "📝 Расшифровать и записать в **Итоговое описание**",
                key="btn_transcribe_mic",
            ):
                asyncio.run(process_audio_voice(audio_mic.getvalue(), "Микрофон"))
                update_text_part("tcr_audio_voice", "prev_audio_voice")
                st.rerun()

    with col_media_file:
        st.markdown("### 📼 Аудиофайл")
        audio_file_upload = st.file_uploader(
            "Загрузите аудиофайл (макс 30 мин)",
            type=["mp3", "wav", "m4a", "ogg"],
        )
        if audio_file_upload:
            if audio_file_upload.size > 50 * 1024 * 1024:
                st.error("Файл слишком большой. Загрузите файл меньше 50 МБ.")
            else:
                if st.button(
                    "📝 Расшифровать и записать в **Итоговое описание**",
                    key="btn_transcribe_file",
                ):
                    asyncio.run(
                        process_audio_file(
                            audio_file_upload.getvalue(), audio_file_upload.name
                        )
                    )
                    update_text_part("tcr_audio_file", "prev_audio_file")
                    st.rerun()

    (
        first_agent_col1,
        first_agent_col2,
        first_agent_col3,
        first_agent_col4,
    ) = st.columns(4)

    # Собираем данные из UI
    st.session_state.profs = first_agent_col1.multiselect(
        "👷‍♂️ Профессии",
        return_lists_items("JobsWorker", "Job"),
        placeholder="Выберите профессии рабочих, производящие разовые работы...",
    )
    st.session_state.dangers = first_agent_col2.multiselect(
        "⚡ Опасности",
        return_lists_items("Risk_Dangers"),
        placeholder="Выберите опасности...",
    )
    st.session_state.siz = first_agent_col3.multiselect(
        "🧤 СИЗ",
        return_lists_items("ProtMat_Name"),
        placeholder="Выберите СИЗ...",
    )
    st.session_state.workshops = first_agent_col4.multiselect(
        "🏭 Цех",
        return_lists_items("Subdivision", "Workshops"),
        placeholder="Выберите цех...",
    )
    # БЛОК ЗАГРУЗКИ ФОТО
    st.markdown("---")
    uploaded_images = []
    st.markdown("### 🖼️ Фото места работ")
    uploaded_images = st.file_uploader(
        "Загрузить фото (макс 3)",
        type=["png", "jpg", "jpeg"],
        accept_multiple_files=True,
    )

    if uploaded_images:
        if len(uploaded_images) > 3:
            st.warning(
                "Можно загрузить не более 3 изображений. Будут использованы первые 3."
            )
            uploaded_images = uploaded_images[:3]
        cols_img = st.columns(3)
        for i, img in enumerate(uploaded_images):
            with cols_img[i]:
                st.image(img, use_container_width=True)
    if st.button(
        "Распознать картинки и включить в **Итоговое описание**",
        disabled=(len(uploaded_images) == 0),
    ):
        with st.spinner("Распознаю картинки..."):
            st.session_state.recognize_imgs = recognize_images(
                list_image_from_file_upload=uploaded_images
            )
            st.success(
                "✅ ИИ распознал обстановку на фото и записал в **Итоговое описание**"
            )
    if st.session_state.recognize_imgs != "":
        st.markdown(
            "✅ описание обстановки с изображений внесено в **Итоговое описание**"
        )
    st.markdown("---")
    # test_obj_on = st.toggle("Вкл тестовые данные")
    test_obj_on = False
    # ❗❗ заглушка для тестов, убрать потом
    if test_obj_on:
        st.session_state.final_promt_ai = final_promt_ai_example_obj

    with st.container(border=True):
        resault_col1, resault_col2 = st.columns(2)
        with resault_col1:
            st.markdown("### 👨Описание от пользователя для ТКР ⬇")
            st.session_state.final_promt_user = UserPromtResault(
                text=st.session_state.text_input_context_area,
                audiofile=st.session_state.tcr_audio_file,
                audiovoice=st.session_state.tcr_audio_voice,
                img=st.session_state.recognize_imgs,
                dangers=st.session_state.dangers,
                siz=st.session_state.siz,
                prof=st.session_state.profs,
                workshop=st.session_state.workshops,
            )
            st.text_area(
                label="",
                value=st.session_state.final_promt_user.get_pretty_repr(),
                height=270,
                label_visibility="collapsed",
            )

            if st.button(
                "Проанализировать описание от пользователя через ИИ ➡➡➡",
                disabled=(
                    test_obj_on
                    or (
                        (st.session_state.text_input_context_area == "")
                        and (st.session_state.tcr_audio_voice == "")
                        and (st.session_state.tcr_audio_file == "")
                    )
                ),
            ):
                with st.spinner("Заполняет ИИ..."):
                    try:
                        st.session_state.final_promt_ai = asyncio.run(
                            run_ai_promt_resault_agent(
                                user_query=st.session_state.final_promt_user,
                            )
                        )
                    except Exception as e:
                        st.error(f"Произошла ошибка: {e}")
        with resault_col2:
            st.markdown("### 💻🧠 Переработанное описание разовой работы через ИИ ⬇")
            st.text_area(
                label="",
                value=(
                    st.session_state.final_promt_ai
                    if isinstance(st.session_state.final_promt_ai, str)
                    else st.session_state.final_promt_ai.get_pretty_repr()
                ),
                height=270,
                label_visibility="collapsed",
            )
            if st.session_state.final_promt_ai != "":
                st.markdown(
                    "✅ ИИ проработал описание разовой работы от пользователя для других агентов"
                )
                st.info("🎉 Можно запускать создание ТКР ⤵")


auto_mode_on = st.toggle("Вкл авторежим", value=True)
with_img = st.toggle("Технология выполнения работ с картинками?", value=True)
# ❗❗ заглушка для тестов, убрать потом
if test_obj_on:
    st.session_state.title_fill_obj = title_example_obj
# выключалка кнопок генерации:
button_off = (st.session_state.final_promt_ai == "") or (test_obj_on)
# ==================================================================================================
# 💾 ВСЕ БЛОКИ СКАЧКИ:
if not auto_mode_on:
    with st.container(border=True):
        download_col1, download_col2 = st.columns(2)

        # === БЛОК 2: ТИТУЛЬНЫЙ ЛИСТ ===
        with download_col1.container(
            border=True, height=320, key="container_title_agent"
        ):
            st.markdown("## 2. Титульный лист")
            title_col_name, title_col_post, title_col_fio = st.columns(3)
            st.session_state.title_name = title_col_name.text_input(
                "Название ТКР", placeholder="Например: Ремонт насоса H-12"
            )
            st.session_state.title_post = title_col_post.text_input(
                "Должность разработчика ТКР"
            )
            st.session_state.title_fio = title_col_fio.text_input(
                "ФИО разработчика ТКР"
            )

            if st.button(
                "Создать титульный лист с необходимыми ТМЦ, инструментами",
                disabled=(st.session_state.title_name == "")
                and not (isinstance(st.session_state.title_fill_obj, Title)),
            ):
                with st.spinner("ИИ формирует необходимы ТМЦ, инструменты..."):
                    st.session_state.title_fill_obj = asyncio.run(
                        run_ai_instruments_agent(
                            title_name=st.session_state.title_name,
                            title_fio=st.session_state.title_fio,
                            title_post=st.session_state.title_post,
                            context=st.session_state.final_promt_ai.context,
                        )
                    )
                    st.success(
                        icon="🎉",
                        body="ИИ сформировал титульный лист с ТМЦ, инструментами",
                    )
            if st.session_state.title_fill_obj.__class__.__name__ == "Title":
                st.markdown("✅ ИИ создал данные о необходимых ТМЦ, инструментах")
                st.download_button(
                    label="Скачать титульный лист ТКР",
                    data=create_word_docx_template(
                        template_name="TKR_title_py",
                        content_fill=st.session_state.title_fill_obj,
                    ),
                    file_name=f"Титульный лист ТКР-{st.session_state.title_fill_obj.title_name}.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                )

        # ==================================================================================================
        # === БЛОК 3: ТЕХНОЛОГИЯ ВЫПОЛНЕНИЯ РАБОТ ===
        with download_col2.container(
            border=True, height=320, key="container_tech_oper_agent"
        ):
            st.markdown("## 3. Технология выполнения работ")
            # on_tech_img = st.toggle(
            #     "🎴 Вкл генерацию данных по технологии выполнению работ с картинками"
            # )
            if with_img is False:
                if st.button(
                    label="Создать раздел с технологией выполнения работ",
                    disabled=st.session_state.final_promt_ai == "",
                ):
                    with st.spinner("ИИ формирует технологию выполнения работ..."):
                        st.session_state.filled_exec_tech = asyncio.run(
                            run_execution_technology_agent(
                                user_query=st.session_state.final_promt_ai
                            )
                        )
                if (
                    st.session_state.filled_exec_tech.__class__.__name__
                    == "ExecutionTechnology"
                ):
                    st.markdown(
                        "✅ ИИ создал данные для Технология выполнения работ для ТКР"
                    )
                    st.download_button(
                        label="Скачать заполненный Технология выполнения работ",
                        data=create_word_docx_template(
                            template_name="TKR_execution_technology",
                            content_fill=st.session_state.filled_exec_tech,
                        ),
                        key="download_exec_tech",
                        file_name=f"Технология выполнения работ.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    )
            # 🎴 ФОРМИРОВАНИЕ ТЕХНОЛОГИИ ВЫПОЛНЕНИЯ РАБОТ С КАРТИНКАМИ:
            if with_img:
                st.write("с картинками")
                if st.button(
                    label="Создать раздел с технологией выполнения работ и картинками",
                    disabled=st.session_state.final_promt_ai == "",
                ):
                    with st.spinner("ИИ формирует технологию выполнения работ..."):
                        st.session_state.filled_exec_tech_img = asyncio.run(
                            run_execution_technology_img_agent(
                                user_query=st.session_state.final_promt_ai
                            )
                        )
                        st.success(
                            "✅ удалось создать несколько картинок для сложных операций через ИИ"
                        )
                if (
                    st.session_state.filled_exec_tech_img.__class__.__name__
                    == "ExecutionTechnologyWithImages"
                ):
                    st.markdown(
                        "✅ ИИ создал данные для Технология выполнения работ для ТКР с картинками"
                    )
                    st.download_button(
                        label="Скачать заполненный **Технология выполнения работ с картинками**",
                        data=create_word_docx_template_img(
                            template_name="TKR_execution_technology_img",
                            content_fill=st.session_state.filled_exec_tech_img,
                        ),
                        key="download_exec_tech_img",
                        file_name=f"Технология выпонения работ с картинками.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    )

        # ==================================================================================================
        # === БЛОК 4: ВЕДОМОСТИ И РИСКИ ===
        with download_col1.container(border=True, height=320, key="container_opf"):
            st.markdown("## 4. Ведомость ОПФ, ВПФ и меры защиты")
            if st.button(
                label="Создать раздел с ОПФ, ВПФ",
                disabled=st.session_state.final_promt_ai == "",
            ):
                with st.spinner("ИИ формирует ОПФ, ВПФ и меры защиты..."):
                    st.session_state.filled_hamf_danger_factor = asyncio.run(
                        run_harmful_danger_factor_agent(
                            user_query=st.session_state.final_promt_ai
                        )
                    )
            if st.session_state.filled_hamf_danger_factor != "":
                st.markdown("✅ ИИ создал данные для Ведомость ОПФ, ВПФ и меры защиты")
                st.download_button(
                    label="Скачать заполненный Ведомость ОПФ, ВПФ и меры защиты",
                    data=create_word_docx_template(
                        template_name="TKR_OPF",
                        content_fill=st.session_state.filled_hamf_danger_factor,
                    ),
                    key="download_opf",
                    file_name=f"Ведомость ОПФ, ВПФ и меры защиты.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                )

        # ==================================================================================================
        # === БЛОК 5: ВЕДОМОСТИ И РИСКИ ===
        with download_col2.container(border=True, height=320, key="container_risk"):
            st.markdown("## 5. Смертельные опасности")
            if st.button(
                label="Создать раздел со смертельными опасностями",
                disabled=st.session_state.final_promt_ai == "",
            ):
                with st.spinner("ИИ формирует смертельные опасности..."):
                    st.session_state.filled_letal_danger = asyncio.run(
                        run_letal_danger_agent(
                            user_query=st.session_state.final_promt_ai
                        )
                    )
            if st.session_state.filled_letal_danger != "":
                st.markdown("✅ ИИ создал данные для Ведомость ОПФ, ВПФ и меры защиты")
                st.download_button(
                    label="Скачать заполненный Смертельные опасности",
                    data=create_word_docx_template(
                        template_name="TKR_letal_risks",
                        content_fill=st.session_state.filled_letal_danger,
                    ),
                    key="download_letal_risk",
                    file_name=f"Смертельные опасности.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                )

        st.header("📑 Сборка общего документа ТКР")
        с1, с2 = st.columns([1, 4])
        if st.session_state.title_fill_obj != "":
            с1.write("✅ Титульный лист")
        if st.session_state.filled_exec_tech != "":
            с1.write("✅ Технология выполнения работ")
        if st.session_state.filled_exec_tech_img != "":
            с1.write("✅ Технология выполнения работ с картинками")
        if st.session_state.filled_hamf_danger_factor != "":
            с1.write("✅ Ведомость ОПФ, ВПФ и меры защиты")
        if st.session_state.filled_letal_danger != "":
            с1.write("✅ Смертельные опасности")
        # Кнопка генерации
        if st.button("Соединить все разделы в готовую ТКР"):
            with st.spinner("Склеивание документа..."):
                try:
                    part_1 = create_word_docx_template(
                        "TKR_title_py", st.session_state.title_fill_obj
                    )
                    if not with_img:
                        part_2 = create_word_docx_template(
                            "TKR_execution_technology",
                            st.session_state.filled_exec_tech,
                        )
                    else:
                        part_2 = create_word_docx_template_img(
                            "TKR_execution_technology_img",
                            st.session_state.filled_exec_tech_img,
                        )

                    part_3 = create_word_docx_template(
                        "TKR_OPF", st.session_state.filled_hamf_danger_factor
                    )
                    part_4 = create_word_docx_template(
                        "TKR_letal_risks", st.session_state.filled_letal_danger
                    )
                    all_parts = [part_1, part_2, part_3, part_4]
                    merged_file = merge_docx_buffers(all_parts)
                    # Сохраняем готовый файл в стейт
                    st.session_state["final_tkr_doc"] = merged_file
                except Exception as e:
                    st.error(f"Ошибка сборки: {e}")
            st.success("Документ собран!")

        # Показываем кнопку скачивания, если файл готов
        if st.session_state.get("final_tkr_doc"):
            st.download_button(
                label="💾 Скачать готовый ТКР.docx",
                data=st.session_state["final_tkr_doc"],
                file_name=f"ТКР_{st.session_state.get('title_name', 'Full')}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )


# АВТОМАТИЧЕСКИЙ ЗАПУСК ВСЕГО ТКР
if auto_mode_on:
    # === 2. ИНТЕРФЕЙС (ВВОД ДАННЫХ) ===

    with st.container(border=True):
        st.markdown("## 💻🚴‍♀️ Генерация сразу всех разделов ТКР")
        col_input1, col_input2 = st.columns(2)

        # Ввод данных для Титульного листа
        with col_input1:
            st.markdown("#### Название ТКР для титульного листа")
            st.text_input(
                label="Название ТКР",
                placeholder="Например: Ремонт насоса H-12",
                label_visibility="collapsed",
                key="title_name",
            )
            st.markdown("#### Данные разработчика ТКР")
            st.text_input("Должность разработчика", key="title_post")
            st.text_input("ФИО разработчика", key="title_fio")
        # if (
        #     "final_promt_ai" not in st.session_state
        #     or st.session_state.final_promt_ai == ""
        # ):
        #     st.session_state.final_promt_ai = final_promt_ai_example_obj  # ❗заглушка

        with col_input2:
            st.markdown("### Статус готовности")
            if st.session_state.final_promt_ai:
                st.info("✅ Описание разовой работы ТКР от ИИ есть")
            else:
                st.warning("Описание разовой работы для ИИ отсутствует")
            if st.session_state.title_name:
                st.info("✅ Название ТКР есть")
            else:
                st.warning("Нет название ТКР")
            if st.session_state.final_promt_ai and st.session_state.title_name:
                st.info("🚀 Можно запускать создания всех разделов ТКР")

        # === 3. ГЛАВНАЯ КНОПКА ГЕНЕРАЦИИ (ЗАПУСК АГЕНТОВ) ===
        inputs_valid = (st.session_state.title_name != "") and (
            (st.session_state.final_promt_ai != "")
        )

        if st.button(
            "💻🧠🚴‍♀️ Запустить создание всех разделов ТКР",
            type="primary",
            disabled=not inputs_valid,
            use_container_width=True,
        ):
            with st.status(
                "ИИ агенты работают параллельно...", expanded=True
            ) as status:
                st.write("🚀 Инициализация агентов...")
                try:
                    results = asyncio.run(
                        run_all_agents_parallel(
                            title_name=st.session_state.title_name,
                            title_fio=st.session_state.title_fio,
                            title_post=st.session_state.title_post,
                            prompt_obj=st.session_state.final_promt_ai,
                            with_img=with_img,
                            status_container=status,
                        )
                    )
                    st.session_state.title_fill_obj = results[0]
                    if not with_img:
                        st.session_state.filled_exec_tech = results[1]
                    else:
                        st.session_state.filled_exec_tech_img = results[1]
                    st.session_state.filled_hamf_danger_factor = results[2]
                    st.session_state.filled_letal_danger = results[3]

                    st.session_state["generation_complete"] = True

                    status.update(
                        label="✅ Все разделы успешно сгенерированы!",
                        state="complete",
                        expanded=False,
                    )

                except Exception as e:
                    st.error(f"Произошла ошибка при генерации: {e}")
                    status.update(label="❌ Ошибка генерации", state="error")

        # === 4. ОТОБРАЖЕНИЕ РЕЗУЛЬТАТОВ И КНОПКА СБОРКИ ===
        has_results = st.session_state.get("generation_complete", False)

        if has_results:
            st.success("Данные получены от всех 4-х агентов. Можно собирать документ.")
            with st.spinner("Склеивание документа..."):
                try:
                    part_1 = create_word_docx_template(
                        "TKR_title_py", st.session_state.title_fill_obj
                    )
                    if not with_img:
                        part_2 = create_word_docx_template(
                            "TKR_execution_technology",
                            st.session_state.filled_exec_tech,
                        )
                    else:
                        part_2 = create_word_docx_template_img(
                            "TKR_execution_technology_img",
                            st.session_state.filled_exec_tech_img,
                        )

                    part_3 = create_word_docx_template(
                        "TKR_OPF", st.session_state.filled_hamf_danger_factor
                    )
                    part_4 = create_word_docx_template(
                        "TKR_letal_risks", st.session_state.filled_letal_danger
                    )
                    all_parts = [part_1, part_2, part_3, part_4]
                    merged_file = merge_docx_buffers(all_parts)
                    # Сохраняем готовый файл в стейт
                    st.session_state["final_tkr_doc"] = merged_file
                except Exception as e:
                    st.error(f"Ошибка сборки: {e}")

        # === 5. КНОПКА СКАЧИВАНИЯ ===
        if st.session_state.get("final_tkr_doc"):
            st.download_button(
                label="💾 Скачать готовый ТКР.docx",
                data=st.session_state["final_tkr_doc"],
                file_name=f"ТКР_{st.session_state.get('title_name', 'Full')}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )

maintanes = st.toggle("Вкл инф для отладки")
if maintanes:
    langfuse_c = get_client()
    if langfuse_c.auth_check():
        st.success("✅ Langfuse подключен")

    st.markdown("---")
    check_money()

    st.write(st.session_state.filled_letal_danger)
    st.write(st.session_state.filled_exec_tech_img)
    # st.write(st.session_state.filled_exec_tech_img)
    # st.write(st.session_state)
    # st.session_state.us_q = st.text_input(
    #     label="вопрос к lightRAG", placeholder="вопрос к lightRAG", value=""
    # )
    # if st.button("Тестовый запрос к LightRAG"):
    #     r = asyncio.run(run_otd_agent(user_query=st.session_state.us_q))
    #     st.text_area(label="ответ от LightRAG", value=r)
