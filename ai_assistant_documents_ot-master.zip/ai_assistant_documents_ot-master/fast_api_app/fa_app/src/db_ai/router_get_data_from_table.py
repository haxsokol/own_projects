from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session
from pathlib import Path
from .database import get_db
from .models import *

DIR_SQL_FILE = Path(__file__).parents[2] / "data/sql"

# Создаем роутер
router = APIRouter()

# Словарь: название таблицы → Pydantic-модель
TABLE_TO_MODEL = {
    "get_factor": HarmfulAndDangerousFactorTypes,
    "get_siz": ProtMat_Name,
    "get_risk_dangers": Risk_Dangers,
    "get_operations": Risk_OperationTypes,
    "get_jobsl_rss": JobsRSS,
    "get_jobs_workers": JobsWorker,
    "get_workshops": Workshops,
    "get_manuf": Manufacture,
}


@router.get("/table/{sql_name}")
def get_table_data(sql_name: str, db: Session = Depends(get_db)) -> list:
    # 1. Получаем класс модели по имени (например, HarmfulAndDangerousFactorTypes)
    model_class = TABLE_TO_MODEL.get(sql_name)

    # Если модели нет в словаре — ошибка 404
    if not model_class:
        raise HTTPException(
            status_code=404, detail=f"Model/Table '{sql_name}' not configured"
        )

    # 2. Проверяем наличие файла
    file_path = DIR_SQL_FILE / f"{sql_name}.sql"
    if not file_path.exists():
        raise HTTPException(
            status_code=404, detail=f"SQL file '{sql_name}.sql' not found"
        )

    # 3. Читаем SQL
    with open(file_path, "r", encoding="utf-8") as f:
        query = f.read()

    # 4. Выполняем запрос
    # .mappings() превращает строки в словари, где ключи = названия колонок
    rows = db.execute(text(query)).mappings().all()

    # 5. Превращаем "сырые" словари в Pydantic-модели
    # Это проверит типы данных (валидация) и отфильтрует лишнее, если настроено
    try:
        # model_class(**row) — это создание объекта модели из словаря
        result = [model_class(**row) for row in rows]
    except Exception as e:
        # Если данные в БД не соответствуют модели (например, нет обязательного поля)
        raise HTTPException(status_code=500, detail=f"Data validation error: {str(e)}")
    return result
