from pydantic import BaseModel


# нужно, чтобы ручка выбирала столбец, иначе будут ошибки
class HarmfulAndDangerousFactorTypes(BaseModel):
    Id: int
    ParentId: int
    Paragraph: str
    ParentFactor: str
    Factor: str


class ProtMat_Name(BaseModel):
    Id: int
    Name: str
    RulesOfApplication: str
    InspectionRulesBeforeWork: str
    RejectionRules: str


class Risk_Dangers(BaseModel):
    Id: int
    Name: str
    ImpactDescription: str
    ExistingControls: str
    WorkAtHeight: str
    IsDeadlyRiskNd: str


class Risk_OperationTypes(BaseModel):
    Name: str


class JobsRSS(BaseModel):
    Job: str


class JobsWorker(BaseModel):
    Job: str


class Workshops(BaseModel):
    Workshops: str


class Manufacture(BaseModel):
    Manufacture: str
