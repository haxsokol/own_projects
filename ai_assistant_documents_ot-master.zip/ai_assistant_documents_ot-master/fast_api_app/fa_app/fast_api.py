from fastapi import FastAPI
import random
from src.db_ai.router_get_data_from_table import router as table_router
from sqlalchemy import create_engine, text

app = FastAPI()

app.include_router(table_router)

URL_CONN_DB_AI = "postgresql+psycopg://admin:supersecret@postgres17:5432/ai"


@app.get("/hello")
def h():
    return "Хэллоу"


@app.get("/data_get_num")
def h():
    return random.randint(1, 111)


@app.get("/debug_connection")
def debug_connection():
    try:
        # Создаем engine прямо внутри функции (одноразовый)
        engine = create_engine(URL_CONN_DB_AI)

        # Пытаемся выполнить простейший запрос
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            val = result.scalar()

        return {"status": "OK", "db_response": val, "connected_to": URL_CONN_DB_AI}

    except Exception as e:
        # Если ошибка, возвращаем её текстом
        return {"status": "ERROR", "detail": str(e), "tried_url": URL_CONN_DB_AI}
